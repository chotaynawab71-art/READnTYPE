# READnTYPE — Next Steps (Android + Offline + Play Store)

Hi! I prepared your project for:
- Offline mode (PWA service worker)
- Android build with Capacitor
- Privacy Policy screen

## 1) Install dependencies
```bash
npm i
```

## 2) Run locally
```bash
npm run dev
# Open http://localhost:5173
# Visit #/privacy to see Privacy page
```

## 3) Build web (this generates /dist used by the Android app)
```bash
npm run build
```

## 4) Add Android platform and open Android Studio
```bash
# Install Capacitor deps (already added to package.json)
npm i @capacitor/core @capacitor/cli
# Create Android project (one-time)
npx cap add android
# Sync web files
npx cap sync android
# Open in Android Studio
npx cap open android
```

## 5) In Android Studio
- Ensure **compileSdk = 35** and **targetSdk = 35** in `android/app/build.gradle`
- App id (package): `com.qasim.readntype`
- Run ▶️ on a device/emulator

## 6) Create signed release (AAB)
- Android Studio → **Build > Generate Signed Bundle/APK… > Android App Bundle**
- Create a keystore (save the passwords)
- Upload the AAB to Google Play Console

## 7) Play Console checklist
- App listing (name, description, screenshots)
- Privacy Policy URL (host the policy text anywhere and link it)
- Data Safety (declare accurately; if no data collected, state that)
- Content rating + Target audience
- Ads declaration

## 8) Offline test
- After `npm run build` → `npm run preview`
- In browser DevTools → Application → check **Offline** → refresh; app should still load

— Prepared on 2025-08-21
