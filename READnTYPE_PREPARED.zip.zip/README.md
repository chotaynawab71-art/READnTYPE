
  # READnTYPE

  This is a code bundle for READnTYPE. The original project is available at https://www.figma.com/design/Lk3WuN8U8SxZudx7PDrA9C/READnTYPE.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  