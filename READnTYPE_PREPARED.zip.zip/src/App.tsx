import { useState, useEffect } from "react";
import { Card, CardContent } from "./components/ui/card";
import { Button } from "./components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./components/ui/tabs";
import { GoogleTranslateInterface } from "./components/GoogleTranslateInterface";
import { AdvancedToolsInterface } from "./components/AdvancedToolsInterface";
import { TranslationHistory } from "./components/TranslationHistory";
import { AuthModal } from "./components/AuthModal";
import { AuthProvider, useAuth } from "./components/AuthContext";
import { TranslationMode } from "./components/TranslationModeMenu";
import { TranslationBubble } from "./components/translation-bubble/TranslationBubble";
import { VoiceTranslate } from "./components/VoiceTranslate";
import { ImageTranslate } from "./components/ImageTranslate";
import { Transcribe } from "./components/Transcribe";
import { KeyboardTranslate } from "./components/KeyboardTranslate";
import { PDFTranslator } from "./components/PDFTranslator";
import { CamScanner } from "./components/CamScanner";
import { VirtualKeyboard } from "./components/VirtualKeyboard";
import { ScreenTranslatorSettings } from "./components/ScreenTranslatorSettings";
import { BookOpen, User, LogOut, Home, Zap, Type } from "lucide-react";

// BEGIN: simple privacy route
import Privacy from './Privacy';
const hash = typeof window !== 'undefined' ? window.location.hash : '';
if (hash === '#/privacy') {
  export default function App() { return <Privacy />; }
}
// END: simple privacy route

import { toast } from "sonner@2.0.3";
import { Toaster } from "./components/ui/sonner";
import { translationService, Translation, UserPreferences } from "./services/translationService";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "./components/ui/dropdown-menu";
import { Avatar, AvatarFallback } from "./components/ui/avatar";

function TranslationApp() {
  const { user, signOut, loading: authLoading } = useAuth();
  const [activeTab, setActiveTab] = useState<'translate' | 'tools'>('translate');
  const [activeMode, setActiveMode] = useState<TranslationMode | null>(null);
  const [sourceLang, setSourceLang] = useState("en");
  const [targetLang, setTargetLang] = useState("es");
  const [translations, setTranslations] = useState<Translation[]>([]);
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [userPreferences, setUserPreferences] = useState<UserPreferences>({
    defaultSourceLang: 'en',
    defaultTargetLang: 'es',
    maxHistoryItems: 50
  });
  const [isLoadingHistory, setIsLoadingHistory] = useState(false);
  const [isScreenTranslateActive, setIsScreenTranslateActive] = useState(false);

  // Load user data and preferences when user signs in
  useEffect(() => {
    if (user && !authLoading) {
      loadUserData();
    } else if (!user) {
      setTranslations([]);
      setUserPreferences({
        defaultSourceLang: 'en',
        defaultTargetLang: 'es',
        maxHistoryItems: 50
      });
      setSourceLang('en');
      setTargetLang('es');
    }
  }, [user, authLoading]);

  const loadUserData = async () => {
    try {
      setIsLoadingHistory(true);
      const [profileData, historyData] = await Promise.all([
        translationService.getUserProfile(),
        translationService.getTranslationHistory()
      ]);

      if (profileData.preferences) {
        setUserPreferences(profileData.preferences);
        setSourceLang(profileData.preferences.defaultSourceLang);
        setTargetLang(profileData.preferences.defaultTargetLang);
      }

      setTranslations(historyData.translations || []);
    } catch (error) {
      console.error('Error loading user data:', error);
      toast.error('Failed to load user data');
    } finally {
      setIsLoadingHistory(false);
    }
  };

  const handleToolSelect = (tool: TranslationMode) => {
    if (tool === 'screen') {
      setIsScreenTranslateActive(!isScreenTranslateActive);
      if (!isScreenTranslateActive) {
        toast.success('Screen translate activated - floating bubble mode');
      }
      return;
    }
    
    setActiveMode(tool);
    if (isScreenTranslateActive && tool !== 'screen') {
      setIsScreenTranslateActive(false);
    }
  };

  const saveTranslation = async (sourceText: string, translatedText: string) => {
    const translationType = activeMode || 'text';
    
    if (user) {
      try {
        const savedTranslation = await translationService.saveTranslation({
          sourceText,
          translatedText,
          sourceLang,
          targetLang,
          type: translationType as string
        });
        
        const newTranslation: Translation = savedTranslation.translation;
        setTranslations(prev => [newTranslation, ...prev.slice(0, userPreferences.maxHistoryItems - 1)]);
        
        toast.success("Translation saved!");
      } catch (error) {
        console.error('Error saving translation:', error);
        toast.success("Translation completed! (Failed to save to history)");
      }
    } else {
      const newTranslation: Translation = {
        id: Date.now().toString(),
        userId: 'local',
        sourceText,
        translatedText,
        sourceLang,
        targetLang,
        timestamp: new Date().toISOString(),
        type: translationType as string
      };
      
      setTranslations(prev => [newTranslation, ...prev.slice(0, 9)]);
      toast.success("Translation completed!");
    }
  };

  const handleLanguageChange = (source: string, target: string) => {
    setSourceLang(source);
    setTargetLang(target);
    
    // Save preferences if user is logged in
    if (user) {
      const newPreferences = {
        ...userPreferences,
        defaultSourceLang: source,
        defaultTargetLang: target
      };
      setUserPreferences(newPreferences);
      
      // Auto-save preferences (in real app, this would be debounced)
      setTimeout(() => {
        translationService.updateUserPreferences(newPreferences).catch(console.error);
      }, 1000);
    }
  };

  const handleClearHistory = async () => {
    if (user) {
      try {
        await translationService.clearTranslationHistory();
        setTranslations([]);
        toast.success("Translation history cleared");
      } catch (error) {
        console.error('Error clearing history:', error);
        toast.error("Failed to clear history");
      }
    } else {
      setTranslations([]);
      toast.success("Translation history cleared");
    }
  };

  const handleUseTranslation = (translation: Translation) => {
    setSourceLang(translation.sourceLang);
    setTargetLang(translation.targetLang);
    if (translation.type && translation.type !== 'text') {
      setActiveMode(translation.type as TranslationMode);
      setActiveTab('tools');
    }
  };

  const handleDeleteTranslation = async (translationId: string) => {
    if (user) {
      try {
        await translationService.deleteTranslation(translationId);
        setTranslations(prev => prev.filter(t => t.id !== translationId));
        toast.success("Translation deleted");
      } catch (error) {
        console.error('Error deleting translation:', error);
        toast.error("Failed to delete translation");
      }
    } else {
      setTranslations(prev => prev.filter(t => t.id !== translationId));
      toast.success("Translation deleted");
    }
  };

  const handleSignOut = async () => {
    try {
      await signOut();
      toast.success("Signed out successfully");
    } catch (error) {
      console.error('Sign out error:', error);
      toast.error("Failed to sign out");
    }
  };

  const handleBackToMain = () => {
    setActiveMode(null);
    setActiveTab('translate');
  };

  const renderToolContent = () => {
    switch (activeMode) {
      case 'voice':
        return (
          <VoiceTranslate
            sourceLang={sourceLang}
            targetLang={targetLang}
            onTranslation={saveTranslation}
          />
        );

      case 'image':
        return (
          <ImageTranslate
            sourceLang={sourceLang}
            targetLang={targetLang}
            onTranslation={saveTranslation}
          />
        );

      case 'transcribe':
        return (
          <Transcribe
            sourceLang={sourceLang}
            onTranscription={(text) => saveTranslation(text, `[Transcription]: ${text}`)}
          />
        );

      case 'keyboard':
        return (
          <KeyboardTranslate
            sourceLang={sourceLang}
            targetLang={targetLang}
            onTranslation={saveTranslation}
          />
        );

      case 'pdf':
        return (
          <PDFTranslator
            sourceLang={sourceLang}
            targetLang={targetLang}
            onTranslation={saveTranslation}
          />
        );

      case 'camscanner':
        return (
          <CamScanner
            sourceLang={sourceLang}
            targetLang={targetLang}
            onTranslation={saveTranslation}
          />
        );

      case 'virtual-keyboard':
        return (
          <VirtualKeyboard
            sourceLang={sourceLang}
            targetLang={targetLang}
            onTranslation={saveTranslation}
          />
        );

      case 'screen-settings':
        return (
          <ScreenTranslatorSettings
            sourceLang={sourceLang}
            targetLang={targetLang}
            onTranslation={saveTranslation}
          />
        );

      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      {/* Header */}
      <header className="bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 py-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 bg-gradient-to-br from-blue-600 to-purple-600 rounded-lg flex items-center justify-center">
                <BookOpen className="h-5 w-5 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-medium text-gray-900 dark:text-white">Read and Type</h1>
                <p className="text-xs text-gray-500 dark:text-gray-400">Translate • Read • Write</p>
              </div>
            </div>

            <div className="flex items-center gap-4">
              {activeMode && (
                <Button onClick={handleBackToMain} variant="ghost" size="sm">
                  <Home className="h-4 w-4 mr-2" />
                  Back
                </Button>
              )}
              
              {user ? (
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" className="relative h-8 w-8 rounded-full">
                      <Avatar className="h-8 w-8">
                        <AvatarFallback className="bg-gradient-to-br from-blue-600 to-purple-600 text-white">
                          {user.user_metadata?.name?.charAt(0)?.toUpperCase() || user.email?.charAt(0)?.toUpperCase()}
                        </AvatarFallback>
                      </Avatar>
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent className="w-56" align="end">
                    <div className="flex items-center justify-start gap-2 p-2">
                      <div className="flex flex-col space-y-1 leading-none">
                        <p className="font-medium text-sm">{user.user_metadata?.name || 'User'}</p>
                        <p className="w-[200px] truncate text-xs text-muted-foreground">
                          {user.email}
                        </p>
                      </div>
                    </div>
                    <DropdownMenuItem onClick={handleSignOut}>
                      <LogOut className="mr-2 h-4 w-4" />
                      Sign out
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              ) : (
                <Button onClick={() => setShowAuthModal(true)} variant="ghost" size="sm">
                  <User className="h-4 w-4 mr-2" />
                  Sign In
                </Button>
              )}
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto p-4">
        {activeMode ? (
          /* Tool Mode */
          <div className="space-y-6">
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={handleBackToMain}
                className="text-blue-600 hover:text-blue-700 p-0"
              >
                Read and Type
              </Button>
              <span>/</span>
              <span className="capitalize">{activeMode.replace('-', ' ')}</span>
            </div>
            {renderToolContent()}
          </div>
        ) : (
          /* Main Interface */
          <div className="grid lg:grid-cols-4 gap-6">
            <div className="lg:col-span-3">
              <Tabs value={activeTab} onValueChange={(value) => setActiveTab(value as 'translate' | 'tools')}>
                <TabsList className="grid w-full grid-cols-2 mb-6">
                  <TabsTrigger value="translate" className="flex items-center gap-2">
                    <Type className="h-4 w-4" />
                    Translate
                  </TabsTrigger>
                  <TabsTrigger value="tools" className="flex items-center gap-2">
                    <Zap className="h-4 w-4" />
                    Advanced Tools
                  </TabsTrigger>
                </TabsList>
                
                <TabsContent value="translate" className="space-y-6">
                  <GoogleTranslateInterface
                    sourceLang={sourceLang}
                    targetLang={targetLang}
                    onLanguageChange={handleLanguageChange}
                    onTranslation={saveTranslation}
                  />
                </TabsContent>
                
                <TabsContent value="tools" className="space-y-6">
                  <AdvancedToolsInterface
                    onToolSelect={handleToolSelect}
                    isScreenTranslateActive={isScreenTranslateActive}
                  />
                </TabsContent>
              </Tabs>
            </div>

            {/* History Sidebar */}
            <div className="lg:col-span-1">
              <TranslationHistory
                translations={translations}
                onClear={handleClearHistory}
                onUseTranslation={handleUseTranslation}
                onDeleteTranslation={user ? handleDeleteTranslation : undefined}
                isLoading={isLoadingHistory}
                isAuthenticated={!!user}
              />
            </div>
          </div>
        )}
      </div>

      {/* Translation Bubble for Screen Translate */}
      <TranslationBubble
        sourceLang={sourceLang}
        targetLang={targetLang}
        onLanguageChange={handleLanguageChange}
        onTranslation={saveTranslation}
        isActive={isScreenTranslateActive}
        onClose={() => setIsScreenTranslateActive(false)}
      />

      <AuthModal open={showAuthModal} onOpenChange={setShowAuthModal} />
      <Toaster />
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <TranslationApp />
    </AuthProvider>
  );
}