import { useState, useMemo } from "react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Popover, PopoverContent, PopoverTrigger } from "./ui/popover";
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from "./ui/command";
import { Badge } from "./ui/badge";
import { 
  Languages, 
  Search, 
  Star, 
  Globe,
  Check,
  ChevronDown,
  Heart,
  MapPin
} from "lucide-react";
import { toast } from "sonner@2.0.3";

interface Language {
  code: string;
  name: string;
  nativeName: string;
  region: string;
  flag: string;
}

const LANGUAGES: Language[] = [
  // Major World Languages
  { code: 'en', name: 'English', nativeName: 'English', region: 'Global', flag: '🇺🇸' },
  { code: 'es', name: 'Spanish', nativeName: 'Español', region: 'Europe/Americas', flag: '🇪🇸' },
  { code: 'fr', name: 'French', nativeName: 'Français', region: 'Europe/Africa', flag: '🇫🇷' },
  { code: 'de', name: 'German', nativeName: 'Deutsch', region: 'Europe', flag: '🇩🇪' },
  { code: 'it', name: 'Italian', nativeName: 'Italiano', region: 'Europe', flag: '🇮🇹' },
  { code: 'pt', name: 'Portuguese', nativeName: 'Português', region: 'Europe/Americas', flag: '🇵🇹' },
  { code: 'ru', name: 'Russian', nativeName: 'Русский', region: 'Europe/Asia', flag: '🇷🇺' },
  { code: 'zh', name: 'Chinese (Simplified)', nativeName: '简体中文', region: 'Asia', flag: '🇨🇳' },
  { code: 'zh-tw', name: 'Chinese (Traditional)', nativeName: '繁體中文', region: 'Asia', flag: '🇹🇼' },
  { code: 'ja', name: 'Japanese', nativeName: '日本語', region: 'Asia', flag: '🇯🇵' },
  { code: 'ko', name: 'Korean', nativeName: '한국어', region: 'Asia', flag: '🇰🇷' },
  
  // South Asian Languages
  { code: 'ur', name: 'Urdu', nativeName: 'اردو', region: 'South Asia', flag: '🇵🇰' },
  { code: 'hi', name: 'Hindi', nativeName: 'हिन्दी', region: 'South Asia', flag: '🇮🇳' },
  { code: 'pa', name: 'Punjabi', nativeName: 'ਪੰਜਾਬੀ', region: 'South Asia', flag: '🇮🇳' },
  { code: 'sd', name: 'Sindhi', nativeName: 'سنڌي', region: 'South Asia', flag: '🇵🇰' },
  { code: 'skr', name: 'Saraiki', nativeName: 'سرائیکی', region: 'South Asia', flag: '🇵🇰' },
  { code: 'bn', name: 'Bengali', nativeName: 'বাংলা', region: 'South Asia', flag: '🇧🇩' },
  { code: 'ta', name: 'Tamil', nativeName: 'தமிழ்', region: 'South Asia', flag: '🇮🇳' },
  { code: 'te', name: 'Telugu', nativeName: 'తెలుగు', region: 'South Asia', flag: '🇮🇳' },
  { code: 'ml', name: 'Malayalam', nativeName: 'മലയാളം', region: 'South Asia', flag: '🇮🇳' },
  { code: 'kn', name: 'Kannada', nativeName: 'ಕನ್ನಡ', region: 'South Asia', flag: '🇮🇳' },
  { code: 'gu', name: 'Gujarati', nativeName: 'ગુજરાતી', region: 'South Asia', flag: '🇮🇳' },
  { code: 'mr', name: 'Marathi', nativeName: 'मराठी', region: 'South Asia', flag: '🇮🇳' },
  { code: 'ne', name: 'Nepali', nativeName: 'नेपाली', region: 'South Asia', flag: '🇳🇵' },
  { code: 'si', name: 'Sinhala', nativeName: 'සිංහල', region: 'South Asia', flag: '🇱🇰' },
  
  // Southeast Asian Languages
  { code: 'th', name: 'Thai', nativeName: 'ไทย', region: 'Southeast Asia', flag: '🇹🇭' },
  { code: 'vi', name: 'Vietnamese', nativeName: 'Tiếng Việt', region: 'Southeast Asia', flag: '🇻🇳' },
  { code: 'id', name: 'Indonesian', nativeName: 'Bahasa Indonesia', region: 'Southeast Asia', flag: '🇮🇩' },
  { code: 'ms', name: 'Malay', nativeName: 'Bahasa Melayu', region: 'Southeast Asia', flag: '🇲🇾' },
  { code: 'tl', name: 'Filipino', nativeName: 'Filipino', region: 'Southeast Asia', flag: '🇵🇭' },
  { code: 'my', name: 'Myanmar', nativeName: 'မြန်မာ', region: 'Southeast Asia', flag: '🇲🇲' },
  { code: 'km', name: 'Khmer', nativeName: 'ខ្មែរ', region: 'Southeast Asia', flag: '🇰🇭' },
  { code: 'lo', name: 'Lao', nativeName: 'ລາວ', region: 'Southeast Asia', flag: '🇱🇦' },
  
  // Middle Eastern Languages
  { code: 'ar', name: 'Arabic', nativeName: 'العربية', region: 'Middle East', flag: '🇸🇦' },
  { code: 'fa', name: 'Persian', nativeName: 'فارسی', region: 'Middle East', flag: '🇮🇷' },
  { code: 'tr', name: 'Turkish', nativeName: 'Türkçe', region: 'Middle East', flag: '🇹🇷' },
  { code: 'he', name: 'Hebrew', nativeName: 'עברית', region: 'Middle East', flag: '🇮🇱' },
  { code: 'ku', name: 'Kurdish', nativeName: 'کوردی', region: 'Middle East', flag: '🏴' },
  
  // East Asian Languages
  { code: 'mn', name: 'Mongolian', nativeName: 'Монгол', region: 'East Asia', flag: '🇲🇳' },
  { code: 'ti', name: 'Tibetan', nativeName: 'བོད་ཡིག', region: 'Asia', flag: '🏔️' },
  
  // African Languages
  { code: 'sw', name: 'Swahili', nativeName: 'Kiswahili', region: 'Africa', flag: '🇰🇪' },
  { code: 'am', name: 'Amharic', nativeName: 'አማርኛ', region: 'Africa', flag: '🇪🇹' },
  { code: 'yo', name: 'Yoruba', nativeName: 'Yorùbá', region: 'Africa', flag: '🇳🇬' },
  { code: 'zu', name: 'Zulu', nativeName: 'isiZulu', region: 'Africa', flag: '🇿🇦' },
  
  // European Languages
  { code: 'pl', name: 'Polish', nativeName: 'Polski', region: 'Europe', flag: '🇵🇱' },
  { code: 'uk', name: 'Ukrainian', nativeName: 'Українська', region: 'Europe', flag: '🇺🇦' },
  { code: 'cs', name: 'Czech', nativeName: 'Čeština', region: 'Europe', flag: '🇨🇿' },
  { code: 'hu', name: 'Hungarian', nativeName: 'Magyar', region: 'Europe', flag: '🇭🇺' },
  { code: 'ro', name: 'Romanian', nativeName: 'Română', region: 'Europe', flag: '🇷🇴' },
  { code: 'bg', name: 'Bulgarian', nativeName: 'Български', region: 'Europe', flag: '🇧🇬' },
  { code: 'hr', name: 'Croatian', nativeName: 'Hrvatski', region: 'Europe', flag: '🇭🇷' },
  { code: 'sr', name: 'Serbian', nativeName: 'Српски', region: 'Europe', flag: '🇷🇸' },
  { code: 'sk', name: 'Slovak', nativeName: 'Slovenčina', region: 'Europe', flag: '🇸🇰' },
  { code: 'sl', name: 'Slovenian', nativeName: 'Slovenščina', region: 'Europe', flag: '🇸🇮' },
  { code: 'et', name: 'Estonian', nativeName: 'Eesti', region: 'Europe', flag: '🇪🇪' },
  { code: 'lv', name: 'Latvian', nativeName: 'Latviešu', region: 'Europe', flag: '🇱🇻' },
  { code: 'lt', name: 'Lithuanian', nativeName: 'Lietuvių', region: 'Europe', flag: '🇱🇹' },
  { code: 'nl', name: 'Dutch', nativeName: 'Nederlands', region: 'Europe', flag: '🇳🇱' },
  { code: 'da', name: 'Danish', nativeName: 'Dansk', region: 'Europe', flag: '🇩🇰' },
  { code: 'sv', name: 'Swedish', nativeName: 'Svenska', region: 'Europe', flag: '🇸🇪' },
  { code: 'no', name: 'Norwegian', nativeName: 'Norsk', region: 'Europe', flag: '🇳🇴' },
  { code: 'fi', name: 'Finnish', nativeName: 'Suomi', region: 'Europe', flag: '🇫🇮' },
  { code: 'is', name: 'Icelandic', nativeName: 'Íslenska', region: 'Europe', flag: '🇮🇸' }
];

interface EnhancedLanguageSelectorProps {
  value: string;
  onValueChange: (value: string) => void;
  placeholder?: string;
  disabled?: boolean;
}

export function EnhancedLanguageSelector({ 
  value, 
  onValueChange, 
  placeholder = "Select language",
  disabled = false 
}: EnhancedLanguageSelectorProps) {
  const [open, setOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [favorites, setFavorites] = useState<string[]>(['en', 'es', 'ur', 'hi', 'pa', 'ar']);
  const [selectedRegion, setSelectedRegion] = useState<string>('all');

  const regions = useMemo(() => {
    const uniqueRegions = [...new Set(LANGUAGES.map(lang => lang.region))];
    return ['all', ...uniqueRegions.sort()];
  }, []);

  const filteredLanguages = useMemo(() => {
    let filtered = LANGUAGES;

    // Filter by region
    if (selectedRegion !== 'all') {
      filtered = filtered.filter(lang => lang.region === selectedRegion);
    }

    // Filter by search term
    if (searchTerm) {
      filtered = filtered.filter(lang => 
        lang.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        lang.nativeName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        lang.code.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    // Sort favorites first, then alphabetically
    return filtered.sort((a, b) => {
      const aIsFavorite = favorites.includes(a.code);
      const bIsFavorite = favorites.includes(b.code);
      
      if (aIsFavorite && !bIsFavorite) return -1;
      if (!aIsFavorite && bIsFavorite) return 1;
      
      return a.name.localeCompare(b.name);
    });
  }, [searchTerm, selectedRegion, favorites]);

  const selectedLanguage = LANGUAGES.find(lang => lang.code === value);

  const toggleFavorite = (langCode: string) => {
    setFavorites(prev => {
      const newFavorites = prev.includes(langCode)
        ? prev.filter(code => code !== langCode)
        : [...prev, langCode];
      
      // Save to localStorage
      localStorage.setItem('favoriteLanguages', JSON.stringify(newFavorites));
      
      toast.success(
        prev.includes(langCode) 
          ? "Removed from favorites" 
          : "Added to favorites"
      );
      
      return newFavorites;
    });
  };

  // Load favorites from localStorage on mount
  useState(() => {
    const saved = localStorage.getItem('favoriteLanguages');
    if (saved) {
      try {
        setFavorites(JSON.parse(saved));
      } catch (error) {
        console.error('Failed to load favorite languages:', error);
      }
    }
  });

  const favoriteLanguages = LANGUAGES.filter(lang => favorites.includes(lang.code));

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button
          variant="outline"
          role="combobox"
          aria-expanded={open}
          className="justify-between"
          disabled={disabled}
        >
          <div className="flex items-center gap-2">
            {selectedLanguage ? (
              <>
                <span className="text-lg">{selectedLanguage.flag}</span>
                <div className="flex flex-col items-start">
                  <span className="text-sm">{selectedLanguage.name}</span>
                  <span className="text-xs text-muted-foreground">{selectedLanguage.nativeName}</span>
                </div>
              </>
            ) : (
              <>
                <Languages className="h-4 w-4" />
                <span>{placeholder}</span>
              </>
            )}
          </div>
          <ChevronDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-80 p-0" align="start">
        <div className="border-b p-3">
          <div className="flex items-center gap-2 mb-2">
            <Search className="h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search languages..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="h-8"
            />
          </div>
          
          {/* Region Filter */}
          <div className="flex flex-wrap gap-1">
            {regions.map((region) => (
              <Badge
                key={region}
                variant={selectedRegion === region ? "default" : "outline"}
                className="cursor-pointer text-xs"
                onClick={() => setSelectedRegion(region)}
              >
                {region === 'all' ? (
                  <>
                    <Globe className="h-3 w-3 mr-1" />
                    All
                  </>
                ) : (
                  <>
                    <MapPin className="h-3 w-3 mr-1" />
                    {region}
                  </>
                )}
              </Badge>
            ))}
          </div>
        </div>

        {/* Favorites Section */}
        {favoriteLanguages.length > 0 && searchTerm === '' && selectedRegion === 'all' && (
          <div className="border-b">
            <div className="p-2">
              <h4 className="flex items-center gap-2 text-sm font-medium text-muted-foreground mb-2">
                <Star className="h-3 w-3" />
                Favorites
              </h4>
              <div className="space-y-1">
                {favoriteLanguages.map((language) => (
                  <div
                    key={language.code}
                    className={`flex items-center justify-between p-2 rounded cursor-pointer hover:bg-accent ${
                      value === language.code ? 'bg-accent' : ''
                    }`}
                    onClick={() => {
                      onValueChange(language.code);
                      setOpen(false);
                    }}
                  >
                    <div className="flex items-center gap-3">
                      <span className="text-lg">{language.flag}</span>
                      <div className="flex flex-col">
                        <div className="flex items-center gap-2">
                          <span className="text-sm font-medium">{language.name}</span>
                          {value === language.code && <Check className="h-3 w-3" />}
                        </div>
                        <span className="text-xs text-muted-foreground">{language.nativeName}</span>
                      </div>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-6 w-6 p-0"
                      onClick={(e) => {
                        e.stopPropagation();
                        toggleFavorite(language.code);
                      }}
                    >
                      <Heart className="h-3 w-3 fill-red-500 text-red-500" />
                    </Button>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* All Languages */}
        <Command>
          <CommandList className="max-h-60">
            <CommandEmpty>No languages found.</CommandEmpty>
            <CommandGroup>
              {filteredLanguages.map((language) => (
                <CommandItem
                  key={language.code}
                  value={`${language.name} ${language.nativeName} ${language.code}`}
                  onSelect={() => {
                    onValueChange(language.code);
                    setOpen(false);
                  }}
                  className="flex items-center justify-between"
                >
                  <div className="flex items-center gap-3">
                    <span className="text-lg">{language.flag}</span>
                    <div className="flex flex-col">
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-medium">{language.name}</span>
                        {value === language.code && <Check className="h-3 w-3" />}
                        {favorites.includes(language.code) && (
                          <Star className="h-3 w-3 fill-yellow-400 text-yellow-400" />
                        )}
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs text-muted-foreground">{language.nativeName}</span>
                        <Badge variant="outline" className="text-xs px-1 py-0">
                          {language.region}
                        </Badge>
                      </div>
                    </div>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-6 w-6 p-0"
                    onClick={(e) => {
                      e.stopPropagation();
                      toggleFavorite(language.code);
                    }}
                  >
                    {favorites.includes(language.code) ? (
                      <Heart className="h-3 w-3 fill-red-500 text-red-500" />
                    ) : (
                      <Heart className="h-3 w-3" />
                    )}
                  </Button>
                </CommandItem>
              ))}
            </CommandGroup>
          </CommandList>
        </Command>
      </PopoverContent>
    </Popover>
  );
}