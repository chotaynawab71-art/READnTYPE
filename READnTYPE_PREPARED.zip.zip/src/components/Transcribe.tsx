import { useState, useRef, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Mic, MicOff, Download, Copy, Trash2, Play, Pause } from "lucide-react";
import { toast } from "sonner@2.0.3";

interface TranscribeProps {
  sourceLang: string;
  onTranscription: (text: string) => void;
}

export function Transcribe({ sourceLang, onTranscription }: TranscribeProps) {
  const [isRecording, setIsRecording] = useState(false);
  const [transcriptSegments, setTranscriptSegments] = useState<Array<{
    id: string;
    text: string;
    timestamp: string;
    isFinal: boolean;
  }>>([]);
  const [currentTranscript, setCurrentTranscript] = useState("");
  const [recordingDuration, setRecordingDuration] = useState(0);
  const recognitionRef = useRef<SpeechRecognition | null>(null);
  const durationIntervalRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    // Check if speech recognition is supported
    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
      recognitionRef.current = new SpeechRecognition();
      recognitionRef.current.continuous = true;
      recognitionRef.current.interimResults = true;
      recognitionRef.current.lang = getLanguageCode(sourceLang);

      recognitionRef.current.onresult = (event) => {
        let interimTranscript = '';
        let finalTranscript = '';

        for (let i = event.resultIndex; i < event.results.length; i++) {
          const transcript = event.results[i][0].transcript;
          if (event.results[i].isFinal) {
            finalTranscript += transcript;
            // Add final transcript as a segment
            const segment = {
              id: `${Date.now()}-${i}`,
              text: transcript,
              timestamp: new Date().toLocaleTimeString(),
              isFinal: true
            };
            setTranscriptSegments(prev => [...prev, segment]);
            onTranscription(transcript);
          } else {
            interimTranscript += transcript;
          }
        }

        setCurrentTranscript(interimTranscript);
      };

      recognitionRef.current.onerror = (event) => {
        console.error('Speech recognition error:', event.error);
        toast.error('Speech recognition failed');
        setIsRecording(false);
        if (durationIntervalRef.current) {
          clearInterval(durationIntervalRef.current);
        }
      };

      recognitionRef.current.onend = () => {
        setIsRecording(false);
        setCurrentTranscript("");
        if (durationIntervalRef.current) {
          clearInterval(durationIntervalRef.current);
        }
      };
    }

    return () => {
      if (recognitionRef.current) {
        recognitionRef.current.stop();
      }
      if (durationIntervalRef.current) {
        clearInterval(durationIntervalRef.current);
      }
    };
  }, [sourceLang]);

  const getLanguageCode = (lang: string) => {
    const langMap: Record<string, string> = {
      'en': 'en-US',
      'es': 'es-ES',
      'fr': 'fr-FR',
      'de': 'de-DE',
      'it': 'it-IT',
      'pt': 'pt-PT',
      'ru': 'ru-RU',
      'ja': 'ja-JP',
      'ko': 'ko-KR',
      'zh': 'zh-CN',
      'ar': 'ar-SA',
      'hi': 'hi-IN',
    };
    return langMap[lang] || 'en-US';
  };

  const startRecording = () => {
    if (!recognitionRef.current) {
      toast.error('Speech recognition not supported in this browser');
      return;
    }

    setIsRecording(true);
    setRecordingDuration(0);
    recognitionRef.current.start();
    
    durationIntervalRef.current = setInterval(() => {
      setRecordingDuration(prev => prev + 1);
    }, 1000);

    toast.success('Recording started...');
  };

  const stopRecording = () => {
    if (recognitionRef.current) {
      recognitionRef.current.stop();
    }
    setIsRecording(false);
    if (durationIntervalRef.current) {
      clearInterval(durationIntervalRef.current);
    }
    toast.success('Recording stopped');
  };

  const clearTranscription = () => {
    setTranscriptSegments([]);
    setCurrentTranscript("");
    setRecordingDuration(0);
    toast.success('Transcription cleared');
  };

  const copyToClipboard = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      toast.success("Copied to clipboard");
    } catch {
      toast.error("Failed to copy");
    }
  };

  const downloadTranscription = () => {
    const fullText = transcriptSegments.map(segment => 
      `[${segment.timestamp}] ${segment.text}`
    ).join('\n');
    
    const blob = new Blob([fullText], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `transcription-${new Date().toISOString().split('T')[0]}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    toast.success('Transcription downloaded');
  };

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const fullTranscript = transcriptSegments.map(s => s.text).join(' ');

  return (
    <div className="space-y-6">
      {/* Recording Controls */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            Audio Transcription
            <div className="flex items-center gap-2">
              {isRecording && (
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse"></div>
                  {formatDuration(recordingDuration)}
                </div>
              )}
              <Button
                onClick={isRecording ? stopRecording : startRecording}
                variant={isRecording ? "destructive" : "default"}
                size="lg"
                className="rounded-full h-12 w-12 p-0"
              >
                {isRecording ? (
                  <MicOff className="h-6 w-6" />
                ) : (
                  <Mic className="h-6 w-6" />
                )}
              </Button>
            </div>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex gap-2">
              <Button
                onClick={startRecording}
                disabled={isRecording}
                variant="outline"
              >
                <Play className="h-4 w-4 mr-2" />
                Start Recording
              </Button>
              <Button
                onClick={stopRecording}
                disabled={!isRecording}
                variant="outline"
              >
                <Pause className="h-4 w-4 mr-2" />
                Stop Recording
              </Button>
              <Button
                onClick={clearTranscription}
                disabled={transcriptSegments.length === 0}
                variant="outline"
              >
                <Trash2 className="h-4 w-4 mr-2" />
                Clear
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Live Transcription */}
      {(isRecording || currentTranscript) && (
        <Card>
          <CardHeader>
            <CardTitle>Live Transcription</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="min-h-16 p-4 border rounded-lg bg-muted/30">
              {isRecording && (
                <div className="flex items-center gap-2 mb-2">
                  <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse"></div>
                  <span className="text-sm text-muted-foreground">Listening...</span>
                </div>
              )}
              {currentTranscript ? (
                <p className="whitespace-pre-wrap text-muted-foreground italic">
                  {currentTranscript}
                </p>
              ) : isRecording ? (
                <p className="text-muted-foreground">Speak now...</p>
              ) : (
                <p className="text-muted-foreground">Click the microphone to start recording</p>
              )}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Transcription Results */}
      {transcriptSegments.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              Transcription Results
              <div className="flex gap-2">
                <Button
                  onClick={() => copyToClipboard(fullTranscript)}
                  variant="outline"
                  size="sm"
                >
                  <Copy className="h-4 w-4 mr-2" />
                  Copy
                </Button>
                <Button
                  onClick={downloadTranscription}
                  variant="outline"
                  size="sm"
                >
                  <Download className="h-4 w-4 mr-2" />
                  Download
                </Button>
              </div>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="max-h-96 overflow-y-auto space-y-2">
              {transcriptSegments.map((segment) => (
                <div key={segment.id} className="flex items-start gap-3 p-3 border rounded-lg">
                  <span className="text-xs text-muted-foreground font-mono shrink-0">
                    {segment.timestamp}
                  </span>
                  <p className="flex-1">{segment.text}</p>
                  <Button
                    onClick={() => copyToClipboard(segment.text)}
                    variant="ghost"
                    size="sm"
                    className="h-6 w-6 p-0 shrink-0"
                  >
                    <Copy className="h-3 w-3" />
                  </Button>
                </div>
              ))}
            </div>
            <div className="text-sm text-muted-foreground border-t pt-4">
              Total: {transcriptSegments.length} segments • {fullTranscript.length} characters
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}