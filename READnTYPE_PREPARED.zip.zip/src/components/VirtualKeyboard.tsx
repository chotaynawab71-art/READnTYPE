import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Textarea } from "./ui/textarea";
import { Input } from "./ui/input";
import { EnhancedLanguageSelector } from "./EnhancedLanguageSelector";
import { 
  Keyboard, 
  Type, 
  Copy, 
  RotateCcw, 
  Download,
  Globe,
  BookOpen,
  Lightbulb,
  Mic,
  Settings,
  ArrowLeft,
  Space,
  Search,
  Zap
} from "lucide-react";
import { toast } from "sonner@2.0.3";

interface VirtualKeyboardProps {
  sourceLang: string;
  targetLang: string;
  onTranslation: (sourceText: string, translatedText: string) => void;
}

interface KeyboardLayout {
  id: string;
  name: string;
  language: string;
  rows: string[][];
  suggestions: string[];
  autocomplete: Record<string, string[]>;
}

const keyboardLayouts: Record<string, KeyboardLayout> = {
  'urdu': {
    id: 'urdu',
    name: 'Urdu',
    language: 'ur',
    rows: [
      ['ض', 'ص', 'ث', 'ق', 'ف', 'غ', 'ع', 'ہ', 'خ', 'ح', 'ج', 'چ'],
      ['ش', 'س', 'ی', 'ب', 'ل', 'ا', 'ت', 'ن', 'م', 'ک', 'گ'],
      ['ظ', 'ط', 'ز', 'ر', 'ذ', 'د', 'پ', 'و', '۔', '؍']
    ],
    suggestions: ['سلام', 'شکریہ', 'آپ کیسے ہیں', 'معاف کریں', 'خوش آمدید'],
    autocomplete: {
      'س': ['سلام', 'شکریہ', 'صبح بخیر'],
      'آ': ['آپ', 'آج', 'آمدید'],
      'ک': ['کیسے', 'کیا', 'کوئی']
    }
  },
  'punjabi': {
    id: 'punjabi',
    name: 'Punjabi (Gurmukhi)',
    language: 'pa',
    rows: [
      ['ੌ', 'ੈ', 'ਾ', 'ੀ', 'ੂ', 'ਬ', 'ਹ', 'ਗ', 'ਦ', 'ਜ', 'ਡ'],
      ['ੋ', 'ੇ', 'ੁ', 'ਿ', 'ੁ', 'ਪ', 'ਰ', 'ਕ', 'ਤ', 'ਚ', 'ਟ'],
      ['ਅ', 'ਸ', 'ਮ', 'ਨ', 'ਵ', 'ਲ', 'ਯ', '।', '॥']
    ],
    suggestions: ['ਸਤ ਸ੍ਰੀ ਅਕਾਲ', 'ਧੰਨਵਾਦ', 'ਤੁਸੀਂ ਕਿਵੇਂ ਹੋ', 'ਮਾਫ਼ ਕਰਨਾ', 'ਜੀ ਆਇਆਂ ਨੂੰ'],
    autocomplete: {
      'ਸ': ['ਸਤ', 'ਸਿੰਘ', 'ਸਮਾਂ'],
      'ਤ': ['ਤੁਸੀਂ', 'ਤੇ', 'ਤਕ'],
      'ਕ': ['ਕੀ', 'ਕਿਸੇ', 'ਕਰਨਾ']
    }
  },
  'arabic': {
    id: 'arabic',
    name: 'Arabic',
    language: 'ar',
    rows: [
      ['ض', 'ص', 'ث', 'ق', 'ف', 'غ', 'ع', 'ه', 'خ', 'ح', 'ج'],
      ['ش', 'س', 'ي', 'ب', 'ل', 'ا', 'ت', 'ن', 'م', 'ك'],
      ['ظ', 'ط', 'ذ', 'د', 'ز', 'ر', 'و', '؍', '.']
    ],
    suggestions: ['السلام عليكم', 'شكرا', 'كيف حالك', 'معذرة', 'أهلا وسهلا'],
    autocomplete: {
      'س': ['السلام', 'شكرا', 'سعيد'],
      'ك': ['كيف', 'كان', 'كل'],
      'أ': ['أهلا', 'أنا', 'أين']
    }
  },
  'hindi': {
    id: 'hindi',
    name: 'Hindi (Devanagari)',
    language: 'hi',
    rows: [
      ['औ', 'ऐ', 'आ', 'ई', 'ऊ', 'ब', 'ह', 'ग', 'द', 'ज', 'ड'],
      ['ो', 'े', 'ा', 'ि', 'ु', 'प', 'र', 'क', 'त', 'च', 'ट'],
      ['अ', 'स', 'म', 'न', 'व', 'ल', 'य', '।', '॥']
    ],
    suggestions: ['नमस्ते', 'धन्यवाद', 'आप कैसे हैं', 'माफ करें', 'स्वागत है'],
    autocomplete: {
      'न': ['नमस्ते', 'नाम', 'नहीं'],
      'आ': ['आप', 'आज', 'आना'],
      'क': ['कैसे', 'क्या', 'कोई']
    }
  }
};

export function VirtualKeyboard({ sourceLang, targetLang, onTranslation }: VirtualKeyboardProps) {
  const [selectedLayout, setSelectedLayout] = useState<KeyboardLayout>(keyboardLayouts['urdu']);
  const [inputText, setInputText] = useState("");
  const [translatedText, setTranslatedText] = useState("");
  const [isTranslating, setIsTranslating] = useState(false);
  const [suggestions, setSuggestions] = useState<string[]>([]);
  const [currentWord, setCurrentWord] = useState("");
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [autoCorrectEnabled, setAutoCorrectEnabled] = useState(true);
  const [predictionEnabled, setPredictionEnabled] = useState(true);

  // Update suggestions based on current input
  useEffect(() => {
    const words = inputText.split(' ');
    const lastWord = words[words.length - 1];
    setCurrentWord(lastWord);

    if (lastWord && predictionEnabled) {
      const matchingSuggestions = selectedLayout.suggestions.filter(
        suggestion => suggestion.startsWith(lastWord)
      );
      
      // Add autocomplete suggestions
      const autocompleteSuggestions = selectedLayout.autocomplete[lastWord] || [];
      
      const allSuggestions = [...new Set([...matchingSuggestions, ...autocompleteSuggestions])];
      setSuggestions(allSuggestions.slice(0, 6)); // Limit to 6 suggestions
      setShowSuggestions(allSuggestions.length > 0);
    } else {
      setSuggestions(selectedLayout.suggestions.slice(0, 6));
      setShowSuggestions(false);
    }
  }, [inputText, selectedLayout, predictionEnabled]);

  // Live translation
  useEffect(() => {
    if (inputText.trim()) {
      const timeoutId = setTimeout(() => {
        handleTranslate();
      }, 1000);
      return () => clearTimeout(timeoutId);
    } else {
      setTranslatedText("");
    }
  }, [inputText, sourceLang, targetLang]);

  const handleKeyPress = (key: string) => {
    setInputText(prev => prev + key);
  };

  const handleSpace = () => {
    setInputText(prev => prev + ' ');
    setShowSuggestions(false);
  };

  const handleBackspace = () => {
    setInputText(prev => prev.slice(0, -1));
  };

  const handleClear = () => {
    setInputText("");
    setTranslatedText("");
    setSuggestions([]);
    setShowSuggestions(false);
  };

  const handleSuggestionClick = (suggestion: string) => {
    const words = inputText.split(' ');
    words[words.length - 1] = suggestion;
    setInputText(words.join(' ') + ' ');
    setShowSuggestions(false);
  };

  const handleTranslate = async () => {
    if (!inputText.trim()) return;

    setIsTranslating(true);
    
    // Simulate translation delay
    await new Promise(resolve => setTimeout(resolve, 500));
    
    // Mock translation based on source language
    const mockTranslations: Record<string, string> = {
      'ur': 'This is a sample Urdu text translated to English with GBoard-style input.',
      'pa': 'This is a sample Punjabi text translated to English with GBoard-style input.',
      'ar': 'This is a sample Arabic text translated to English with GBoard-style input.',
      'hi': 'This is a sample Hindi text translated to English with GBoard-style input.'
    };

    const translated = mockTranslations[selectedLayout.language] || `Translated: ${inputText}`;
    setTranslatedText(translated);
    setIsTranslating(false);
    
    onTranslation(inputText, translated);
  };

  const copyToClipboard = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      toast.success("Copied to clipboard");
    } catch {
      toast.error("Failed to copy");
    }
  };

  const downloadText = () => {
    const content = `Original (${selectedLayout.name}):\n${inputText}\n\nTranslated:\n${translatedText}`;
    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'gboard_translation.txt';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    toast.success("Text downloaded successfully");
  };

  const handleVoiceInput = () => {
    toast.info("Voice input activated for " + selectedLayout.name);
    setTimeout(() => {
      setInputText(inputText + "یہ آواز سے لکھا گیا متن ہے۔ ");
      toast.success("Voice input completed");
    }, 2000);
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Keyboard className="h-5 w-5" />
            GBoard Virtual Keyboard
            <Badge variant="secondary">AI-Powered</Badge>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Keyboard Language & Settings */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="space-y-2">
                <label className="text-sm font-medium flex items-center gap-2">
                  <Globe className="h-4 w-4" />
                  Keyboard Language
                </label>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                  {Object.values(keyboardLayouts).map((layout) => (
                    <Button
                      key={layout.id}
                      variant={selectedLayout.id === layout.id ? "default" : "outline"}
                      size="sm"
                      onClick={() => setSelectedLayout(layout)}
                      className="justify-start"
                    >
                      <BookOpen className="h-3 w-3 mr-2" />
                      {layout.name}
                    </Button>
                  ))}
                </div>
              </div>
            </div>
            
            <div className="flex items-center gap-2">
              <Button
                variant={autoCorrectEnabled ? "default" : "outline"}
                size="sm"
                onClick={() => setAutoCorrectEnabled(!autoCorrectEnabled)}
              >
                <Zap className="h-3 w-3 mr-1" />
                AutoCorrect
              </Button>
              <Button
                variant={predictionEnabled ? "default" : "outline"}
                size="sm"
                onClick={() => setPredictionEnabled(!predictionEnabled)}
              >
                <Lightbulb className="h-3 w-3 mr-1" />
                Predictions
              </Button>
            </div>
          </div>

          {/* Suggestions Bar */}
          {(showSuggestions || suggestions.length > 0) && (
            <div className="space-y-2">
              <label className="text-sm font-medium flex items-center gap-2">
                <Lightbulb className="h-4 w-4" />
                {showSuggestions ? "Smart Suggestions" : "Quick Phrases"}
              </label>
              <div className="flex gap-2 flex-wrap">
                {suggestions.map((suggestion, index) => (
                  <Button
                    key={index}
                    variant="outline"
                    size="sm"
                    onClick={() => handleSuggestionClick(suggestion)}
                    className="text-sm hover:bg-blue-50 hover:border-blue-300"
                  >
                    {suggestion}
                  </Button>
                ))}
              </div>
            </div>
          )}

          {/* GBoard-style Virtual Keyboard */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="font-medium flex items-center gap-2">
                <Type className="h-4 w-4" />
                {selectedLayout.name} Keyboard
              </h4>
              <div className="flex items-center gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handleVoiceInput}
                  className="h-8 w-8 p-0"
                >
                  <Mic className="h-3 w-3" />
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  className="h-8 w-8 p-0"
                >
                  <Settings className="h-3 w-3" />
                </Button>
              </div>
            </div>
            
            <div className="space-y-2 p-4 bg-gradient-to-b from-gray-100 to-gray-200 dark:from-gray-800 dark:to-gray-900 rounded-lg shadow-inner">
              {selectedLayout.rows.map((row, rowIndex) => (
                <div key={rowIndex} className="flex gap-1 justify-center">
                  {row.map((key, keyIndex) => (
                    <Button
                      key={keyIndex}
                      variant="outline"
                      size="sm"
                      onClick={() => handleKeyPress(key)}
                      className="min-w-[45px] h-12 text-lg font-medium bg-white dark:bg-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600 shadow-sm border-gray-300 dark:border-gray-600"
                    >
                      {key}
                    </Button>
                  ))}
                </div>
              ))}
              
              {/* Special Keys Row */}
              <div className="flex gap-1 justify-center">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => handleKeyPress('123')}
                  className="px-4 h-12 bg-gray-200 dark:bg-gray-600"
                >
                  123
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handleSpace}
                  className="px-16 h-12 bg-white dark:bg-gray-700 flex items-center gap-2"
                >
                  <Space className="h-4 w-4" />
                  Space
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handleBackspace}
                  className="px-4 h-12 bg-gray-200 dark:bg-gray-600"
                >
                  <ArrowLeft className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>

          {/* Text Input Area */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <label className="text-sm font-medium">Input Text ({selectedLayout.name})</label>
              <div className="flex gap-2">
                <Button size="sm" variant="outline" onClick={() => copyToClipboard(inputText)} disabled={!inputText}>
                  <Copy className="h-3 w-3 mr-1" />
                  Copy
                </Button>
                <Button size="sm" variant="outline" onClick={handleClear} disabled={!inputText}>
                  <RotateCcw className="h-3 w-3 mr-1" />
                  Clear
                </Button>
              </div>
            </div>
            <Textarea
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder={`Type in ${selectedLayout.name} using the virtual keyboard above or direct input...`}
              className="min-h-[120px] text-lg"
              dir={['ar', 'ur', 'sd'].includes(selectedLayout.language) ? 'rtl' : 'ltr'}
            />
          </div>

          {/* Translation Result */}
          {(translatedText || isTranslating) && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <label className="text-sm font-medium">Live Translation ({targetLang.toUpperCase()})</label>
                <div className="flex gap-2">
                  {translatedText && (
                    <>
                      <Button size="sm" variant="outline" onClick={() => copyToClipboard(translatedText)}>
                        <Copy className="h-3 w-3 mr-1" />
                        Copy
                      </Button>
                      <Button size="sm" variant="outline" onClick={downloadText}>
                        <Download className="h-3 w-3 mr-1" />
                        Download
                      </Button>
                    </>
                  )}
                </div>
              </div>
              <div className="p-4 bg-blue-50 dark:bg-blue-950/20 rounded-lg min-h-[100px]">
                {isTranslating ? (
                  <div className="flex items-center gap-2 text-blue-600">
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-blue-600"></div>
                    <span className="text-sm">Translating live...</span>
                  </div>
                ) : (
                  <p className="text-lg">{translatedText}</p>
                )}
              </div>
            </div>
          )}

          {/* GBoard Features Info */}
          <Card className="bg-gradient-to-r from-blue-50 to-purple-50 dark:from-blue-950/20 dark:to-purple-950/20">
            <CardContent className="pt-4">
              <h4 className="font-medium mb-3">GBoard Features Active</h4>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                <div className="flex items-center gap-2">
                  <Lightbulb className="h-4 w-4 text-yellow-500" />
                  <span>Smart Suggestions</span>
                </div>
                <div className="flex items-center gap-2">
                  <Zap className="h-4 w-4 text-blue-500" />
                  <span>Auto-correct</span>
                </div>
                <div className="flex items-center gap-2">
                  <Mic className="h-4 w-4 text-green-500" />
                  <span>Voice Input</span>
                </div>
                <div className="flex items-center gap-2">
                  <Search className="h-4 w-4 text-purple-500" />
                  <span>Live Translation</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </CardContent>
      </Card>
    </div>
  );
}