import { useState, useRef, useEffect } from "react";
import { Button } from "./ui/button";
import { Card, CardContent } from "./ui/card";
import { Monitor, Eye, EyeOff, Copy, Settings, Minimize2, Maximize2, X, GripHorizontal } from "lucide-react";
import { toast } from "sonner@2.0.3";
import { motion, AnimatePresence } from "motion/react";

interface FloatingScreenTranslateProps {
  sourceLang: string;
  targetLang: string;
  onTranslation: (sourceText: string, translatedText: string) => void;
  isActive: boolean;
  onClose: () => void;
}

interface DetectedTextRegion {
  id: string;
  text: string;
  translatedText?: string;
  confidence: number;
  timestamp: number;
}

export function FloatingScreenTranslate({ 
  sourceLang, 
  targetLang, 
  onTranslation, 
  isActive,
  onClose 
}: FloatingScreenTranslateProps) {
  const [isMonitoring, setIsMonitoring] = useState(false);
  const [isMinimized, setIsMinimized] = useState(false);
  const [isExpanded, setIsExpanded] = useState(false);
  const [position, setPosition] = useState({ x: window.innerWidth - 320, y: 20 });
  const [detectedRegions, setDetectedRegions] = useState<DetectedTextRegion[]>([]);
  const [isDragging, setIsDragging] = useState(false);
  const monitoringIntervalRef = useRef<NodeJS.Timeout | null>(null);
  const bubbleRef = useRef<HTMLDivElement>(null);
  const dragRef = useRef<{ startX: number; startY: number; startPosX: number; startPosY: number } | null>(null);

  // Mock OCR and translation functions
  const mockDetectAndTranslate = async (): Promise<DetectedTextRegion[]> => {
    await new Promise(resolve => setTimeout(resolve, 800));
    
    const mockTexts = [
      'Welcome to our website',
      'Click here to continue',
      'Settings',
      'Home | About | Contact',
      'Search...',
      'Sign In',
      'Language Options',
      'Download App'
    ];

    const mockTranslations: Record<string, string> = {
      'Welcome to our website': 'Bienvenido a nuestro sitio web',
      'Click here to continue': 'Haz clic aquí para continuar',
      'Settings': 'Configuración',
      'Home | About | Contact': 'Inicio | Acerca de | Contacto',
      'Search...': 'Buscar...',
      'Sign In': 'Iniciar Sesión',
      'Language Options': 'Opciones de Idioma',
      'Download App': 'Descargar App'
    };

    // Randomly select 1-3 texts to simulate real-time detection
    const numTexts = Math.floor(Math.random() * 3) + 1;
    const selectedTexts = mockTexts.sort(() => 0.5 - Math.random()).slice(0, numTexts);
    
    return selectedTexts.map((text, index) => ({
      id: `${Date.now()}-${index}`,
      text,
      translatedText: mockTranslations[text] || `[${sourceLang} → ${targetLang}]: ${text}`,
      confidence: 0.8 + Math.random() * 0.2,
      timestamp: Date.now()
    }));
  };

  const startMonitoring = async () => {
    setIsMonitoring(true);
    toast.success('Screen translation monitoring started');
    
    // Initial scan
    try {
      const regions = await mockDetectAndTranslate();
      setDetectedRegions(regions);
      regions.forEach(region => {
        onTranslation(region.text, region.translatedText || region.text);
      });
    } catch (error) {
      console.error('Initial scan error:', error);
    }

    // Set up periodic monitoring
    monitoringIntervalRef.current = setInterval(async () => {
      try {
        const regions = await mockDetectAndTranslate();
        setDetectedRegions(prev => {
          // Keep recent regions and add new ones
          const recentRegions = prev.filter(r => Date.now() - r.timestamp < 30000); // Keep for 30 seconds
          const newRegions = regions.filter(r => 
            !recentRegions.some(existing => existing.text === r.text)
          );
          
          // Save new translations
          newRegions.forEach(region => {
            onTranslation(region.text, region.translatedText || region.text);
          });
          
          return [...recentRegions, ...newRegions].slice(-10); // Keep max 10 items
        });
      } catch (error) {
        console.error('Monitoring error:', error);
      }
    }, 3000);
  };

  const stopMonitoring = () => {
    setIsMonitoring(false);
    if (monitoringIntervalRef.current) {
      clearInterval(monitoringIntervalRef.current);
      monitoringIntervalRef.current = null;
    }
    setDetectedRegions([]);
    toast.success('Screen monitoring stopped');
  };

  // Auto-start monitoring when component becomes active
  useEffect(() => {
    if (isActive && !isMonitoring) {
      startMonitoring();
    } else if (!isActive && isMonitoring) {
      stopMonitoring();
    }
  }, [isActive]);

  // Clean up on unmount
  useEffect(() => {
    return () => {
      if (monitoringIntervalRef.current) {
        clearInterval(monitoringIntervalRef.current);
      }
    };
  }, []);

  // Handle dragging
  const handleMouseDown = (e: React.MouseEvent) => {
    if (!bubbleRef.current) return;
    
    setIsDragging(true);
    dragRef.current = {
      startX: e.clientX,
      startY: e.clientY,
      startPosX: position.x,
      startPosY: position.y
    };
    
    e.preventDefault();
  };

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (!isDragging || !dragRef.current) return;
      
      const deltaX = e.clientX - dragRef.current.startX;
      const deltaY = e.clientY - dragRef.current.startY;
      
      const newX = Math.max(0, Math.min(window.innerWidth - 320, dragRef.current.startPosX + deltaX));
      const newY = Math.max(0, Math.min(window.innerHeight - 100, dragRef.current.startPosY + deltaY));
      
      setPosition({ x: newX, y: newY });
    };

    const handleMouseUp = () => {
      setIsDragging(false);
      dragRef.current = null;
    };

    if (isDragging) {
      document.addEventListener('mousemove', handleMouseMove);
      document.addEventListener('mouseup', handleMouseUp);
    }

    return () => {
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
    };
  }, [isDragging]);

  const copyToClipboard = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      toast.success("Copied to clipboard");
    } catch {
      toast.error("Failed to copy");
    }
  };

  if (!isActive) return null;

  return (
    <AnimatePresence>
      <motion.div
        ref={bubbleRef}
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.8 }}
        className="fixed z-50 select-none"
        style={{ 
          left: position.x, 
          top: position.y,
          width: isExpanded ? '400px' : '280px'
        }}
      >
        <Card className="shadow-2xl border-2">
          <div
            className="flex items-center justify-between p-3 bg-gradient-to-r from-blue-500 to-purple-600 text-white rounded-t-lg cursor-move"
            onMouseDown={handleMouseDown}
          >
            <div className="flex items-center gap-2">
              <Monitor className="h-4 w-4" />
              <span className="font-medium text-sm">Screen Translate</span>
              {isMonitoring && (
                <div className="w-2 h-2 bg-green-300 rounded-full animate-pulse"></div>
              )}
            </div>
            
            <div className="flex items-center gap-1">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setIsExpanded(!isExpanded)}
                className="h-6 w-6 p-0 text-white hover:bg-white/20"
              >
                {isExpanded ? <Minimize2 className="h-3 w-3" /> : <Maximize2 className="h-3 w-3" />}
              </Button>
              
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setIsMinimized(!isMinimized)}
                className="h-6 w-6 p-0 text-white hover:bg-white/20"
              >
                <GripHorizontal className="h-3 w-3" />
              </Button>
              
              <Button
                variant="ghost"
                size="sm"
                onClick={onClose}
                className="h-6 w-6 p-0 text-white hover:bg-red-500/50"
              >
                <X className="h-3 w-3" />
              </Button>
            </div>
          </div>

          {!isMinimized && (
            <CardContent className="p-3 max-h-80 overflow-y-auto">
              <div className="space-y-3">
                {/* Controls */}
                <div className="flex items-center justify-between">
                  <span className="text-xs text-muted-foreground">
                    {sourceLang} → {targetLang}
                  </span>
                  <Button
                    size="sm"
                    variant={isMonitoring ? "destructive" : "default"}
                    onClick={isMonitoring ? stopMonitoring : startMonitoring}
                    className="h-6 text-xs px-2"
                  >
                    {isMonitoring ? (
                      <>
                        <EyeOff className="h-3 w-3 mr-1" />
                        Stop
                      </>
                    ) : (
                      <>
                        <Eye className="h-3 w-3 mr-1" />
                        Start
                      </>
                    )}
                  </Button>
                </div>

                {/* Status */}
                {isMonitoring && (
                  <div className="bg-green-50 border border-green-200 rounded p-2 dark:bg-green-950 dark:border-green-800">
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                      <span className="text-xs text-green-700 dark:text-green-300">
                        Monitoring active
                      </span>
                    </div>
                  </div>
                )}

                {/* Recent Translations */}
                {detectedRegions.length > 0 && (
                  <div className="space-y-2">
                    <h4 className="text-xs font-medium">Recent Translations:</h4>
                    {detectedRegions.slice(-3).reverse().map((region) => (
                      <div key={region.id} className="bg-muted/50 rounded p-2 space-y-1">
                        <div className="flex items-start justify-between">
                          <div className="flex-1 min-w-0">
                            <p className="text-xs text-muted-foreground truncate">
                              {region.text}
                            </p>
                            <p className="text-xs font-medium text-primary">
                              {region.translatedText}
                            </p>
                          </div>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => copyToClipboard(region.translatedText || region.text)}
                            className="h-5 w-5 p-0 ml-1"
                          >
                            <Copy className="h-2.5 w-2.5" />
                          </Button>
                        </div>
                        <div className="text-xs text-muted-foreground">
                          Confidence: {(region.confidence * 100).toFixed(0)}%
                        </div>
                      </div>
                    ))}
                  </div>
                )}

                {!isMonitoring && detectedRegions.length === 0 && (
                  <div className="text-center py-4">
                    <Monitor className="h-8 w-8 text-muted-foreground mx-auto mb-2" />
                    <p className="text-xs text-muted-foreground">
                      Click Start to begin screen monitoring
                    </p>
                  </div>
                )}
              </div>
            </CardContent>
          )}
        </Card>
      </motion.div>
    </AnimatePresence>
  );
}