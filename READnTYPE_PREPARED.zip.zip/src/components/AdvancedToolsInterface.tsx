import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { 
  FileText,
  ScanLine,
  Languages,
  Settings,
  Monitor,
  Keyboard,
  FileAudio,
  Zap,
  ArrowRight
} from "lucide-react";
import { TranslationMode } from "./TranslationModeMenu";

interface AdvancedToolsInterfaceProps {
  onToolSelect: (tool: TranslationMode) => void;
  isScreenTranslateActive: boolean;
}

interface ToolCard {
  id: TranslationMode;
  title: string;
  description: string;
  icon: React.ComponentType<{ className?: string }>;
  badge?: string;
  color: string;
  category: 'document' | 'media' | 'input' | 'system';
}

const getAdvancedTools = (isScreenTranslateActive: boolean): ToolCard[] => [
  {
    id: 'pdf',
    title: 'PDF Translator',
    description: 'Upload and translate entire PDF documents with preserved formatting',
    icon: FileText,
    badge: 'Beta',
    color: 'from-indigo-500 to-indigo-600',
    category: 'document'
  },
  {
    id: 'camscanner',
    title: 'CamScanner & Translate',
    description: 'Scan physical documents with smart OCR and instant translation',
    icon: ScanLine,
    badge: 'Smart OCR',
    color: 'from-teal-500 to-teal-600',
    category: 'media'
  },
  {
    id: 'virtual-keyboard',
    title: 'Virtual Keyboard',
    description: 'Type in multiple languages with native script support',
    icon: Languages,
    badge: 'Multi-script',
    color: 'from-pink-500 to-pink-600',
    category: 'input'
  },
  {
    id: 'transcribe',
    title: 'Audio Transcription',
    description: 'Convert speech and audio files to text in any language',
    icon: FileAudio,
    color: 'from-purple-500 to-purple-600',
    category: 'media'
  },
  {
    id: 'screen',
    title: 'Screen Translator',
    description: 'Real-time translation of text anywhere on your screen',
    icon: Monitor,
    badge: isScreenTranslateActive ? 'Active' : undefined,
    color: 'from-red-500 to-red-600',
    category: 'system'
  },
  {
    id: 'screen-settings',
    title: 'Screen Translator Settings',
    description: 'Configure advanced options for screen translation',
    icon: Settings,
    badge: 'Advanced',
    color: 'from-gray-500 to-gray-600',
    category: 'system'
  }
];

const categoryLabels = {
  document: 'Document Processing',
  media: 'Media & OCR',
  input: 'Input Methods',
  system: 'System Tools'
};

export function AdvancedToolsInterface({ onToolSelect, isScreenTranslateActive }: AdvancedToolsInterfaceProps) {
  const advancedTools = getAdvancedTools(isScreenTranslateActive);
  
  const categorizedTools = advancedTools.reduce((acc, tool) => {
    if (!acc[tool.category]) {
      acc[tool.category] = [];
    }
    acc[tool.category].push(tool);
    return acc;
  }, {} as Record<string, ToolCard[]>);

  return (
    <div className="max-w-6xl mx-auto space-y-8">
      {/* Header */}
      <div className="text-center space-y-4">
        <div className="flex items-center justify-center gap-3">
          <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-purple-600 rounded-xl flex items-center justify-center">
            <Zap className="h-6 w-6 text-white" />
          </div>
          <div>
            <h2 className="text-3xl font-bold">Advanced Translation Tools</h2>
            <p className="text-muted-foreground">
              Professional tools for complex translation workflows
            </p>
          </div>
        </div>
      </div>

      {/* Tool Categories */}
      {Object.entries(categorizedTools).map(([category, tools]) => (
        <div key={category} className="space-y-4">
          <div className="flex items-center gap-2">
            <h3 className="text-xl font-semibold">
              {categoryLabels[category as keyof typeof categoryLabels]}
            </h3>
            <Badge variant="outline">{tools.length} tools</Badge>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {tools.map((tool) => {
              const Icon = tool.icon;
              const isActive = tool.id === 'screen' && isScreenTranslateActive;
              
              return (
                <Card 
                  key={tool.id}
                  className={`group cursor-pointer transition-all duration-300 hover:shadow-lg hover:scale-105 ${
                    isActive ? 'ring-2 ring-blue-500 shadow-lg' : ''
                  }`}
                  onClick={() => onToolSelect(tool.id)}
                >
                  <CardHeader className="pb-4">
                    <div className="flex items-start justify-between">
                      <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${tool.color} flex items-center justify-center text-white shadow-lg`}>
                        <Icon className="h-6 w-6" />
                      </div>
                      {tool.badge && (
                        <Badge 
                          variant={isActive ? "default" : "secondary"} 
                          className="text-xs"
                        >
                          {tool.badge}
                        </Badge>
                      )}
                    </div>
                    <CardTitle className="text-lg group-hover:text-blue-600 transition-colors">
                      {tool.title}
                    </CardTitle>
                  </CardHeader>
                  
                  <CardContent className="pt-0">
                    <p className="text-sm text-muted-foreground leading-relaxed mb-4">
                      {tool.description}
                    </p>
                    
                    <Button 
                      variant={isActive ? "default" : "ghost"} 
                      size="sm"
                      className="w-full group-hover:bg-blue-50 group-hover:text-blue-600 transition-colors"
                    >
                      {isActive ? 'Active' : 'Launch Tool'}
                      <ArrowRight className="h-3 w-3 ml-2" />
                    </Button>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      ))}

      {/* Feature Highlights */}
      <Card className="bg-gradient-to-r from-blue-50 to-purple-50 dark:from-blue-950/20 dark:to-purple-950/20 border-0">
        <CardContent className="p-6">
          <div className="grid md:grid-cols-3 gap-6">
            <div className="text-center">
              <div className="w-12 h-12 bg-blue-100 dark:bg-blue-900/30 rounded-lg flex items-center justify-center mx-auto mb-3">
                <FileText className="h-6 w-6 text-blue-600" />
              </div>
              <h4 className="font-medium mb-2">Document Processing</h4>
              <p className="text-sm text-muted-foreground">
                Handle PDFs, scanned documents, and complex layouts with precision
              </p>
            </div>
            
            <div className="text-center">
              <div className="w-12 h-12 bg-green-100 dark:bg-green-900/30 rounded-lg flex items-center justify-center mx-auto mb-3">
                <ScanLine className="h-6 w-6 text-green-600" />
              </div>
              <h4 className="font-medium mb-2">Smart OCR</h4>
              <p className="text-sm text-muted-foreground">
                Advanced optical character recognition for 60+ languages
              </p>
            </div>
            
            <div className="text-center">
              <div className="w-12 h-12 bg-purple-100 dark:bg-purple-900/30 rounded-lg flex items-center justify-center mx-auto mb-3">
                <Monitor className="h-6 w-6 text-purple-600" />
              </div>
              <h4 className="font-medium mb-2">Real-time Translation</h4>
              <p className="text-sm text-muted-foreground">
                Live screen translation and instant text processing
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}