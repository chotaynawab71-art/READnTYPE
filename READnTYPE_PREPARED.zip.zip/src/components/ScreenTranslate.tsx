import { useState, useRef, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Switch } from "./ui/switch";
import { Slider } from "./ui/slider";
import { Monitor, Eye, EyeOff, Copy, Settings, Zap, ZapOff, AlertCircle } from "lucide-react";
import { toast } from "sonner@2.0.3";

interface ScreenTranslateProps {
  sourceLang: string;
  targetLang: string;
  onTranslation: (sourceText: string, translatedText: string) => void;
}

interface DetectedTextRegion {
  id: string;
  text: string;
  x: number;
  y: number;
  width: number;
  height: number;
  confidence: number;
}

interface TranslatedRegion extends DetectedTextRegion {
  translatedText: string;
}

export function ScreenTranslate({ sourceLang, targetLang, onTranslation }: ScreenTranslateProps) {
  const [isMonitoring, setIsMonitoring] = useState(false);
  const [detectedRegions, setDetectedRegions] = useState<DetectedTextRegion[]>([]);
  const [translatedRegions, setTranslatedRegions] = useState<TranslatedRegion[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [showOverlay, setShowOverlay] = useState(true);
  const [autoTranslate, setAutoTranslate] = useState(true);
  const [refreshRate, setRefreshRate] = useState(2000); // 2 seconds
  const [confidenceThreshold, setConfidenceThreshold] = useState(0.7);
  const overlayRef = useRef<HTMLDivElement>(null);
  const monitoringIntervalRef = useRef<NodeJS.Timeout | null>(null);

  // Mock OCR function that simulates text detection
  const mockDetectText = async (): Promise<DetectedTextRegion[]> => {
    await new Promise(resolve => setTimeout(resolve, 500));
    
    // Simulate finding text regions on screen
    const mockRegions: DetectedTextRegion[] = [
      {
        id: '1',
        text: 'Welcome to our website',
        x: 100,
        y: 50,
        width: 200,
        height: 30,
        confidence: 0.95
      },
      {
        id: '2',
        text: 'Please click here to continue',
        x: 150,
        y: 200,
        width: 250,
        height: 25,
        confidence: 0.88
      },
      {
        id: '3',
        text: 'Contact us for more information',
        x: 200,
        y: 350,
        width: 280,
        height: 20,
        confidence: 0.82
      },
      {
        id: '4',
        text: 'Settings',
        x: 50,
        y: 400,
        width: 80,
        height: 18,
        confidence: 0.75
      },
      {
        id: '5',
        text: 'Home | About | Services | Contact',
        x: 120,
        y: 120,
        width: 300,
        height: 22,
        confidence: 0.91
      }
    ];

    // Filter by confidence threshold
    return mockRegions.filter(region => region.confidence >= confidenceThreshold);
  };

  // Mock translation function
  const mockTranslate = async (text: string): Promise<string> => {
    await new Promise(resolve => setTimeout(resolve, 300));
    
    const translations: Record<string, string> = {
      'Welcome to our website': 'Bienvenido a nuestro sitio web',
      'Please click here to continue': 'Por favor haga clic aquí para continuar',
      'Contact us for more information': 'Contáctanos para más información',
      'Settings': 'Configuración',
      'Home | About | Services | Contact': 'Inicio | Acerca de | Servicios | Contacto'
    };

    return translations[text] || `[${sourceLang} → ${targetLang}]: ${text}`;
  };

  // Process detected text regions
  const processTextRegions = async (regions: DetectedTextRegion[]) => {
    if (!autoTranslate) return;

    setIsProcessing(true);
    try {
      const translated: TranslatedRegion[] = [];
      
      for (const region of regions) {
        const translatedText = await mockTranslate(region.text);
        translated.push({
          ...region,
          translatedText
        });
        
        // Save to history
        onTranslation(region.text, translatedText);
      }
      
      setTranslatedRegions(translated);
    } catch (error) {
      console.error('Translation error:', error);
      toast.error('Translation failed');
    } finally {
      setIsProcessing(false);
    }
  };

  // Monitor screen for text
  const startMonitoring = async () => {
    setIsMonitoring(true);
    toast.success('Live screen monitoring started');
    
    // Simulate initial scan
    try {
      const regions = await mockDetectText();
      setDetectedRegions(regions);
      if (regions.length > 0) {
        await processTextRegions(regions);
      }
    } catch (error) {
      console.error('Initial scan error:', error);
    }

    // Set up periodic monitoring
    monitoringIntervalRef.current = setInterval(async () => {
      try {
        const regions = await mockDetectText();
        setDetectedRegions(regions);
        
        // Only process if regions have changed
        const hasChanged = regions.length !== detectedRegions.length || 
          regions.some(r => !detectedRegions.find(d => d.id === r.id && d.text === r.text));
        
        if (hasChanged && autoTranslate) {
          await processTextRegions(regions);
        }
      } catch (error) {
        console.error('Monitoring error:', error);
      }
    }, refreshRate);
  };

  const stopMonitoring = () => {
    setIsMonitoring(false);
    if (monitoringIntervalRef.current) {
      clearInterval(monitoringIntervalRef.current);
      monitoringIntervalRef.current = null;
    }
    setDetectedRegions([]);
    setTranslatedRegions([]);
    toast.success('Live screen monitoring stopped');
  };

  // Clean up on unmount
  useEffect(() => {
    return () => {
      if (monitoringIntervalRef.current) {
        clearInterval(monitoringIntervalRef.current);
      }
    };
  }, []);

  const copyToClipboard = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      toast.success("Copied to clipboard");
    } catch {
      toast.error("Failed to copy");
    }
  };

  const translateRegion = async (region: DetectedTextRegion) => {
    try {
      const translatedText = await mockTranslate(region.text);
      
      setTranslatedRegions(prev => {
        const existing = prev.find(r => r.id === region.id);
        if (existing) {
          return prev.map(r => r.id === region.id ? { ...r, translatedText } : r);
        } else {
          return [...prev, { ...region, translatedText }];
        }
      });
      
      onTranslation(region.text, translatedText);
      toast.success('Text translated');
    } catch (error) {
      console.error('Translation error:', error);
      toast.error('Translation failed');
    }
  };

  const formatRefreshRate = (ms: number) => {
    if (ms < 1000) return `${ms}ms`;
    return `${ms / 1000}s`;
  };

  return (
    <div className="space-y-6">
      {/* Live Monitoring Controls */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            Live Screen Translation
            <div className="flex items-center gap-2">
              {isMonitoring && (
                <div className="flex items-center gap-1 text-sm text-muted-foreground">
                  <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                  <span>Live</span>
                </div>
              )}
              <Button
                onClick={isMonitoring ? stopMonitoring : startMonitoring}
                variant={isMonitoring ? "destructive" : "default"}
              >
                {isMonitoring ? (
                  <>
                    <EyeOff className="h-4 w-4 mr-2" />
                    Stop Monitoring
                  </>
                ) : (
                  <>
                    <Eye className="h-4 w-4 mr-2" />
                    Start Monitoring
                  </>
                )}
              </Button>
            </div>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Status and Info */}
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 dark:bg-blue-950 dark:border-blue-800">
            <div className="flex items-start gap-3">
              <AlertCircle className="h-5 w-5 text-blue-600 dark:text-blue-400 mt-0.5" />
              <div>
                <h4 className="font-medium text-blue-900 dark:text-blue-100">Live Screen Translation</h4>
                <p className="text-sm text-blue-700 dark:text-blue-300 mt-1">
                  This simulates live screen monitoring and text translation. In a real implementation, 
                  this would use screen capture APIs and OCR technology to detect and translate text in real-time.
                </p>
              </div>
            </div>
          </div>

          {/* Settings */}
          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    {autoTranslate ? (
                      <Zap className="h-4 w-4 text-yellow-500" />
                    ) : (
                      <ZapOff className="h-4 w-4 text-muted-foreground" />
                    )}
                    <span className="font-medium">Auto Translate</span>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    Automatically translate detected text
                  </p>
                </div>
                <Switch
                  checked={autoTranslate}
                  onCheckedChange={setAutoTranslate}
                />
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <Monitor className="h-4 w-4" />
                    <span className="font-medium">Show Overlay</span>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    Display translation overlay
                  </p>
                </div>
                <Switch
                  checked={showOverlay}
                  onCheckedChange={setShowOverlay}
                />
              </div>
            </div>

            <div className="space-y-4">
              <div className="space-y-2">
                <label className="text-sm font-medium">
                  Refresh Rate: {formatRefreshRate(refreshRate)}
                </label>
                <Slider
                  value={[refreshRate]}
                  onValueChange={(value) => setRefreshRate(value[0])}
                  min={500}
                  max={5000}
                  step={250}
                  className="w-full"
                />
                <div className="flex justify-between text-xs text-muted-foreground">
                  <span>Fast (500ms)</span>
                  <span>Slow (5s)</span>
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">
                  Confidence Threshold: {(confidenceThreshold * 100).toFixed(0)}%
                </label>
                <Slider
                  value={[confidenceThreshold]}
                  onValueChange={(value) => setConfidenceThreshold(value[0])}
                  min={0.3}
                  max={1.0}
                  step={0.05}
                  className="w-full"
                />
                <div className="flex justify-between text-xs text-muted-foreground">
                  <span>Low (30%)</span>
                  <span>High (100%)</span>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Detected Text Regions */}
      {detectedRegions.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              Detected Text Regions
              <div className="flex items-center gap-2">
                {isProcessing && (
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-primary"></div>
                )}
                <span className="text-sm text-muted-foreground">
                  {detectedRegions.length} regions found
                </span>
              </div>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {detectedRegions.map((region) => {
              const translation = translatedRegions.find(t => t.id === region.id);
              return (
                <div key={region.id} className="border rounded-lg p-4 space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="text-xs bg-muted px-2 py-1 rounded">
                        Region {region.id}
                      </span>
                      <span className="text-xs text-muted-foreground">
                        Confidence: {(region.confidence * 100).toFixed(0)}%
                      </span>
                      <span className="text-xs text-muted-foreground">
                        Position: {region.x},{region.y}
                      </span>
                    </div>
                    <div className="flex gap-1">
                      {!translation && (
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => translateRegion(region)}
                          className="h-7 text-xs"
                        >
                          Translate
                        </Button>
                      )}
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => copyToClipboard(region.text)}
                        className="h-7 w-7 p-0"
                      >
                        <Copy className="h-3 w-3" />
                      </Button>
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <div>
                      <span className="text-xs text-muted-foreground">Original:</span>
                      <p className="text-sm">{region.text}</p>
                    </div>
                    
                    {translation && (
                      <div>
                        <span className="text-xs text-muted-foreground">Translation:</span>
                        <p className="text-sm font-medium text-primary">{translation.translatedText}</p>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </CardContent>
        </Card>
      )}

      {/* Live Translation Overlay Simulation */}
      {isMonitoring && showOverlay && translatedRegions.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Translation Overlay Preview</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="relative bg-muted/30 rounded-lg p-8 min-h-64" ref={overlayRef}>
              <div className="text-center text-sm text-muted-foreground mb-4">
                Simulated Screen Content with Live Translations
              </div>
              {translatedRegions.map((region) => (
                <div
                  key={region.id}
                  className="absolute bg-yellow-100 border-2 border-yellow-400 rounded px-2 py-1 shadow-lg dark:bg-yellow-900 dark:border-yellow-600"
                  style={{
                    left: `${Math.min(region.x / 4, 80)}%`,
                    top: `${Math.min(region.y / 8, 70)}%`,
                    minWidth: '120px'
                  }}
                >
                  <div className="text-xs text-gray-600 dark:text-gray-300">
                    {region.text}
                  </div>
                  <div className="text-sm font-medium text-yellow-800 dark:text-yellow-200">
                    {region.translatedText}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Monitoring Status */}
      {isMonitoring && (
        <Card>
          <CardContent className="pt-6">
            <div className="text-center space-y-2">
              <div className="flex items-center justify-center gap-2">
                <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse"></div>
                <span className="font-medium">Live Monitoring Active</span>
              </div>
              <p className="text-sm text-muted-foreground">
                Scanning screen every {formatRefreshRate(refreshRate)} for text changes
              </p>
              <div className="flex items-center justify-center gap-4 text-xs text-muted-foreground">
                <span>Languages: {sourceLang} → {targetLang}</span>
                <span>•</span>
                <span>Auto-translate: {autoTranslate ? 'On' : 'Off'}</span>
                <span>•</span>
                <span>Confidence: {(confidenceThreshold * 100).toFixed(0)}%+</span>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}