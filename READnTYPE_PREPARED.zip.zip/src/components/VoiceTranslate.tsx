import { useState, useRef, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Mic, MicOff, Volume2, VolumeX, Play, Square } from "lucide-react";
import { toast } from "sonner@2.0.3";

interface VoiceTranslateProps {
  sourceLang: string;
  targetLang: string;
  onTranslation: (sourceText: string, translatedText: string) => void;
}

export function VoiceTranslate({ sourceLang, targetLang, onTranslation }: VoiceTranslateProps) {
  const [isListening, setIsListening] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [transcript, setTranscript] = useState("");
  const [translatedText, setTranslatedText] = useState("");
  const [isTranslating, setIsTranslating] = useState(false);
  const recognitionRef = useRef<SpeechRecognition | null>(null);
  const synthRef = useRef<SpeechSynthesisUtterance | null>(null);

  useEffect(() => {
    // Check if speech recognition is supported
    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
      recognitionRef.current = new SpeechRecognition();
      recognitionRef.current.continuous = true;
      recognitionRef.current.interimResults = true;
      recognitionRef.current.lang = getLanguageCode(sourceLang);

      recognitionRef.current.onresult = (event) => {
        let finalTranscript = '';
        let interimTranscript = '';

        for (let i = event.resultIndex; i < event.results.length; i++) {
          const transcript = event.results[i][0].transcript;
          if (event.results[i].isFinal) {
            finalTranscript += transcript;
          } else {
            interimTranscript += transcript;
          }
        }

        setTranscript(finalTranscript + interimTranscript);

        if (finalTranscript) {
          handleTranslate(finalTranscript);
        }
      };

      recognitionRef.current.onerror = (event) => {
        console.error('Speech recognition error:', event.error);
        
        // Handle different error types with appropriate messages
        switch (event.error) {
          case 'not-allowed':
            toast.error('Microphone access denied. Please allow microphone permissions and try again.');
            break;
          case 'no-speech':
            toast.error('No speech detected. Please try speaking clearly.');
            break;
          case 'audio-capture':
            toast.error('Audio capture failed. Please check your microphone.');
            break;
          case 'network':
            toast.error('Network error. Please check your internet connection.');
            break;
          case 'service-not-allowed':
            toast.error('Speech recognition service not allowed.');
            break;
          case 'bad-grammar':
            toast.error('Recognition error. Please try again.');
            break;
          default:
            toast.error(`Speech recognition error: ${event.error}`);
        }
        
        setIsListening(false);
      };

      recognitionRef.current.onend = () => {
        setIsListening(false);
      };
    }

    return () => {
      if (recognitionRef.current) {
        recognitionRef.current.stop();
      }
      if (synthRef.current) {
        speechSynthesis.cancel();
      }
    };
  }, [sourceLang]);

  const getLanguageCode = (lang: string) => {
    const langMap: Record<string, string> = {
      'en': 'en-US',
      'es': 'es-ES',
      'fr': 'fr-FR',
      'de': 'de-DE',
      'it': 'it-IT',
      'pt': 'pt-PT',
      'ru': 'ru-RU',
      'ja': 'ja-JP',
      'ko': 'ko-KR',
      'zh': 'zh-CN',
      'zh-tw': 'zh-TW',
      'ar': 'ar-SA',
      'hi': 'hi-IN',
      'nl': 'nl-NL',
      'pl': 'pl-PL',
      'sv': 'sv-SE',
      'no': 'no-NO',
      'da': 'da-DK',
      'fi': 'fi-FI',
      'el': 'el-GR',
      'cs': 'cs-CZ',
      'sk': 'sk-SK',
      'hu': 'hu-HU',
      'ro': 'ro-RO',
      'bg': 'bg-BG',
      'hr': 'hr-HR',
      'sr': 'sr-RS',
      'sl': 'sl-SI',
      'lv': 'lv-LV',
      'lt': 'lt-LT',
      'et': 'et-EE',
      'is': 'is-IS',
      'mt': 'mt-MT',
      'th': 'th-TH',
      'vi': 'vi-VN',
      'id': 'id-ID',
      'ms': 'ms-MY',
      'tl': 'tl-PH',
      'my': 'my-MM',
      'km': 'km-KH',
      'lo': 'lo-LA',
      'ka': 'ka-GE',
      'hy': 'hy-AM',
      'az': 'az-AZ',
      'kk': 'kk-KZ',
      'ky': 'ky-KG',
      'uz': 'uz-UZ',
      'tk': 'tk-TM',
      'tj': 'tg-TJ',
      'mn': 'mn-MN',
      'bn': 'bn-BD',
      'ur': 'ur-PK',
      'ta': 'ta-IN',
      'te': 'te-IN',
      'ml': 'ml-IN',
      'kn': 'kn-IN',
      'gu': 'gu-IN',
      'mr': 'mr-IN',
      'pa': 'pa-IN',
      'or': 'or-IN',
      'as': 'as-IN',
      'ne': 'ne-NP',
      'si': 'si-LK',
      'fa': 'fa-IR',
      'he': 'he-IL',
      'tr': 'tr-TR',
      'sw': 'sw-KE',
      'am': 'am-ET',
      'ha': 'ha-NG',
      'yo': 'yo-NG',
      'ig': 'ig-NG',
      'zu': 'zu-ZA',
      'af': 'af-ZA',
      'xh': 'xh-ZA',
      'so': 'so-SO',
      'mg': 'mg-MG',
      'qu': 'qu-PE',
      'gn': 'gn-PY',
      'ay': 'ay-BO',
      'mi': 'mi-NZ',
      'haw': 'haw-US',
      'sm': 'sm-WS',
      'to': 'to-TO',
      'fj': 'fj-FJ',
      'eu': 'eu-ES',
      'ca': 'ca-ES',
      'gl': 'gl-ES',
      'br': 'br-FR',
      'co': 'co-FR',
      'sc': 'sc-IT',
      'lb': 'lb-LU',
      'fo': 'fo-FO',
      'fy': 'fy-NL',
    };
    return langMap[lang] || 'en-US';
  };

  const mockTranslate = async (text: string): Promise<string> => {
    await new Promise(resolve => setTimeout(resolve, 1000));
    return `[Voice Translation ${sourceLang} → ${targetLang}]: ${text}`;
  };

  const handleTranslate = async (text: string) => {
    if (!text.trim()) return;

    setIsTranslating(true);
    try {
      const result = await mockTranslate(text);
      setTranslatedText(result);
      onTranslation(text, result);
    } catch (error) {
      console.error('Translation error:', error);
      toast.error('Translation failed');
    } finally {
      setIsTranslating(false);
    }
  };

  const startListening = async () => {
    if (!recognitionRef.current) {
      toast.error('Speech recognition not supported in this browser');
      return;
    }

    // Request microphone permission first
    try {
      await navigator.mediaDevices.getUserMedia({ audio: true });
    } catch (error) {
      toast.error('Microphone access denied. Please allow microphone permissions in your browser settings.');
      return;
    }

    setIsListening(true);
    setTranscript("");
    setTranslatedText("");
    recognitionRef.current.start();
    toast.success('Listening... Speak now');
  };

  const stopListening = () => {
    if (recognitionRef.current) {
      recognitionRef.current.stop();
    }
    setIsListening(false);
  };

  const speakTranslation = () => {
    if (!translatedText || !('speechSynthesis' in window)) {
      toast.error('Text-to-speech not supported');
      return;
    }

    if (isSpeaking) {
      speechSynthesis.cancel();
      setIsSpeaking(false);
      return;
    }

    synthRef.current = new SpeechSynthesisUtterance(translatedText);
    synthRef.current.lang = getLanguageCode(targetLang);
    synthRef.current.rate = 0.8;

    synthRef.current.onstart = () => setIsSpeaking(true);
    synthRef.current.onend = () => setIsSpeaking(false);
    synthRef.current.onerror = () => {
      setIsSpeaking(false);
      toast.error('Text-to-speech failed');
    };

    speechSynthesis.speak(synthRef.current);
  };

  return (
    <div className="space-y-6">
      {/* Voice Input */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            Voice Input
            <Button
              onClick={isListening ? stopListening : startListening}
              variant={isListening ? "destructive" : "default"}
              size="lg"
              className="rounded-full h-16 w-16 p-0"
            >
              {isListening ? (
                <MicOff className="h-8 w-8" />
              ) : (
                <Mic className="h-8 w-8" />
              )}
            </Button>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="min-h-24 p-4 border rounded-lg bg-muted/30">
            {isListening && (
              <div className="flex items-center gap-2 mb-2">
                <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse"></div>
                <span className="text-sm text-muted-foreground">Recording...</span>
              </div>
            )}
            {transcript ? (
              <p className="whitespace-pre-wrap">{transcript}</p>
            ) : (
              <p className="text-muted-foreground">
                {isListening ? "Speak now..." : "Click the microphone to start voice input"}
              </p>
            )}
          </div>
          {transcript && (
            <div className="text-sm text-muted-foreground">
              {transcript.length} characters
            </div>
          )}
        </CardContent>
      </Card>

      {/* Voice Output */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            Translation
            <Button
              onClick={speakTranslation}
              disabled={!translatedText}
              variant="outline"
              size="sm"
            >
              {isSpeaking ? (
                <>
                  <VolumeX className="h-4 w-4 mr-2" />
                  Stop
                </>
              ) : (
                <>
                  <Volume2 className="h-4 w-4 mr-2" />
                  Speak
                </>
              )}
            </Button>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="min-h-24 p-4 border rounded-lg bg-muted/30">
            {isTranslating ? (
              <div className="flex items-center justify-center h-full">
                <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-primary"></div>
              </div>
            ) : translatedText ? (
              <p className="whitespace-pre-wrap">{translatedText}</p>
            ) : (
              <p className="text-muted-foreground">
                Translation will appear here...
              </p>
            )}
          </div>
          {translatedText && (
            <div className="mt-4 flex items-center justify-between text-sm text-muted-foreground">
              <span>{translatedText.length} characters</span>
              {isSpeaking && (
                <div className="flex items-center gap-1">
                  <div className="w-2 h-2 bg-blue-500 rounded-full animate-pulse"></div>
                  <span>Speaking...</span>
                </div>
              )}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Voice Controls */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex flex-wrap gap-2">
            <Button
              onClick={startListening}
              disabled={isListening}
              variant="outline"
            >
              <Mic className="h-4 w-4 mr-2" />
              Start Recording
            </Button>
            <Button
              onClick={stopListening}
              disabled={!isListening}
              variant="outline"
            >
              <Square className="h-4 w-4 mr-2" />
              Stop Recording
            </Button>
            <Button
              onClick={speakTranslation}
              disabled={!translatedText}
              variant="outline"
            >
              <Play className="h-4 w-4 mr-2" />
              Play Translation
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Voice Features Info */}
      <Card>
        <CardHeader>
          <CardTitle>Voice Features</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-2 gap-4 text-sm">
            <div className="space-y-2">
              <h4 className="font-medium">Speech Recognition</h4>
              <ul className="space-y-1 text-muted-foreground">
                <li>• Continuous listening mode</li>
                <li>• Real-time transcription</li>
                <li>• Multi-language support</li>
                <li>• Interim results display</li>
              </ul>
            </div>
            <div className="space-y-2">
              <h4 className="font-medium">Text-to-Speech</h4>
              <ul className="space-y-1 text-muted-foreground">
                <li>• Natural voice synthesis</li>
                <li>• Language-specific voices</li>
                <li>• Adjustable speech rate</li>
                <li>• High-quality audio output</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}