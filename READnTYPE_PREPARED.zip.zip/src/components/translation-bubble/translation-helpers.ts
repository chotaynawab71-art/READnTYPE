import { MOCK_TEXTS, MOCK_TRANSLATIONS } from './constants';
import { DetectedText, SelectionArea } from './types';

export const mockTranslateText = async (text: string, sourceLang: string, targetLang: string): Promise<string> => {
  await new Promise(resolve => setTimeout(resolve, 500));
  
  const sourceDict = MOCK_TRANSLATIONS[sourceLang];
  const targetDict = sourceDict?.[targetLang];
  return targetDict?.[text] || `[${sourceLang}→${targetLang}] ${text}`;
};

export const mockScanScreen = async (area?: SelectionArea, sourceLang: string = 'en', targetLang: string = 'es'): Promise<DetectedText[]> => {
  await new Promise(resolve => setTimeout(resolve, 300));
  
  const selectedTexts = MOCK_TEXTS.sort(() => 0.5 - Math.random()).slice(0, Math.floor(Math.random() * 3) + 1);
  
  const results: DetectedText[] = [];
  for (const text of selectedTexts) {
    const translatedText = await mockTranslateText(text, sourceLang, targetLang);
    results.push({
      id: `${Date.now()}-${Math.random()}`,
      text,
      translatedText,
      confidence: 0.8 + Math.random() * 0.2,
      area: area || {
        x: Math.random() * 500,
        y: Math.random() * 300,
        width: 100 + Math.random() * 200,
        height: 20 + Math.random() * 40
      },
      timestamp: Date.now()
    });
  }
  
  return results;
};

export const copyToClipboard = async (text: string): Promise<void> => {
  try {
    await navigator.clipboard.writeText(text);
  } catch (error) {
    throw new Error('Failed to copy to clipboard');
  }
};