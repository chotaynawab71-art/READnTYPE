import { Button } from "../ui/button";
import { Languages, Move, X } from "lucide-react";

interface BubbleHeaderProps {
  isMonitoring: boolean;
  onMinimizeToggle: () => void;
  onClose: () => void;
  onMouseDown: (e: React.MouseEvent) => void;
}

export function BubbleHeader({ isMonitoring, onMinimizeToggle, onClose, onMouseDown }: BubbleHeaderProps) {
  return (
    <div
      className="flex items-center justify-between p-2 bg-gradient-to-r from-blue-500 to-purple-600 text-white rounded-t-lg cursor-move"
      onMouseDown={onMouseDown}
    >
      <div className="flex items-center gap-2">
        <Languages className="h-4 w-4" />
        <span className="font-medium text-sm">Live Translate</span>
        {isMonitoring && (
          <div className="w-2 h-2 bg-green-300 rounded-full animate-pulse"></div>
        )}
      </div>
      
      <div className="flex items-center gap-1">
        <Button
          variant="ghost"
          size="sm"
          onClick={onMinimizeToggle}
          className="h-6 w-6 p-0 text-white hover:bg-white/20"
        >
          <Move className="h-3 w-3" />
        </Button>
        
        <Button
          variant="ghost"
          size="sm"
          onClick={onClose}
          className="h-6 w-6 p-0 text-white hover:bg-red-500/50"
        >
          <X className="h-3 w-3" />
        </Button>
      </div>
    </div>
  );
}