export const MOCK_TEXTS = [
  'Welcome to our website',
  'Settings',
  'Home',
  'Search',
  'Sign In',
  'About',
  'Contact',
  'Download App',
  'Continue',
  'Menu',
  'Profile',
  'Dashboard',
  'Logout',
  'Help'
];

export const MOCK_TRANSLATIONS: Record<string, Record<string, string>> = {
  'en': {
    'es': {
      'Welcome to our website': 'Bienvenido a nuestro sitio web',
      'Settings': 'Configuración',
      'Home': 'Inicio',
      'Search': 'Buscar',
      'Sign In': 'Iniciar Sesión',
      'About': 'Acerca de',
      'Contact': 'Contacto',
      'Download App': 'Descargar App',
      'Continue': 'Continuar',
      'Menu': 'Menú',
      'Profile': 'Perfil',
      'Dashboard': 'Tablero',
      'Logout': 'Cerrar Sesión',
      'Help': 'Ayuda'
    },
    'fr': {
      'Welcome to our website': 'Bienvenue sur notre site web',
      'Settings': 'Paramètres',
      'Home': 'Accueil',
      'Search': 'Rechercher',
      'Sign In': 'Se connecter',
      'About': 'À propos',
      'Contact': 'Contact',
      'Download App': 'Télécharger l\'app',
      'Continue': 'Continuer',
      'Menu': 'Menu',
      'Profile': 'Profil',
      'Dashboard': 'Tableau de bord',
      'Logout': 'Déconnexion',
      'Help': 'Aide'
    }
  }
};

export const SELECTION_MODES = {
  AUTO: 'auto' as const,
  MANUAL: 'manual' as const,
  AREA: 'area' as const
};

export const DEFAULT_POSITION = { x: 20, y: 20 };
export const BUBBLE_WIDTH = { minimized: 200, normal: 300 };
export const MONITORING_INTERVAL = 4000;
export const TEXT_RETENTION_TIME = 30000;
export const MAX_DETECTED_TEXTS = 5;