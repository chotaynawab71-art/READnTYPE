export interface SelectionArea {
  x: number;
  y: number;
  width: number;
  height: number;
}

export interface DetectedText {
  id: string;
  text: string;
  translatedText: string;
  confidence: number;
  area: SelectionArea;
  timestamp: number;
}

export type SelectionMode = 'auto' | 'manual' | 'area';

export interface TranslationBubbleProps {
  sourceLang: string;
  targetLang: string;
  onLanguageChange: (source: string, target: string) => void;
  onTranslation: (sourceText: string, translatedText: string) => void;
  isActive: boolean;
  onClose: () => void;
}