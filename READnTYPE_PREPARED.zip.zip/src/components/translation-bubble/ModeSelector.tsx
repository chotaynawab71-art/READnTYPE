import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../ui/select";
import { Eye, MousePointer, Square } from "lucide-react";
import { SelectionMode } from "./types";

interface ModeSelectorProps {
  value: SelectionMode;
  onChange: (value: SelectionMode) => void;
}

export function ModeSelector({ value, onChange }: ModeSelectorProps) {
  return (
    <div className="space-y-2">
      <label className="text-xs font-medium">Mode</label>
      <Select value={value} onValueChange={onChange}>
        <SelectTrigger className="h-8">
          <SelectValue />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="auto">
            <div className="flex items-center gap-2">
              <Eye className="h-3 w-3" />
              Auto Scan
            </div>
          </SelectItem>
          <SelectItem value="manual">
            <div className="flex items-center gap-2">
              <MousePointer className="h-3 w-3" />
              Manual Scan
            </div>
          </SelectItem>
          <SelectItem value="area">
            <div className="flex items-center gap-2">
              <Square className="h-3 w-3" />
              Select Area
            </div>
          </SelectItem>
        </SelectContent>
      </Select>
    </div>
  );
}