import { useState, useRef, useEffect } from "react";
import { Card, CardContent } from "../ui/card";
import { Button } from "../ui/button";
import { LanguageSelector } from "../LanguageSelector";
import { Eye, EyeOff, RefreshCw, Target, Languages } from "lucide-react";
import { toast } from "sonner@2.0.3";
import { motion, AnimatePresence } from "motion/react";

import { BubbleHeader } from "./BubbleHeader";
import { ModeSelector } from "./ModeSelector";
import { TranslationDisplay } from "./TranslationDisplay";
import { mockScanScreen, copyToClipboard } from "./translation-helpers";
import { 
  SELECTION_MODES, 
  DEFAULT_POSITION, 
  BUBBLE_WIDTH, 
  MONITORING_INTERVAL, 
  TEXT_RETENTION_TIME, 
  MAX_DETECTED_TEXTS 
} from "./constants";
import { TranslationBubbleProps, DetectedText, SelectionArea, SelectionMode } from "./types";

export function TranslationBubble({ 
  sourceLang, 
  targetLang, 
  onLanguageChange,
  onTranslation, 
  isActive,
  onClose 
}: TranslationBubbleProps) {
  const [isMinimized, setIsMinimized] = useState(false);
  const [position, setPosition] = useState(DEFAULT_POSITION);
  const [isMonitoring, setIsMonitoring] = useState(false);
  const [isSelectingArea, setIsSelectingArea] = useState(false);
  const [selectionMode, setSelectionMode] = useState<SelectionMode>(SELECTION_MODES.AUTO);
  const [detectedTexts, setDetectedTexts] = useState<DetectedText[]>([]);
  const [currentTranslation, setCurrentTranslation] = useState<DetectedText | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  
  const bubbleRef = useRef<HTMLDivElement>(null);
  const monitoringIntervalRef = useRef<NodeJS.Timeout | null>(null);
  const dragRef = useRef<{ startX: number; startY: number; startPosX: number; startPosY: number } | null>(null);

  const startMonitoring = async () => {
    setIsMonitoring(true);
    toast.success('Screen translation started');
    
    try {
      const texts = await mockScanScreen(undefined, sourceLang, targetLang);
      setDetectedTexts(texts);
      if (texts.length > 0) {
        setCurrentTranslation(texts[0]);
        onTranslation(texts[0].text, texts[0].translatedText);
      }
    } catch (error) {
      console.error('Initial scan error:', error);
    }

    if (selectionMode === SELECTION_MODES.AUTO) {
      monitoringIntervalRef.current = setInterval(async () => {
        try {
          const texts = await mockScanScreen(undefined, sourceLang, targetLang);
          setDetectedTexts(prev => {
            const recent = prev.filter(t => Date.now() - t.timestamp < TEXT_RETENTION_TIME);
            const newTexts = texts.filter(t => !recent.some(r => r.text === t.text));
            
            if (newTexts.length > 0) {
              setCurrentTranslation(newTexts[0]);
              newTexts.forEach(text => {
                onTranslation(text.text, text.translatedText);
              });
            }
            
            return [...recent, ...newTexts].slice(-MAX_DETECTED_TEXTS);
          });
        } catch (error) {
          console.error('Monitoring error:', error);
        }
      }, MONITORING_INTERVAL);
    }
  };

  const stopMonitoring = () => {
    setIsMonitoring(false);
    setCurrentTranslation(null);
    if (monitoringIntervalRef.current) {
      clearInterval(monitoringIntervalRef.current);
      monitoringIntervalRef.current = null;
    }
    toast.success('Screen translation stopped');
  };

  const handleModeChange = (mode: SelectionMode) => {
    setSelectionMode(mode);
    if (isMonitoring) {
      stopMonitoring();
    }
  };

  const handleAreaSelect = () => {
    if (selectionMode === SELECTION_MODES.AREA) {
      setIsSelectingArea(true);
      toast.info('Click and drag to select area for translation');
    }
  };

  const handleManualScan = async () => {
    if (selectionMode === SELECTION_MODES.MANUAL) {
      try {
        const texts = await mockScanScreen(undefined, sourceLang, targetLang);
        setDetectedTexts(texts);
        if (texts.length > 0) {
          setCurrentTranslation(texts[0]);
          onTranslation(texts[0].text, texts[0].translatedText);
        }
        toast.success('Manual scan completed');
      } catch (error) {
        console.error('Manual scan error:', error);
        toast.error('Scan failed');
      }
    }
  };

  const handleCopy = async (text: string) => {
    try {
      await copyToClipboard(text);
      toast.success("Copied to clipboard");
    } catch {
      toast.error("Failed to copy");
    }
  };

  const handleMouseDown = (e: React.MouseEvent) => {
    if (!bubbleRef.current) return;
    
    setIsDragging(true);
    dragRef.current = {
      startX: e.clientX,
      startY: e.clientY,
      startPosX: position.x,
      startPosY: position.y
    };
    
    e.preventDefault();
  };

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (!isDragging || !dragRef.current) return;
      
      const deltaX = e.clientX - dragRef.current.startX;
      const deltaY = e.clientY - dragRef.current.startY;
      
      const newX = Math.max(0, Math.min(window.innerWidth - BUBBLE_WIDTH.normal, dragRef.current.startPosX + deltaX));
      const newY = Math.max(0, Math.min(window.innerHeight - 200, dragRef.current.startPosY + deltaY));
      
      setPosition({ x: newX, y: newY });
    };

    const handleMouseUp = () => {
      setIsDragging(false);
      dragRef.current = null;
    };

    if (isDragging) {
      document.addEventListener('mousemove', handleMouseMove);
      document.addEventListener('mouseup', handleMouseUp);
    }

    return () => {
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
    };
  }, [isDragging]);

  useEffect(() => {
    if (isActive && !isMonitoring && selectionMode === SELECTION_MODES.AUTO) {
      startMonitoring();
    } else if (!isActive && isMonitoring) {
      stopMonitoring();
    }
  }, [isActive, selectionMode]);

  useEffect(() => {
    return () => {
      if (monitoringIntervalRef.current) {
        clearInterval(monitoringIntervalRef.current);
      }
    };
  }, []);

  if (!isActive) return null;

  return (
    <>
      <AnimatePresence>
        <motion.div
          ref={bubbleRef}
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.8 }}
          className="fixed z-50 select-none"
          style={{ 
            left: position.x, 
            top: position.y,
            width: isMinimized ? BUBBLE_WIDTH.minimized : BUBBLE_WIDTH.normal
          }}
        >
          <Card className="shadow-2xl border-2 bg-white/95 backdrop-blur-sm dark:bg-gray-900/95">
            <BubbleHeader
              isMonitoring={isMonitoring}
              onMinimizeToggle={() => setIsMinimized(!isMinimized)}
              onClose={onClose}
              onMouseDown={handleMouseDown}
            />

            {!isMinimized && (
              <CardContent className="p-3 space-y-3">
                <div className="grid grid-cols-2 gap-2">
                  <div className="space-y-1">
                    <label className="text-xs font-medium">From</label>
                    <LanguageSelector
                      value={sourceLang}
                      onValueChange={(value) => onLanguageChange(value, targetLang)}
                      placeholder="Source"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-xs font-medium">To</label>
                    <LanguageSelector
                      value={targetLang}
                      onValueChange={(value) => onLanguageChange(sourceLang, value)}
                      placeholder="Target"
                    />
                  </div>
                </div>

                <ModeSelector value={selectionMode} onChange={handleModeChange} />

                <div className="flex gap-2">
                  {selectionMode === SELECTION_MODES.AUTO && (
                    <Button
                      size="sm"
                      variant={isMonitoring ? "destructive" : "default"}
                      onClick={isMonitoring ? stopMonitoring : startMonitoring}
                      className="flex-1 h-8 text-xs"
                    >
                      {isMonitoring ? (
                        <>
                          <EyeOff className="h-3 w-3 mr-1" />
                          Stop
                        </>
                      ) : (
                        <>
                          <Eye className="h-3 w-3 mr-1" />
                          Start
                        </>
                      )}
                    </Button>
                  )}
                  
                  {selectionMode === SELECTION_MODES.MANUAL && (
                    <Button
                      size="sm"
                      onClick={handleManualScan}
                      className="flex-1 h-8 text-xs"
                    >
                      <RefreshCw className="h-3 w-3 mr-1" />
                      Scan Now
                    </Button>
                  )}
                  
                  {selectionMode === SELECTION_MODES.AREA && (
                    <Button
                      size="sm"
                      onClick={handleAreaSelect}
                      variant={isSelectingArea ? "destructive" : "default"}
                      className="flex-1 h-8 text-xs"
                    >
                      <Target className="h-3 w-3 mr-1" />
                      {isSelectingArea ? 'Cancel' : 'Select Area'}
                    </Button>
                  )}
                </div>

                {currentTranslation && (
                  <TranslationDisplay
                    translation={currentTranslation}
                    onCopy={handleCopy}
                  />
                )}

                {isMonitoring && selectionMode === SELECTION_MODES.AUTO && (
                  <div className="bg-green-50 border border-green-200 rounded p-2 dark:bg-green-950 dark:border-green-800">
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                      <span className="text-xs text-green-700 dark:text-green-300">
                        Auto-scanning active
                      </span>
                    </div>
                  </div>
                )}

                {!isMonitoring && !currentTranslation && (
                  <div className="text-center py-2">
                    <Languages className="h-6 w-6 text-muted-foreground mx-auto mb-1" />
                    <p className="text-xs text-muted-foreground">
                      {selectionMode === SELECTION_MODES.AUTO && 'Click Start to begin auto-scanning'}
                      {selectionMode === SELECTION_MODES.MANUAL && 'Click Scan Now to translate screen'}
                      {selectionMode === SELECTION_MODES.AREA && 'Select an area to translate'}
                    </p>
                  </div>
                )}
              </CardContent>
            )}
          </Card>
        </motion.div>
      </AnimatePresence>

      {isSelectingArea && (
        <div className="fixed inset-0 z-40 bg-black/20 cursor-crosshair">
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="bg-white dark:bg-gray-800 px-4 py-2 rounded-lg shadow-lg">
              <p className="text-sm font-medium">Click and drag to select area</p>
              <p className="text-xs text-muted-foreground">Press Esc to cancel</p>
            </div>
          </div>
        </div>
      )}
    </>
  );
}