import { Button } from "../ui/button";
import { Copy } from "lucide-react";
import { DetectedText } from "./types";

interface TranslationDisplayProps {
  translation: DetectedText;
  onCopy: (text: string) => void;
}

export function TranslationDisplay({ translation, onCopy }: TranslationDisplayProps) {
  return (
    <div className="bg-blue-50 border border-blue-200 rounded p-2 dark:bg-blue-950 dark:border-blue-800">
      <div className="space-y-1">
        <div className="flex items-start justify-between">
          <div className="flex-1 min-w-0">
            <p className="text-xs text-muted-foreground truncate">
              {translation.text}
            </p>
            <p className="text-sm font-medium text-blue-700 dark:text-blue-300">
              {translation.translatedText}
            </p>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => onCopy(translation.translatedText)}
            className="h-6 w-6 p-0 ml-1"
          >
            <Copy className="h-3 w-3" />
          </Button>
        </div>
        <div className="text-xs text-blue-600 dark:text-blue-400">
          Confidence: {(translation.confidence * 100).toFixed(0)}%
        </div>
      </div>
    </div>
  );
}