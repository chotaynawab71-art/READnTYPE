import { useState, useRef, useEffect } from "react";
import { Button } from "./ui/button";
import { Card, CardContent } from "./ui/card";
import { LanguageSelector } from "./LanguageSelector";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { 
  Languages, 
  Eye, 
  EyeOff, 
  Copy, 
  X, 
  Move,
  Square,
  Target,
  MousePointer,
  Settings,
  RefreshCw
} from "lucide-react";
import { toast } from "sonner@2.0.3";
import { motion, AnimatePresence } from "motion/react";

interface TranslationBubbleProps {
  sourceLang: string;
  targetLang: string;
  onLanguageChange: (source: string, target: string) => void;
  onTranslation: (sourceText: string, translatedText: string) => void;
  isActive: boolean;
  onClose: () => void;
}

interface SelectionArea {
  x: number;
  y: number;
  width: number;
  height: number;
}

interface DetectedText {
  id: string;
  text: string;
  translatedText: string;
  confidence: number;
  area: SelectionArea;
  timestamp: number;
}

export function TranslationBubble({ 
  sourceLang, 
  targetLang, 
  onLanguageChange,
  onTranslation, 
  isActive,
  onClose 
}: TranslationBubbleProps) {
  const [isMinimized, setIsMinimized] = useState(false);
  const [position, setPosition] = useState({ x: 20, y: 20 });
  const [isMonitoring, setIsMonitoring] = useState(false);
  const [isSelectingArea, setIsSelectingArea] = useState(false);
  const [selectionMode, setSelectionMode] = useState<'auto' | 'manual' | 'area'>('auto');
  const [detectedTexts, setDetectedTexts] = useState<DetectedText[]>([]);
  const [currentTranslation, setCurrentTranslation] = useState<DetectedText | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  
  const bubbleRef = useRef<HTMLDivElement>(null);
  const monitoringIntervalRef = useRef<NodeJS.Timeout | null>(null);
  const dragRef = useRef<{ startX: number; startY: number; startPosX: number; startPosY: number } | null>(null);
  const selectionRef = useRef<SelectionArea | null>(null);

  // Mock translation function
  const mockTranslateText = async (text: string): Promise<string> => {
    await new Promise(resolve => setTimeout(resolve, 500));
    
    const translations: Record<string, Record<string, string>> = {
      'en': {
        'es': {
          'Hello': 'Hola',
          'Welcome': 'Bienvenido',
          'Settings': 'Configuración',
          'Home': 'Inicio',
          'Search': 'Buscar',
          'Sign In': 'Iniciar Sesión',
          'About': 'Acerca de',
          'Contact': 'Contacto',
          'Download': 'Descargar',
          'Continue': 'Continuar'
        },
        'fr': {
          'Hello': 'Bonjour',
          'Welcome': 'Bienvenue',
          'Settings': 'Paramètres',
          'Home': 'Accueil',
          'Search': 'Rechercher',
          'Sign In': 'Se connecter',
          'About': 'À propos',
          'Contact': 'Contact',
          'Download': 'Télécharger',
          'Continue': 'Continuer'
        }
      }
    };

    const sourceDict = translations[sourceLang];
    const targetDict = sourceDict?.[targetLang];
    return targetDict?.[text] || `[${sourceLang}→${targetLang}] ${text}`;
  };

  // Mock screen scanning
  const mockScanScreen = async (area?: SelectionArea): Promise<DetectedText[]> => {
    await new Promise(resolve => setTimeout(resolve, 300));
    
    const mockTexts = [
      'Welcome to our website',
      'Settings',
      'Home',
      'Search',
      'Sign In',
      'About',
      'Contact',
      'Download App',
      'Continue'
    ];

    const selectedTexts = mockTexts.sort(() => 0.5 - Math.random()).slice(0, Math.floor(Math.random() * 3) + 1);
    
    const results: DetectedText[] = [];
    for (const text of selectedTexts) {
      const translatedText = await mockTranslateText(text);
      results.push({
        id: `${Date.now()}-${Math.random()}`,
        text,
        translatedText,
        confidence: 0.8 + Math.random() * 0.2,
        area: area || {
          x: Math.random() * 500,
          y: Math.random() * 300,
          width: 100 + Math.random() * 200,
          height: 20 + Math.random() * 40
        },
        timestamp: Date.now()
      });
    }
    
    return results;
  };

  const startMonitoring = async () => {
    setIsMonitoring(true);
    toast.success('Screen translation started');
    
    // Initial scan
    try {
      const texts = await mockScanScreen();
      setDetectedTexts(texts);
      if (texts.length > 0) {
        setCurrentTranslation(texts[0]);
        onTranslation(texts[0].text, texts[0].translatedText);
      }
    } catch (error) {
      console.error('Initial scan error:', error);
    }

    // Periodic scanning for auto mode
    if (selectionMode === 'auto') {
      monitoringIntervalRef.current = setInterval(async () => {
        try {
          const texts = await mockScanScreen();
          setDetectedTexts(prev => {
            const recent = prev.filter(t => Date.now() - t.timestamp < 30000);
            const newTexts = texts.filter(t => !recent.some(r => r.text === t.text));
            
            if (newTexts.length > 0) {
              setCurrentTranslation(newTexts[0]);
              newTexts.forEach(text => {
                onTranslation(text.text, text.translatedText);
              });
            }
            
            return [...recent, ...newTexts].slice(-5);
          });
        } catch (error) {
          console.error('Monitoring error:', error);
        }
      }, 4000);
    }
  };

  const stopMonitoring = () => {
    setIsMonitoring(false);
    setCurrentTranslation(null);
    if (monitoringIntervalRef.current) {
      clearInterval(monitoringIntervalRef.current);
      monitoringIntervalRef.current = null;
    }
    toast.success('Screen translation stopped');
  };

  const handleAreaSelect = () => {
    if (selectionMode === 'area') {
      setIsSelectingArea(true);
      toast.info('Click and drag to select area for translation');
    }
  };

  const handleManualScan = async () => {
    if (selectionMode === 'manual') {
      try {
        const texts = await mockScanScreen();
        setDetectedTexts(texts);
        if (texts.length > 0) {
          setCurrentTranslation(texts[0]);
          onTranslation(texts[0].text, texts[0].translatedText);
        }
        toast.success('Manual scan completed');
      } catch (error) {
        console.error('Manual scan error:', error);
        toast.error('Scan failed');
      }
    }
  };

  // Auto-start monitoring when component becomes active
  useEffect(() => {
    if (isActive && !isMonitoring && selectionMode === 'auto') {
      startMonitoring();
    } else if (!isActive && isMonitoring) {
      stopMonitoring();
    }
  }, [isActive, selectionMode]);

  // Clean up on unmount
  useEffect(() => {
    return () => {
      if (monitoringIntervalRef.current) {
        clearInterval(monitoringIntervalRef.current);
      }
    };
  }, []);

  // Handle dragging
  const handleMouseDown = (e: React.MouseEvent) => {
    if (!bubbleRef.current) return;
    
    setIsDragging(true);
    dragRef.current = {
      startX: e.clientX,
      startY: e.clientY,
      startPosX: position.x,
      startPosY: position.y
    };
    
    e.preventDefault();
  };

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (!isDragging || !dragRef.current) return;
      
      const deltaX = e.clientX - dragRef.current.startX;
      const deltaY = e.clientY - dragRef.current.startY;
      
      const newX = Math.max(0, Math.min(window.innerWidth - 300, dragRef.current.startPosX + deltaX));
      const newY = Math.max(0, Math.min(window.innerHeight - 200, dragRef.current.startPosY + deltaY));
      
      setPosition({ x: newX, y: newY });
    };

    const handleMouseUp = () => {
      setIsDragging(false);
      dragRef.current = null;
    };

    if (isDragging) {
      document.addEventListener('mousemove', handleMouseMove);
      document.addEventListener('mouseup', handleMouseUp);
    }

    return () => {
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
    };
  }, [isDragging]);

  const copyToClipboard = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      toast.success("Copied to clipboard");
    } catch {
      toast.error("Failed to copy");
    }
  };

  if (!isActive) return null;

  return (
    <>
      <AnimatePresence>
        <motion.div
          ref={bubbleRef}
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.8 }}
          className="fixed z-50 select-none"
          style={{ 
            left: position.x, 
            top: position.y,
            width: isMinimized ? '200px' : '300px'
          }}
        >
          <Card className="shadow-2xl border-2 bg-white/95 backdrop-blur-sm dark:bg-gray-900/95">
            {/* Header */}
            <div
              className="flex items-center justify-between p-2 bg-gradient-to-r from-blue-500 to-purple-600 text-white rounded-t-lg cursor-move"
              onMouseDown={handleMouseDown}
            >
              <div className="flex items-center gap-2">
                <Languages className="h-4 w-4" />
                <span className="font-medium text-sm">Live Translate</span>
                {isMonitoring && (
                  <div className="w-2 h-2 bg-green-300 rounded-full animate-pulse"></div>
                )}
              </div>
              
              <div className="flex items-center gap-1">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setIsMinimized(!isMinimized)}
                  className="h-6 w-6 p-0 text-white hover:bg-white/20"
                >
                  <Move className="h-3 w-3" />
                </Button>
                
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={onClose}
                  className="h-6 w-6 p-0 text-white hover:bg-red-500/50"
                >
                  <X className="h-3 w-3" />
                </Button>
              </div>
            </div>

            {!isMinimized && (
              <CardContent className="p-3 space-y-3">
                {/* Language Selectors */}
                <div className="grid grid-cols-2 gap-2">
                  <div className="space-y-1">
                    <label className="text-xs font-medium">From</label>
                    <LanguageSelector
                      value={sourceLang}
                      onValueChange={(value) => onLanguageChange(value, targetLang)}
                      placeholder="Source"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-xs font-medium">To</label>
                    <LanguageSelector
                      value={targetLang}
                      onValueChange={(value) => onLanguageChange(sourceLang, value)}
                      placeholder="Target"
                    />
                  </div>
                </div>

                {/* Translation Mode */}
                <div className="space-y-2">
                  <label className="text-xs font-medium">Mode</label>
                  <Select value={selectionMode} onValueChange={(value: 'auto' | 'manual' | 'area') => {
                    setSelectionMode(value);
                    if (isMonitoring) {
                      stopMonitoring();
                    }
                  }}>
                    <SelectTrigger className="h-8">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="auto">
                        <div className="flex items-center gap-2">
                          <Eye className="h-3 w-3" />
                          Auto Scan
                        </div>
                      </SelectItem>
                      <SelectItem value="manual">
                        <div className="flex items-center gap-2">
                          <MousePointer className="h-3 w-3" />
                          Manual Scan
                        </div>
                      </SelectItem>
                      <SelectItem value="area">
                        <div className="flex items-center gap-2">
                          <Square className="h-3 w-3" />
                          Select Area
                        </div>
                      </SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Controls */}
                <div className="flex gap-2">
                  {selectionMode === 'auto' && (
                    <Button
                      size="sm"
                      variant={isMonitoring ? "destructive" : "default"}
                      onClick={isMonitoring ? stopMonitoring : startMonitoring}
                      className="flex-1 h-8 text-xs"
                    >
                      {isMonitoring ? (
                        <>
                          <EyeOff className="h-3 w-3 mr-1" />
                          Stop
                        </>
                      ) : (
                        <>
                          <Eye className="h-3 w-3 mr-1" />
                          Start
                        </>
                      )}
                    </Button>
                  )}
                  
                  {selectionMode === 'manual' && (
                    <Button
                      size="sm"
                      onClick={handleManualScan}
                      className="flex-1 h-8 text-xs"
                    >
                      <RefreshCw className="h-3 w-3 mr-1" />
                      Scan Now
                    </Button>
                  )}
                  
                  {selectionMode === 'area' && (
                    <Button
                      size="sm"
                      onClick={handleAreaSelect}
                      variant={isSelectingArea ? "destructive" : "default"}
                      className="flex-1 h-8 text-xs"
                    >
                      <Target className="h-3 w-3 mr-1" />
                      {isSelectingArea ? 'Cancel' : 'Select Area'}
                    </Button>
                  )}
                </div>

                {/* Current Translation */}
                {currentTranslation && (
                  <div className="bg-blue-50 border border-blue-200 rounded p-2 dark:bg-blue-950 dark:border-blue-800">
                    <div className="space-y-1">
                      <div className="flex items-start justify-between">
                        <div className="flex-1 min-w-0">
                          <p className="text-xs text-muted-foreground truncate">
                            {currentTranslation.text}
                          </p>
                          <p className="text-sm font-medium text-blue-700 dark:text-blue-300">
                            {currentTranslation.translatedText}
                          </p>
                        </div>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => copyToClipboard(currentTranslation.translatedText)}
                          className="h-6 w-6 p-0 ml-1"
                        >
                          <Copy className="h-3 w-3" />
                        </Button>
                      </div>
                      <div className="text-xs text-blue-600 dark:text-blue-400">
                        Confidence: {(currentTranslation.confidence * 100).toFixed(0)}%
                      </div>
                    </div>
                  </div>
                )}

                {/* Status */}
                {isMonitoring && selectionMode === 'auto' && (
                  <div className="bg-green-50 border border-green-200 rounded p-2 dark:bg-green-950 dark:border-green-800">
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                      <span className="text-xs text-green-700 dark:text-green-300">
                        Auto-scanning active
                      </span>
                    </div>
                  </div>
                )}

                {!isMonitoring && !currentTranslation && (
                  <div className="text-center py-2">
                    <Languages className="h-6 w-6 text-muted-foreground mx-auto mb-1" />
                    <p className="text-xs text-muted-foreground">
                      {selectionMode === 'auto' && 'Click Start to begin auto-scanning'}
                      {selectionMode === 'manual' && 'Click Scan Now to translate screen'}
                      {selectionMode === 'area' && 'Select an area to translate'}
                    </p>
                  </div>
                )}
              </CardContent>
            )}
          </Card>
        </motion.div>
      </AnimatePresence>

      {/* Selection Overlay for Area Mode */}
      {isSelectingArea && (
        <div className="fixed inset-0 z-40 bg-black/20 cursor-crosshair">
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="bg-white dark:bg-gray-800 px-4 py-2 rounded-lg shadow-lg">
              <p className="text-sm font-medium">Click and drag to select area</p>
              <p className="text-xs text-muted-foreground">Press Esc to cancel</p>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
</parameter>
</invoke