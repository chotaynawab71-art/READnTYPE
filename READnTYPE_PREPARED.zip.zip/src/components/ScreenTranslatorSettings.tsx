import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Switch } from "./ui/switch";
import { Slider } from "./ui/slider";
import { Badge } from "./ui/badge";
import { Input } from "./ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { 
  Settings, 
  Monitor, 
  Eye, 
  Zap, 
  Bell, 
  Palette, 
  Clock,
  MousePointer,
  Save,
  RotateCcw,
  Download,
  Upload
} from "lucide-react";
import { toast } from "sonner@2.0.3";

interface ScreenTranslatorSettingsProps {
  sourceLang: string;
  targetLang: string;
  onTranslation: (sourceText: string, translatedText: string) => void;
}

interface SettingsConfig {
  autoScan: boolean;
  scanInterval: number;
  showConfidence: boolean;
  enableNotifications: boolean;
  bubbleOpacity: number;
  bubblePosition: 'top-left' | 'top-right' | 'bottom-left' | 'bottom-right';
  theme: 'light' | 'dark' | 'auto';
  hotkey: string;
  maxHistory: number;
  enableHover: boolean;
  hoverDelay: number;
  ocrLanguages: string[];
}

export function ScreenTranslatorSettings({ sourceLang, targetLang, onTranslation }: ScreenTranslatorSettingsProps) {
  const [settings, setSettings] = useState<SettingsConfig>({
    autoScan: true,
    scanInterval: 3000,
    showConfidence: true,
    enableNotifications: true,
    bubbleOpacity: 95,
    bubblePosition: 'top-right',
    theme: 'auto',
    hotkey: 'Ctrl+Shift+T',
    maxHistory: 50,
    enableHover: false,
    hoverDelay: 1000,
    ocrLanguages: ['en', 'es', 'fr', 'de']
  });

  const [isTestMode, setIsTestMode] = useState(false);

  const handleSettingChange = <K extends keyof SettingsConfig>(
    key: K,
    value: SettingsConfig[K]
  ) => {
    setSettings(prev => ({ ...prev, [key]: value }));
  };

  const resetToDefaults = () => {
    setSettings({
      autoScan: true,
      scanInterval: 3000,
      showConfidence: true,
      enableNotifications: true,
      bubbleOpacity: 95,
      bubblePosition: 'top-right',
      theme: 'auto',
      hotkey: 'Ctrl+Shift+T',
      maxHistory: 50,
      enableHover: false,
      hoverDelay: 1000,
      ocrLanguages: ['en', 'es', 'fr', 'de']
    });
    toast.success("Settings reset to defaults");
  };

  const saveSettings = () => {
    // In a real app, this would save to localStorage or backend
    localStorage.setItem('screenTranslatorSettings', JSON.stringify(settings));
    toast.success("Settings saved successfully");
  };

  const exportSettings = () => {
    const dataStr = JSON.stringify(settings, null, 2);
    const blob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'screen_translator_settings.json';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    toast.success("Settings exported successfully");
  };

  const importSettings = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        try {
          const importedSettings = JSON.parse(e.target?.result as string);
          setSettings(importedSettings);
          toast.success("Settings imported successfully");
        } catch (error) {
          toast.error("Invalid settings file");
        }
      };
      reader.readAsText(file);
    }
  };

  const testScreenTranslator = () => {
    setIsTestMode(true);
    toast.success("Test mode activated - Screen translator is now running with current settings");
    onTranslation("Test screen text", "Texto de prueba de pantalla");
    
    setTimeout(() => {
      setIsTestMode(false);
      toast.info("Test mode completed");
    }, 5000);
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Settings className="h-5 w-5" />
            Screen Translator Settings
            <Badge variant="secondary">Advanced</Badge>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* General Settings */}
          <div className="space-y-4">
            <h4 className="font-medium flex items-center gap-2">
              <Monitor className="h-4 w-4" />
              General Settings
            </h4>
            
            <div className="grid gap-4">
              <div className="flex items-center justify-between">
                <div className="space-y-1">
                  <label className="text-sm font-medium">Auto Scan</label>
                  <p className="text-xs text-muted-foreground">Automatically scan screen for text</p>
                </div>
                <Switch
                  checked={settings.autoScan}
                  onCheckedChange={(checked) => handleSettingChange('autoScan', checked)}
                />
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">
                  Scan Interval: {settings.scanInterval / 1000}s
                </label>
                <Slider
                  value={[settings.scanInterval]}
                  onValueChange={([value]) => handleSettingChange('scanInterval', value)}
                  min={1000}
                  max={10000}
                  step={500}
                  className="w-full"
                />
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-1">
                  <label className="text-sm font-medium">Show Confidence Score</label>
                  <p className="text-xs text-muted-foreground">Display OCR confidence percentage</p>
                </div>
                <Switch
                  checked={settings.showConfidence}
                  onCheckedChange={(checked) => handleSettingChange('showConfidence', checked)}
                />
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-1">
                  <label className="text-sm font-medium">Enable Notifications</label>
                  <p className="text-xs text-muted-foreground">Show system notifications for translations</p>
                </div>
                <Switch
                  checked={settings.enableNotifications}
                  onCheckedChange={(checked) => handleSettingChange('enableNotifications', checked)}
                />
              </div>
            </div>
          </div>

          {/* Bubble Appearance */}
          <div className="space-y-4">
            <h4 className="font-medium flex items-center gap-2">
              <Palette className="h-4 w-4" />
              Bubble Appearance
            </h4>
            
            <div className="grid gap-4">
              <div className="space-y-2">
                <label className="text-sm font-medium">
                  Bubble Opacity: {settings.bubbleOpacity}%
                </label>
                <Slider
                  value={[settings.bubbleOpacity]}
                  onValueChange={([value]) => handleSettingChange('bubbleOpacity', value)}
                  min={50}
                  max={100}
                  step={5}
                  className="w-full"
                />
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">Default Position</label>
                <Select 
                  value={settings.bubblePosition} 
                  onValueChange={(value: typeof settings.bubblePosition) => handleSettingChange('bubblePosition', value)}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="top-left">Top Left</SelectItem>
                    <SelectItem value="top-right">Top Right</SelectItem>
                    <SelectItem value="bottom-left">Bottom Left</SelectItem>
                    <SelectItem value="bottom-right">Bottom Right</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">Theme</label>
                <Select 
                  value={settings.theme} 
                  onValueChange={(value: typeof settings.theme) => handleSettingChange('theme', value)}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="light">Light</SelectItem>
                    <SelectItem value="dark">Dark</SelectItem>
                    <SelectItem value="auto">Auto (System)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>

          {/* Advanced Features */}
          <div className="space-y-4">
            <h4 className="font-medium flex items-center gap-2">
              <Zap className="h-4 w-4" />
              Advanced Features
            </h4>
            
            <div className="grid gap-4">
              <div className="space-y-2">
                <label className="text-sm font-medium">Hotkey Combination</label>
                <Input
                  value={settings.hotkey}
                  onChange={(e) => handleSettingChange('hotkey', e.target.value)}
                  placeholder="e.g., Ctrl+Shift+T"
                />
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">
                  Max History Items: {settings.maxHistory}
                </label>
                <Slider
                  value={[settings.maxHistory]}
                  onValueChange={([value]) => handleSettingChange('maxHistory', value)}
                  min={10}
                  max={200}
                  step={10}
                  className="w-full"
                />
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-1">
                  <label className="text-sm font-medium">Enable Hover Translation</label>
                  <p className="text-xs text-muted-foreground">Translate text on mouse hover</p>
                </div>
                <Switch
                  checked={settings.enableHover}
                  onCheckedChange={(checked) => handleSettingChange('enableHover', checked)}
                />
              </div>

              {settings.enableHover && (
                <div className="space-y-2">
                  <label className="text-sm font-medium">
                    Hover Delay: {settings.hoverDelay / 1000}s
                  </label>
                  <Slider
                    value={[settings.hoverDelay]}
                    onValueChange={([value]) => handleSettingChange('hoverDelay', value)}
                    min={500}
                    max={3000}
                    step={250}
                    className="w-full"
                  />
                </div>
              )}
            </div>
          </div>

          {/* OCR Languages */}
          <div className="space-y-4">
            <h4 className="font-medium flex items-center gap-2">
              <Eye className="h-4 w-4" />
              OCR Languages
            </h4>
            
            <div className="space-y-2">
              <p className="text-sm text-muted-foreground">
                Select languages for optical character recognition
              </p>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                {[
                  { code: 'en', name: 'English' },
                  { code: 'es', name: 'Spanish' },
                  { code: 'fr', name: 'French' },
                  { code: 'de', name: 'German' },
                  { code: 'it', name: 'Italian' },
                  { code: 'pt', name: 'Portuguese' },
                  { code: 'ru', name: 'Russian' },
                  { code: 'zh', name: 'Chinese' },
                  { code: 'ja', name: 'Japanese' },
                  { code: 'ko', name: 'Korean' },
                  { code: 'ar', name: 'Arabic' },
                  { code: 'hi', name: 'Hindi' },
                ].map((lang) => (
                  <Button
                    key={lang.code}
                    variant={settings.ocrLanguages.includes(lang.code) ? "default" : "outline"}
                    size="sm"
                    onClick={() => {
                      const newLanguages = settings.ocrLanguages.includes(lang.code)
                        ? settings.ocrLanguages.filter(l => l !== lang.code)
                        : [...settings.ocrLanguages, lang.code];
                      handleSettingChange('ocrLanguages', newLanguages);
                    }}
                  >
                    {lang.name}
                  </Button>
                ))}
              </div>
            </div>
          </div>

          {/* Test Mode */}
          <div className="space-y-4">
            <h4 className="font-medium flex items-center gap-2">
              <MousePointer className="h-4 w-4" />
              Test & Preview
            </h4>
            
            <div className="flex gap-2">
              <Button 
                onClick={testScreenTranslator} 
                disabled={isTestMode}
                className="flex-1"
              >
                {isTestMode ? (
                  <>
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                    Testing...
                  </>
                ) : (
                  <>
                    <Eye className="h-4 w-4 mr-2" />
                    Test Screen Translator
                  </>
                )}
              </Button>
            </div>
            
            {isTestMode && (
              <div className="p-4 bg-blue-50 dark:bg-blue-950/20 rounded-lg">
                <div className="flex items-center gap-2 mb-2">
                  <div className="w-2 h-2 bg-blue-500 rounded-full animate-pulse"></div>
                  <span className="text-sm font-medium">Test Mode Active</span>
                </div>
                <p className="text-sm text-muted-foreground">
                  Screen translator is running with your current settings. 
                  You should see the translation bubble in the {settings.bubblePosition.replace('-', ' ')} corner.
                </p>
              </div>
            )}
          </div>

          {/* Action Buttons */}
          <div className="flex gap-2 pt-4 border-t">
            <Button onClick={saveSettings} className="flex-1">
              <Save className="h-4 w-4 mr-2" />
              Save Settings
            </Button>
            <Button variant="outline" onClick={resetToDefaults}>
              <RotateCcw className="h-4 w-4 mr-2" />
              Reset
            </Button>
            <Button variant="outline" onClick={exportSettings}>
              <Download className="h-4 w-4 mr-2" />
              Export
            </Button>
            <Button variant="outline" onClick={() => document.getElementById('import-input')?.click()}>
              <Upload className="h-4 w-4 mr-2" />
              Import
            </Button>
            <input
              id="import-input"
              type="file"
              accept=".json"
              onChange={importSettings}
              className="hidden"
            />
          </div>
        </CardContent>
      </Card>
    </div>
  );
}