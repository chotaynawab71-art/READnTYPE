import { useState, useEffect, useRef } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Textarea } from "./ui/textarea";
import { Switch } from "./ui/switch";
import { Copy, RotateCcw, Zap, ZapOff, Keyboard, Globe, X, Minus } from "lucide-react";
import { toast } from "sonner@2.0.3";

interface KeyboardTranslateProps {
  sourceLang: string;
  targetLang: string;
  onTranslation: (sourceText: string, translatedText: string) => void;
}

interface VirtualKeyboardLayout {
  [key: string]: string[][];
}

export function KeyboardTranslate({ sourceLang, targetLang, onTranslation }: KeyboardTranslateProps) {
  const [sourceText, setSourceText] = useState("");
  const [translatedText, setTranslatedText] = useState("");
  const [isLiveMode, setIsLiveMode] = useState(true);
  const [isTranslating, setIsTranslating] = useState(false);
  const [showVirtualKeyboard, setShowVirtualKeyboard] = useState(false);
  const [currentKeyboardLang, setCurrentKeyboardLang] = useState('en');
  const [translationDelay, setTranslationDelay] = useState(1000);
  const debounceRef = useRef<NodeJS.Timeout | null>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  // Virtual keyboard layouts for different languages
  const keyboardLayouts: VirtualKeyboardLayout = {
    en: [
      ['q', 'w', 'e', 'r', 't', 'y', 'u', 'i', 'o', 'p'],
      ['a', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l'],
      ['z', 'x', 'c', 'v', 'b', 'n', 'm']
    ],
    es: [
      ['q', 'w', 'e', 'r', 't', 'y', 'u', 'i', 'o', 'p'],
      ['a', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l', 'ñ'],
      ['z', 'x', 'c', 'v', 'b', 'n', 'm']
    ],
    fr: [
      ['a', 'z', 'e', 'r', 't', 'y', 'u', 'i', 'o', 'p'],
      ['q', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l', 'm'],
      ['w', 'x', 'c', 'v', 'b', 'n']
    ],
    de: [
      ['q', 'w', 'e', 'r', 't', 'z', 'u', 'i', 'o', 'p', 'ü'],
      ['a', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l', 'ö', 'ä'],
      ['y', 'x', 'c', 'v', 'b', 'n', 'm']
    ],
    ar: [
      ['ض', 'ص', 'ث', 'ق', 'ف', 'غ', 'ع', 'ه', 'خ', 'ح', 'ج'],
      ['ش', 'س', 'ي', 'ب', 'ل', 'ا', 'ت', 'ن', 'م', 'ك'],
      ['ظ', 'ط', 'ذ', 'د', 'ز', 'ر', 'و']
    ],
    hi: [
      ['क', 'ख', 'ग', 'घ', 'ङ', 'च', 'छ', 'ज', 'झ', 'ञ'],
      ['ट', 'ठ', 'ड', 'ढ', 'ण', 'त', 'थ', 'द', 'ध', 'न'],
      ['प', 'फ', 'ब', 'भ', 'म', 'य', 'र', 'ल', 'व', 'श']
    ],
    ru: [
      ['й', 'ц', 'у', 'к', 'е', 'н', 'г', 'ш', 'щ', 'з', 'х'],
      ['ф', 'ы', 'в', 'а', 'п', 'р', 'о', 'л', 'д', 'ж', 'э'],
      ['я', 'ч', 'с', 'м', 'и', 'т', 'ь', 'б', 'ю']
    ]
  };

  const languageNames: Record<string, string> = {
    en: 'English',
    es: 'Español',
    fr: 'Français', 
    de: 'Deutsch',
    ar: 'العربية',
    hi: 'हिन्दी',
    ru: 'Русский'
  };

  // Mock translation function with better responses
  const mockTranslate = async (text: string): Promise<string> => {
    await new Promise(resolve => setTimeout(resolve, 300));
    
    const mockTranslations: Record<string, Record<string, string>> = {
      en: {
        es: "Esta es una traducción del texto que escribiste usando el teclado virtual.",
        fr: "Ceci est une traduction du texte que vous avez tapé avec le clavier virtuel.",
        de: "Dies ist eine Übersetzung des Textes, den Sie mit der virtuellen Tastatur eingegeben haben.",
        hi: "यह उस पाठ का अनुवाद है जो आपने वर्चुअल कीबोर्ड का उपयोग करके टाइप किया है।"
      }
    };

    if (text.length > 50) {
      return mockTranslations[sourceLang]?.[targetLang] || 
        `[${sourceLang.toUpperCase()} → ${targetLang.toUpperCase()}]: ${text}`;
    }
    
    return `[${sourceLang.toUpperCase()} → ${targetLang.toUpperCase()}]: ${text}`;
  };

  const handleTranslation = async (text: string) => {
    if (!text.trim()) {
      setTranslatedText("");
      return;
    }

    setIsTranslating(true);
    try {
      const result = await mockTranslate(text);
      setTranslatedText(result);
      onTranslation(text, result);
    } catch (error) {
      console.error('Translation error:', error);
      toast.error('Translation failed');
    } finally {
      setIsTranslating(false);
    }
  };

  // Handle live translation with debouncing
  useEffect(() => {
    if (!isLiveMode) return;

    if (debounceRef.current) {
      clearTimeout(debounceRef.current);
    }

    debounceRef.current = setTimeout(() => {
      if (sourceText.trim()) {
        handleTranslation(sourceText);
      } else {
        setTranslatedText("");
      }
    }, translationDelay);

    return () => {
      if (debounceRef.current) {
        clearTimeout(debounceRef.current);
      }
    };
  }, [sourceText, isLiveMode, translationDelay]);

  const handleVirtualKeyPress = (key: string) => {
    if (!textareaRef.current) return;

    const textarea = textareaRef.current;
    const start = textarea.selectionStart || 0;
    const end = textarea.selectionEnd || 0;
    const newText = sourceText.slice(0, start) + key + sourceText.slice(end);
    
    setSourceText(newText);
    
    // Set cursor position after the inserted character
    setTimeout(() => {
      textarea.focus();
      textarea.setSelectionRange(start + 1, start + 1);
    }, 0);
  };

  const handleBackspace = () => {
    if (!textareaRef.current) return;

    const textarea = textareaRef.current;
    const start = textarea.selectionStart || 0;
    const end = textarea.selectionEnd || 0;
    
    let newText: string;
    let newCursorPos: number;
    
    if (start !== end) {
      // Delete selection
      newText = sourceText.slice(0, start) + sourceText.slice(end);
      newCursorPos = start;
    } else if (start > 0) {
      // Delete character before cursor
      newText = sourceText.slice(0, start - 1) + sourceText.slice(start);
      newCursorPos = start - 1;
    } else {
      return;
    }
    
    setSourceText(newText);
    
    setTimeout(() => {
      textarea.focus();
      textarea.setSelectionRange(newCursorPos, newCursorPos);
    }, 0);
  };

  const handleSpace = () => {
    handleVirtualKeyPress(' ');
  };

  const handleTextChange = (value: string) => {
    setSourceText(value);
  };

  const handleManualTranslate = () => {
    if (!sourceText.trim()) {
      toast.error("Please enter text to translate");
      return;
    }
    handleTranslation(sourceText);
  };

  const clearText = () => {
    setSourceText("");
    setTranslatedText("");
    textareaRef.current?.focus();
  };

  const copyToClipboard = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      toast.success("Copied to clipboard");
    } catch {
      toast.error("Failed to copy");
    }
  };

  const getKeyboardLayout = () => {
    return keyboardLayouts[currentKeyboardLang] || keyboardLayouts['en'];
  };

  return (
    <div className="space-y-6">
      {/* Virtual Keyboard Toggle & Settings */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            Virtual Keyboard Translation
            <Button
              onClick={() => setShowVirtualKeyboard(!showVirtualKeyboard)}
              variant={showVirtualKeyboard ? "default" : "outline"}
              className="flex items-center gap-2"
            >
              <Keyboard className="h-4 w-4" />
              {showVirtualKeyboard ? "Hide Keyboard" : "Show Keyboard"}
            </Button>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid md:grid-cols-2 gap-4">
            {/* Live Translation Toggle */}
            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  {isLiveMode ? (
                    <Zap className="h-4 w-4 text-yellow-500" />
                  ) : (
                    <ZapOff className="h-4 w-4 text-muted-foreground" />
                  )}
                  <span className="font-medium">Live Translation</span>
                </div>
                <p className="text-sm text-muted-foreground">
                  Auto-translate as you type
                </p>
              </div>
              <Switch
                checked={isLiveMode}
                onCheckedChange={setIsLiveMode}
              />
            </div>

            {/* Keyboard Language Selector */}
            <div className="space-y-2">
              <label className="text-sm font-medium flex items-center gap-2">
                <Globe className="h-4 w-4" />
                Keyboard Layout
              </label>
              <select
                value={currentKeyboardLang}
                onChange={(e) => setCurrentKeyboardLang(e.target.value)}
                className="w-full p-2 border border-border rounded-md bg-background text-foreground"
              >
                {Object.entries(languageNames).map(([code, name]) => (
                  <option key={code} value={code}>
                    {name}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {isLiveMode && (
            <div className="space-y-2">
              <label className="text-sm font-medium">Translation Delay: {translationDelay}ms</label>
              <input
                type="range"
                min="500"
                max="3000"
                step="250"
                value={translationDelay}
                onChange={(e) => setTranslationDelay(Number(e.target.value))}
                className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer dark:bg-gray-700"
              />
              <div className="flex justify-between text-xs text-muted-foreground">
                <span>Fast (500ms)</span>
                <span>Slow (3s)</span>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Input and Output */}
      <div className="grid md:grid-cols-2 gap-6">
        {/* Source Text */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              Type Here ({languageNames[currentKeyboardLang] || 'English'})
              <div className="flex gap-2">
                {!isLiveMode && (
                  <Button
                    onClick={handleManualTranslate}
                    disabled={!sourceText.trim() || isTranslating}
                    size="sm"
                  >
                    {isTranslating ? "..." : "Translate"}
                  </Button>
                )}
                <Button
                  onClick={clearText}
                  disabled={!sourceText}
                  variant="outline"
                  size="sm"
                >
                  <RotateCcw className="h-4 w-4" />
                </Button>
              </div>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <Textarea
              ref={textareaRef}
              value={sourceText}
              onChange={(e) => handleTextChange(e.target.value)}
              placeholder={showVirtualKeyboard ? 
                "Use the virtual keyboard below or type here..." : 
                (isLiveMode ? "Start typing to see live translation..." : "Type text to translate...")
              }
              className="min-h-40 resize-none"
            />
            <div className="flex items-center justify-between text-sm text-muted-foreground">
              <span>{sourceText.length} characters</span>
              {isLiveMode && sourceText && (
                <div className="flex items-center gap-1">
                  {isTranslating ? (
                    <>
                      <div className="w-2 h-2 bg-blue-500 rounded-full animate-pulse"></div>
                      <span>Translating...</span>
                    </>
                  ) : (
                    <>
                      <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                      <span>Live</span>
                    </>
                  )}
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Translated Text */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              Translation ({targetLang.toUpperCase()})
              <Button
                onClick={() => copyToClipboard(translatedText)}
                disabled={!translatedText}
                variant="outline"
                size="sm"
              >
                <Copy className="h-4 w-4 mr-1" />
                Copy
              </Button>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="min-h-40 p-4 border rounded-lg bg-muted/30">
              {isTranslating ? (
                <div className="flex items-center justify-center h-full">
                  <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-primary"></div>
                </div>
              ) : translatedText ? (
                <p className="whitespace-pre-wrap">{translatedText}</p>
              ) : (
                <p className="text-muted-foreground">
                  {isLiveMode ? 
                    "Translation will appear here as you type..." : 
                    "Click translate to see translation..."
                  }
                </p>
              )}
            </div>
            {translatedText && (
              <div className="mt-4 text-sm text-muted-foreground">
                {translatedText.length} characters
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Virtual Keyboard */}
      {showVirtualKeyboard && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              Virtual Keyboard - {languageNames[currentKeyboardLang]}
              <div className="flex gap-2">
                {Object.entries(languageNames).slice(0, 4).map(([code, name]) => (
                  <Button
                    key={code}
                    variant={currentKeyboardLang === code ? "default" : "outline"}
                    size="sm"
                    onClick={() => setCurrentKeyboardLang(code)}
                    className="text-xs"
                  >
                    {name}
                  </Button>
                ))}
              </div>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {getKeyboardLayout().map((row, rowIndex) => (
              <div key={rowIndex} className="flex justify-center gap-1">
                {row.map((key, keyIndex) => (
                  <Button
                    key={keyIndex}
                    variant="outline"
                    size="sm"
                    onClick={() => handleVirtualKeyPress(key)}
                    className="min-w-8 h-10 text-sm font-medium hover:bg-primary hover:text-primary-foreground"
                  >
                    {key}
                  </Button>
                ))}
              </div>
            ))}
            
            {/* Space and special keys */}
            <div className="flex justify-center gap-2 pt-2">
              <Button
                variant="outline"
                size="sm"
                onClick={handleBackspace}
                className="px-3 h-10"
              >
                <X className="h-4 w-4" />
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={handleSpace}
                className="px-8 h-10"
              >
                <Minus className="h-4 w-4" />
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => handleVirtualKeyPress('.')}
                className="px-3 h-10"
              >
                .
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => handleVirtualKeyPress(',')}
                className="px-3 h-10"
              >
                ,
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}