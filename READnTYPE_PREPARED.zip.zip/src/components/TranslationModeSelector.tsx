import { Tabs, TabsList, TabsTrigger } from "./ui/tabs";
import { Type, Mic, Image, FileText, Keyboard, Monitor } from "lucide-react";

export type TranslationMode = 'text' | 'voice' | 'image' | 'transcribe' | 'keyboard' | 'screen';

interface TranslationModeSelectorProps {
  activeMode: TranslationMode;
  onModeChange: (mode: TranslationMode) => void;
}

export function TranslationModeSelector({ activeMode, onModeChange }: TranslationModeSelectorProps) {
  const modes = [
    { id: 'text' as TranslationMode, label: 'Text', icon: Type },
    { id: 'voice' as TranslationMode, label: 'Voice', icon: Mic },
    { id: 'image' as TranslationMode, label: 'Image', icon: Image },
    { id: 'transcribe' as TranslationMode, label: 'Transcribe', icon: FileText },
    { id: 'keyboard' as TranslationMode, label: 'Keyboard', icon: Keyboard },
    { id: 'screen' as TranslationMode, label: 'Screen', icon: Monitor },
  ];

  return (
    <Tabs value={activeMode} onValueChange={onModeChange} className="w-full">
      <TabsList className="grid w-full grid-cols-6 h-auto p-1">
        {modes.map((mode) => {
          const Icon = mode.icon;
          return (
            <TabsTrigger
              key={mode.id}
              value={mode.id}
              className="flex flex-col gap-1 h-16 data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
            >
              <Icon className="h-5 w-5" />
              <span className="text-xs">{mode.label}</span>
            </TabsTrigger>
          );
        })}
      </TabsList>
    </Tabs>
  );
}