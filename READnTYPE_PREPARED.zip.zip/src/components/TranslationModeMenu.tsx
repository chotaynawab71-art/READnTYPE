import { Card, CardContent } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { 
  Mic, 
  Camera, 
  FileAudio, 
  Keyboard, 
  Monitor,
  FileText,
  ScanLine,
  Languages,
  Settings,
  Zap
} from "lucide-react";

export type TranslationMode = 
  | 'voice' 
  | 'image' 
  | 'transcribe' 
  | 'keyboard' 
  | 'screen'
  | 'pdf'
  | 'camscanner'
  | 'virtual-keyboard'
  | 'screen-settings';

interface TranslationModeMenuProps {
  onModeActivate: (mode: TranslationMode) => void;
  isScreenTranslateActive: boolean;
}

interface ModeCard {
  id: TranslationMode;
  title: string;
  description: string;
  icon: React.ComponentType<{ className?: string }>;
  shortcut: string;
  badge?: string;
  color: string;
  category: 'input' | 'capture' | 'advanced';
}

const getTranslationModes = (isScreenTranslateActive: boolean): ModeCard[] => [
  {
    id: 'voice',
    title: '🎤 Voice Translate',
    description: 'Speak and get instant translation',
    icon: Mic,
    shortcut: 'Ctrl+1',
    color: 'from-blue-500 to-blue-600',
    category: 'input'
  },
  {
    id: 'image',
    title: '📷 Image Translate', 
    description: 'Upload image and extract text',
    icon: Camera,
    shortcut: 'Ctrl+2',
    color: 'from-green-500 to-green-600',
    category: 'capture'
  },
  {
    id: 'transcribe',
    title: '🎧 Transcribe',
    description: 'Convert speech to text',
    icon: FileAudio,
    shortcut: 'Ctrl+3',
    color: 'from-purple-500 to-purple-600',
    category: 'input'
  },
  {
    id: 'keyboard',
    title: '⌨️ Keyboard Translate',
    description: 'Type text for translation',
    icon: Keyboard,
    shortcut: 'Ctrl+4',
    color: 'from-orange-500 to-orange-600',
    category: 'input'
  },
  {
    id: 'screen',
    title: '🖥️ Screen Translate',
    description: 'Live screen text translation',
    icon: Monitor,
    shortcut: 'Ctrl+5',
    badge: isScreenTranslateActive ? 'Active' : undefined,
    color: 'from-red-500 to-red-600',
    category: 'advanced'
  },
  {
    id: 'pdf',
    title: '📄 PDF Translator',
    description: 'Upload & translate PDF documents',
    icon: FileText,
    shortcut: 'Ctrl+6',
    badge: 'Beta',
    color: 'from-indigo-500 to-indigo-600',
    category: 'advanced'
  },
  {
    id: 'camscanner',
    title: '📷 CamScanner & Translate',
    description: 'Scan documents with smart OCR',
    icon: ScanLine,
    shortcut: 'Ctrl+7',
    badge: 'Smart OCR',
    color: 'from-teal-500 to-teal-600',
    category: 'capture'
  },
  {
    id: 'screen-settings',
    title: '⚙️ Screen Translator Settings',
    description: 'Configure screen translation',
    icon: Settings,
    shortcut: 'Ctrl+8',
    badge: 'Advanced',
    color: 'from-gray-500 to-gray-600',
    category: 'advanced'
  },
  {
    id: 'virtual-keyboard',
    title: '🌐 Virtual Keyboard',
    description: 'Multi-language virtual keyboard',
    icon: Languages,
    shortcut: 'Ctrl+9',
    badge: 'Multi-language',
    color: 'from-pink-500 to-pink-600',
    category: 'input'
  }
];

const categoryLabels = {
  input: 'Text Input',
  capture: 'Media Capture',
  advanced: 'Advanced Tools'
};

export function TranslationModeMenu({ onModeActivate, isScreenTranslateActive }: TranslationModeMenuProps) {
  const translationModes = getTranslationModes(isScreenTranslateActive);
  
  const categorizedModes = translationModes.reduce((acc, mode) => {
    if (!acc[mode.category]) {
      acc[mode.category] = [];
    }
    acc[mode.category].push(mode);
    return acc;
  }, {} as Record<string, ModeCard[]>);

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="text-center space-y-4">
        <div className="flex items-center justify-center gap-3 mb-4">
          <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-purple-600 rounded-xl flex items-center justify-center">
            <Languages className="h-6 w-6 text-white" />
          </div>
          <div>
            <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
              Translation Hub Pro
            </h1>
            <p className="text-lg text-muted-foreground">
              9 powerful translation modes with AI-powered accuracy
            </p>
          </div>
        </div>
        
        <div className="flex items-center justify-center gap-2">
          <Badge variant="secondary" className="text-sm">
            <Zap className="h-3 w-3 mr-1" />
            Keyboard shortcuts available
          </Badge>
          <Badge variant="outline" className="text-sm">
            Press Ctrl+0 to return to menu
          </Badge>
        </div>
      </div>

      {/* Mode Categories */}
      {Object.entries(categorizedModes).map(([category, modes]) => (
        <div key={category} className="space-y-4">
          <div className="flex items-center gap-2">
            <h3 className="text-xl font-semibold">{categoryLabels[category as keyof typeof categoryLabels]}</h3>
            <Badge variant="outline">{modes.length} modes</Badge>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
            {modes.map((mode, index) => {
              const Icon = mode.icon;
              const isActive = mode.id === 'screen' && isScreenTranslateActive;
              
              return (
                <Card 
                  key={mode.id}
                  className={`group cursor-pointer transition-all duration-300 hover:shadow-lg hover:scale-105 ${
                    isActive ? 'ring-2 ring-blue-500 shadow-lg' : ''
                  }`}
                  onClick={() => onModeActivate(mode.id)}
                >
                  <CardContent className="p-6">
                    <div className="space-y-4">
                      {/* Header with number and icon */}
                      <div className="flex items-center justify-between">
                        <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${mode.color} flex items-center justify-center text-white shadow-lg`}>
                          <Icon className="h-6 w-6" />
                        </div>
                        <div className="flex flex-col items-end gap-1">
                          <div className="w-8 h-8 rounded-lg bg-muted flex items-center justify-center text-sm font-bold">
                            {category === 'input' ? index + 1 : 
                             category === 'capture' ? index + 3 : 
                             index + 6}
                          </div>
                          {mode.badge && (
                            <Badge 
                              variant={isActive ? "default" : "secondary"} 
                              className="text-xs"
                            >
                              {mode.badge}
                            </Badge>
                          )}
                        </div>
                      </div>

                      {/* Content */}
                      <div className="space-y-2">
                        <h3 className="font-semibold text-lg group-hover:text-primary transition-colors">
                          {mode.title}
                        </h3>
                        <p className="text-sm text-muted-foreground leading-relaxed">
                          {mode.description}
                        </p>
                      </div>

                      {/* Footer */}
                      <div className="flex items-center justify-between pt-2 border-t">
                        <Badge variant="outline" className="text-xs">
                          {mode.shortcut}
                        </Badge>
                        <Button 
                          size="sm" 
                          variant={isActive ? "default" : "ghost"}
                          className="text-xs"
                        >
                          {isActive ? 'Active' : 'Launch'}
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      ))}

      {/* Always-visible keyboard preview */}
      <Card className="bg-gradient-to-r from-blue-50 to-purple-50 dark:from-blue-950/20 dark:to-purple-950/20 border-dashed">
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-pink-500 to-pink-600 flex items-center justify-center text-white">
                <Languages className="h-5 w-5" />
              </div>
              <div>
                <h4 className="font-medium">Virtual Keyboard Preview</h4>
                <p className="text-sm text-muted-foreground">
                  Multi-language support: Urdu • Punjabi • Sindhi • Arabic • Hindi • Bengali
                </p>
              </div>
            </div>
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => onModeActivate('virtual-keyboard')}
            >
              <Keyboard className="h-4 w-4 mr-2" />
              Try Now
            </Button>
          </div>
          
          {/* Mini keyboard preview */}
          <div className="mt-4 flex justify-center">
            <div className="flex gap-1 p-2 bg-white dark:bg-gray-800 rounded border">
              {['ض', 'ص', 'ث', 'ق', 'ف', 'غ', 'ع', 'ہ'].map((key, i) => (
                <div key={i} className="w-6 h-6 border rounded text-xs flex items-center justify-center bg-muted/50">
                  {key}
                </div>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}