import { useState, useEffect, useCallback } from "react";
import { Card, CardContent } from "./ui/card";
import { Button } from "./ui/button";
import { Textarea } from "./ui/textarea";
import { EnhancedLanguageSelector } from "./EnhancedLanguageSelector";
import { 
  ArrowRightLeft, 
  Mic, 
  Camera, 
  Volume2,
  Copy,
  Star,
  RotateCcw,
  Loader2
} from "lucide-react";
import { toast } from "sonner@2.0.3";

interface GoogleTranslateInterfaceProps {
  sourceLang: string;
  targetLang: string;
  onLanguageChange: (source: string, target: string) => void;
  onTranslation: (sourceText: string, translatedText: string) => void;
}

export function GoogleTranslateInterface({
  sourceLang,
  targetLang,
  onLanguageChange,
  onTranslation
}: GoogleTranslateInterfaceProps) {
  const [sourceText, setSourceText] = useState("");
  const [translatedText, setTranslatedText] = useState("");
  const [isTranslating, setIsTranslating] = useState(false);
  const [isListening, setIsListening] = useState(false);

  const handleSwapLanguages = () => {
    onLanguageChange(targetLang, sourceLang);
    setSourceText(translatedText);
    setTranslatedText(sourceText);
  };

  const translateText = useCallback(async (text: string) => {
    if (!text.trim()) {
      setTranslatedText("");
      return;
    }

    setIsTranslating(true);
    
    try {
      // Simulate translation delay
      await new Promise(resolve => setTimeout(resolve, 500));
      
      // Mock translation - in real app, this would call translation API
      const mockTranslations: Record<string, Record<string, string>> = {
        'en': {
          'es': 'Hola, ¿cómo estás? Este es un ejemplo de traducción en vivo.',
          'fr': 'Bonjour, comment allez-vous? Ceci est un exemple de traduction en direct.',
          'ur': 'سلام، آپ کیسے ہیں؟ یہ لائیو ترجمے کی ایک مثال ہے۔',
          'hi': 'नमस्ते, आप कैसे हैं? यह लाइव अनुवाद का एक उदाहरण है।',
          'ar': 'مرحبا، كيف حالك؟ هذا مثال على الترجمة المباشرة.',
          'pa': 'ਸਤ ਸ੍ਰੀ ਅਕਾਲ, ਤੁਸੀਂ ਕਿਵੇਂ ਹੋ? ਇਹ ਲਾਈਵ ਅਨੁਵਾਦ ਦਾ ਇੱਕ ਉਦਾਹਰਨ ਹੈ।'
        },
        'es': {
          'en': 'Hello, how are you? This is an example of live translation.',
          'fr': 'Bonjour, comment allez-vous? Ceci est un exemple de traduction en direct.'
        },
        'ur': {
          'en': 'Hello, how are you? This is an example of live translation.',
          'es': 'Hola, ¿cómo estás? Este es un ejemplo de traducción en vivo.'
        },
        'hi': {
          'en': 'Hello, how are you? This is an example of live translation.',
          'es': 'Hola, ¿cómo estás? Este es un ejemplo de traducción en vivo.'
        }
      };

      let translated = '';
      
      // Simple word-by-word translation for longer texts
      if (text.length > 50) {
        const words = text.split(' ');
        const translatedWords = words.map((word, index) => {
          if (mockTranslations[sourceLang]?.[targetLang]) {
            const sample = mockTranslations[sourceLang][targetLang];
            const sampleWords = sample.split(' ');
            return sampleWords[index % sampleWords.length] || word;
          }
          return word;
        });
        translated = translatedWords.join(' ');
      } else {
        translated = mockTranslations[sourceLang]?.[targetLang] || 
                   `[${sourceLang} → ${targetLang}]: ${text}`;
      }
      
      setTranslatedText(translated);
      onTranslation(text, translated);
    } catch (error) {
      toast.error('Translation failed');
    } finally {
      setIsTranslating(false);
    }
  }, [sourceLang, targetLang, onTranslation]);

  // Live translation - translate as user types
  useEffect(() => {
    if (sourceText.trim()) {
      const timeoutId = setTimeout(() => {
        translateText(sourceText);
      }, 800); // Debounce for 800ms
      
      return () => clearTimeout(timeoutId);
    } else {
      setTranslatedText("");
    }
  }, [sourceText, translateText]);

  // Re-translate when languages change
  useEffect(() => {
    if (sourceText.trim()) {
      translateText(sourceText);
    }
  }, [sourceLang, targetLang, translateText]);

  const handleVoiceInput = () => {
    setIsListening(true);
    toast.info("Voice input activated");
    
    // Mock voice input
    setTimeout(() => {
      setSourceText("Hello, this is a voice input example that will be translated live.");
      setIsListening(false);
      toast.success("Voice input completed");
    }, 2000);
  };

  const handleImageUpload = () => {
    toast.info("Image upload feature - upload an image to extract text");
    // Mock image text extraction
    setTimeout(() => {
      setSourceText("This text was extracted from an image and will be translated automatically.");
      toast.success("Text extracted from image");
    }, 1500);
  };

  const copyToClipboard = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      toast.success("Copied to clipboard");
    } catch {
      toast.error("Failed to copy");
    }
  };

  const playAudio = (text: string, lang: string) => {
    toast.info(`Playing audio: ${text.substring(0, 30)}...`);
    // In real app, this would use Web Speech API or TTS service
  };

  const clearText = () => {
    setSourceText("");
    setTranslatedText("");
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Language Selection */}
      <Card className="border-0 shadow-sm">
        <CardContent className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-5 gap-4 items-center">
            <div className="md:col-span-2">
              <EnhancedLanguageSelector
                value={sourceLang}
                onValueChange={(value) => onLanguageChange(value, targetLang)}
                placeholder="Detect language"
              />
            </div>
            
            <div className="flex justify-center">
              <Button
                variant="ghost"
                size="sm"
                onClick={handleSwapLanguages}
                className="rounded-full h-10 w-10 p-0 hover:bg-blue-50"
              >
                <ArrowRightLeft className="h-4 w-4 text-blue-600" />
              </Button>
            </div>
            
            <div className="md:col-span-2">
              <EnhancedLanguageSelector
                value={targetLang}
                onValueChange={(value) => onLanguageChange(sourceLang, value)}
                placeholder="Select language"
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Translation Interface */}
      <div className="grid md:grid-cols-2 gap-1">
        {/* Source Text */}
        <Card className="border-0 shadow-sm">
          <CardContent className="p-0">
            <div className="border-b px-4 py-3 bg-gray-50 dark:bg-gray-800/50">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium text-gray-600 dark:text-gray-400">
                  {sourceLang.toUpperCase()}
                </span>
                <div className="flex items-center gap-2">
                  {sourceText && (
                    <>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => playAudio(sourceText, sourceLang)}
                        className="h-8 w-8 p-0"
                      >
                        <Volume2 className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={clearText}
                        className="h-8 w-8 p-0"
                      >
                        <RotateCcw className="h-4 w-4" />
                      </Button>
                    </>
                  )}
                </div>
              </div>
            </div>
            
            <div className="p-4 relative">
              <Textarea
                value={sourceText}
                onChange={(e) => setSourceText(e.target.value)}
                placeholder="Enter text to translate (translates live as you type)"
                className="min-h-[200px] border-0 p-0 text-lg resize-none focus-visible:ring-0 bg-transparent"
                dir={['ar', 'ur', 'sd', 'fa'].includes(sourceLang) ? 'rtl' : 'ltr'}
              />
              
              {/* Input Tools */}
              <div className="absolute bottom-4 right-4 flex gap-2">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={handleVoiceInput}
                  disabled={isListening}
                  className="h-10 w-10 p-0 rounded-full hover:bg-blue-50"
                >
                  <Mic className={`h-5 w-5 ${isListening ? 'text-red-500 animate-pulse' : 'text-blue-600'}`} />
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={handleImageUpload}
                  className="h-10 w-10 p-0 rounded-full hover:bg-blue-50"
                >
                  <Camera className="h-5 w-5 text-blue-600" />
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Translated Text */}
        <Card className="border-0 shadow-sm bg-blue-50 dark:bg-blue-950/20">
          <CardContent className="p-0">
            <div className="border-b px-4 py-3 bg-blue-100 dark:bg-blue-900/30">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium text-blue-700 dark:text-blue-300">
                  {targetLang.toUpperCase()}
                </span>
                <div className="flex items-center gap-2">
                  {translatedText && (
                    <>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => playAudio(translatedText, targetLang)}
                        className="h-8 w-8 p-0"
                      >
                        <Volume2 className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => copyToClipboard(translatedText)}
                        className="h-8 w-8 p-0"
                      >
                        <Copy className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="h-8 w-8 p-0"
                      >
                        <Star className="h-4 w-4" />
                      </Button>
                    </>
                  )}
                </div>
              </div>
            </div>
            
            <div className="p-4 min-h-[200px] relative">
              {isTranslating ? (
                <div className="flex items-center gap-2 text-blue-600">
                  <Loader2 className="h-4 w-4 animate-spin" />
                  <span className="text-sm">Translating...</span>
                </div>
              ) : translatedText ? (
                <p 
                  className="text-lg leading-relaxed text-gray-800 dark:text-gray-200"
                  dir={['ar', 'ur', 'sd', 'fa'].includes(targetLang) ? 'rtl' : 'ltr'}
                >
                  {translatedText}
                </p>
              ) : (
                <p className="text-gray-500 dark:text-gray-400 text-lg">
                  Translation will appear here automatically
                </p>
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Live Translation Indicator */}
      {sourceText && (
        <div className="flex justify-center">
          <div className="flex items-center gap-2 px-3 py-1 bg-green-100 dark:bg-green-900/20 rounded-full text-green-700 dark:text-green-300 text-sm">
            <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
            Live Translation Active
          </div>
        </div>
      )}

      {/* Usage Examples */}
      <Card className="border-0 shadow-sm bg-gray-50 dark:bg-gray-800/50">
        <CardContent className="p-4">
          <h4 className="font-medium mb-3 text-sm text-gray-600 dark:text-gray-400">Try these examples:</h4>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-2">
            {[
              "Hello, how are you today?",
              "What time is the meeting?",
              "Thank you for your help!"
            ].map((example, index) => (
              <Button
                key={index}
                variant="ghost"
                size="sm"
                onClick={() => setSourceText(example)}
                className="justify-start text-left h-auto p-2 text-sm text-gray-600 dark:text-gray-400 hover:text-blue-600 hover:bg-blue-50"
              >
                {example}
              </Button>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}