import { useState, useRef } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Progress } from "./ui/progress";
import { Badge } from "./ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { 
  FileText, 
  Upload, 
  Download, 
  Eye, 
  Loader2, 
  CheckCircle, 
  AlertCircle,
  RefreshCw,
  FileDown,
  FileType
} from "lucide-react";
import { toast } from "sonner@2.0.3";

interface PDFTranslatorProps {
  sourceLang: string;
  targetLang: string;
  onTranslation: (sourceText: string, translatedText: string) => void;
}

interface ProcessingStep {
  id: string;
  name: string;
  status: 'pending' | 'processing' | 'completed' | 'error';
  progress: number;
}

type OutputFormat = 'pdf' | 'docx' | 'txt';

export function PDFTranslator({ sourceLang, targetLang, onTranslation }: PDFTranslatorProps) {
  const [file, setFile] = useState<File | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [extractedText, setExtractedText] = useState("");
  const [translatedText, setTranslatedText] = useState("");
  const [currentStep, setCurrentStep] = useState(0);
  const [outputFormat, setOutputFormat] = useState<OutputFormat>('pdf');
  const [steps, setSteps] = useState<ProcessingStep[]>([
    { id: 'upload', name: 'File Upload', status: 'pending', progress: 0 },
    { id: 'extract', name: 'Text Extraction', status: 'pending', progress: 0 },
    { id: 'translate', name: 'Translation', status: 'pending', progress: 0 },
    { id: 'generate', name: 'Document Generation', status: 'pending', progress: 0 }
  ]);
  
  const fileInputRef = useRef<HTMLInputElement>(null);

  const mockProcessPDF = async () => {
    setIsProcessing(true);
    setCurrentStep(0);

    try {
      // Step 1: File Upload
      await updateStep(0, 'processing', 50);
      await new Promise(resolve => setTimeout(resolve, 800));
      await updateStep(0, 'completed', 100);

      // Step 2: Text Extraction
      setCurrentStep(1);
      await updateStep(1, 'processing', 30);
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      const mockText = `Advanced Translation Document
      
This document contains comprehensive information about modern translation technologies and their applications in various industries.

Chapter 1: Introduction to Machine Translation
Machine translation has evolved significantly over the past decade. With the advent of neural networks and artificial intelligence, we can now achieve translation quality that rivals human translators in many contexts.

Key benefits include:
• Real-time translation capabilities
• Support for over 100 languages
• Integration with various document formats
• Preservation of original formatting

Chapter 2: Implementation Strategies
Organizations implementing translation solutions should consider factors such as accuracy requirements, volume of content, and integration with existing workflows.

Best practices include:
1. Selecting appropriate translation engines
2. Implementing quality assurance processes
3. Training staff on new technologies
4. Regular evaluation and optimization

Conclusion:
The future of translation technology looks promising, with continued improvements in accuracy and capabilities expected in the coming years.`;
      
      setExtractedText(mockText);
      await updateStep(1, 'completed', 100);

      // Step 3: Translation
      setCurrentStep(2);
      await updateStep(2, 'processing', 20);
      await new Promise(resolve => setTimeout(resolve, 2500));
      
      const mockTranslations: Record<string, string> = {
        'es': `Documento de Traducción Avanzada
        
Este documento contiene información integral sobre las tecnologías de traducción modernas y sus aplicaciones en diversas industrias.

Capítulo 1: Introducción a la Traducción Automática
La traducción automática ha evolucionado significativamente en la última década. Con el advenimiento de las redes neuronales y la inteligencia artificial, ahora podemos lograr una calidad de traducción que rivaliza con los traductores humanos en muchos contextos.

Los beneficios clave incluyen:
• Capacidades de traducción en tiempo real
• Soporte para más de 100 idiomas
• Integración con varios formatos de documentos
• Preservación del formato original

Capítulo 2: Estrategias de Implementación
Las organizaciones que implementan soluciones de traducción deben considerar factores como los requisitos de precisión, el volumen de contenido y la integración con los flujos de trabajo existentes.

Las mejores prácticas incluyen:
1. Seleccionar motores de traducción apropiados
2. Implementar procesos de aseguramiento de calidad
3. Capacitar al personal en nuevas tecnologías
4. Evaluación y optimización regulares

Conclusión:
El futuro de la tecnología de traducción se ve prometedor, con mejoras continuas en precisión y capacidades esperadas en los próximos años.`,
        'fr': `Document de Traduction Avancée
        
Ce document contient des informations complètes sur les technologies de traduction modernes et leurs applications dans diverses industries.

Chapitre 1: Introduction à la Traduction Automatique
La traduction automatique a considérablement évolué au cours de la dernière décennie. Avec l'avènement des réseaux de neurones et de l'intelligence artificielle, nous pouvons maintenant atteindre une qualité de traduction qui rivalise avec les traducteurs humains dans de nombreux contextes.

Les avantages clés incluent:
• Capacités de traduction en temps réel
• Support pour plus de 100 langues
• Intégration avec divers formats de documents
• Préservation du formatage original

Chapitre 2: Stratégies d'Implémentation
Les organisations implémentant des solutions de traduction doivent considérer des facteurs tels que les exigences de précision, le volume de contenu et l'intégration avec les flux de travail existants.

Les meilleures pratiques incluent:
1. Sélectionner des moteurs de traduction appropriés
2. Implémenter des processus d'assurance qualité
3. Former le personnel aux nouvelles technologies
4. Évaluation et optimisation régulières

Conclusion:
L'avenir de la technologie de traduction semble prometteur, avec des améliorations continues en précision et capacités attendues dans les années à venir.`
      };
      
      const translation = mockTranslations[targetLang] || `[Translated to ${targetLang}]: ${mockText}`;
      setTranslatedText(translation);
      await updateStep(2, 'completed', 100);

      // Step 4: Document Generation
      setCurrentStep(3);
      await updateStep(3, 'processing', 60);
      await new Promise(resolve => setTimeout(resolve, 1500));
      await updateStep(3, 'completed', 100);

      setIsProcessing(false);
      onTranslation(mockText, translation);
      toast.success(`PDF translation completed! Ready for ${outputFormat.toUpperCase()} download.`);
    } catch (error) {
      setIsProcessing(false);
      toast.error("Translation failed. Please try again.");
    }
  };

  const updateStep = async (stepIndex: number, status: ProcessingStep['status'], progress: number) => {
    setSteps(prev => prev.map((step, index) => 
      index === stepIndex ? { ...step, status, progress } : step
    ));
    await new Promise(resolve => setTimeout(resolve, 200));
  };

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = event.target.files?.[0];
    if (selectedFile) {
      if (selectedFile.type === 'application/pdf' || selectedFile.name.endsWith('.pdf')) {
        setFile(selectedFile);
        setExtractedText("");
        setTranslatedText("");
        setSteps(prev => prev.map(step => ({ ...step, status: 'pending', progress: 0 })));
        toast.success("PDF file selected successfully");
      } else {
        toast.error("Please select a valid PDF file");
      }
    }
  };

  const handleUploadClick = () => {
    fileInputRef.current?.click();
  };

  const downloadTranslatedDocument = async () => {
    if (!translatedText) return;

    try {
      let blob: Blob;
      let filename: string;
      
      switch (outputFormat) {
        case 'pdf':
          // In real implementation, this would generate an actual PDF
          const pdfContent = `%PDF-1.4
1 0 obj
<<
/Type /Catalog
/Pages 2 0 R
>>
endobj

2 0 obj
<<
/Type /Pages
/Kids [3 0 R]
/Count 1
>>
endobj

3 0 obj
<<
/Type /Page
/Parent 2 0 R
/MediaBox [0 0 612 792]
/Contents 4 0 R
>>
endobj

4 0 obj
<<
/Length ${translatedText.length + 100}
>>
stream
BT
/F1 12 Tf
50 750 Td
(${translatedText.substring(0, 100)}...) Tj
ET
endstream
endobj

xref
0 5
0000000000 65535 f 
0000000010 00000 n 
0000000079 00000 n 
0000000173 00000 n 
0000000301 00000 n 
trailer
<<
/Size 5
/Root 1 0 R
>>
startxref
${400 + translatedText.length}
%%EOF`;
          blob = new Blob([pdfContent], { type: 'application/pdf' });
          filename = `translated_${file?.name?.replace('.pdf', '.pdf') || 'document.pdf'}`;
          break;
          
        case 'docx':
          // In real implementation, this would generate an actual DOCX file
          const docxContent = `<?xml version="1.0" encoding="UTF-8"?>
<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
  <w:body>
    <w:p><w:t>${translatedText}</w:t></w:p>
  </w:body>
</w:document>`;
          blob = new Blob([docxContent], { 
            type: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' 
          });
          filename = `translated_${file?.name?.replace('.pdf', '.docx') || 'document.docx'}`;
          break;
          
        case 'txt':
        default:
          blob = new Blob([translatedText], { type: 'text/plain' });
          filename = `translated_${file?.name?.replace('.pdf', '.txt') || 'document.txt'}`;
          break;
      }
      
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      
      toast.success(`${outputFormat.toUpperCase()} file downloaded successfully!`);
    } catch (error) {
      toast.error("Download failed. Please try again.");
    }
  };

  const resetProcess = () => {
    setFile(null);
    setExtractedText("");
    setTranslatedText("");
    setCurrentStep(0);
    setSteps(prev => prev.map(step => ({ ...step, status: 'pending', progress: 0 })));
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const getStepIcon = (step: ProcessingStep) => {
    switch (step.status) {
      case 'processing':
        return <Loader2 className="h-4 w-4 animate-spin text-blue-500" />;
      case 'completed':
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'error':
        return <AlertCircle className="h-4 w-4 text-red-500" />;
      default:
        return <div className="h-4 w-4 rounded-full border-2 border-muted-foreground" />;
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="h-5 w-5" />
            Advanced PDF Translator
            <Badge variant="secondary">Multi-format</Badge>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Upload Section */}
          <div className="space-y-4">
            <div className="border-2 border-dashed border-muted-foreground/25 rounded-lg p-8 text-center">
              {file ? (
                <div className="space-y-3">
                  <FileText className="h-12 w-12 text-blue-500 mx-auto" />
                  <div>
                    <p className="font-medium">{file.name}</p>
                    <p className="text-sm text-muted-foreground">
                      {(file.size / 1024 / 1024).toFixed(2)} MB
                    </p>
                  </div>
                  
                  {/* Output Format Selection */}
                  <div className="flex items-center justify-center gap-4">
                    <div className="flex items-center gap-2">
                      <label className="text-sm font-medium">Output Format:</label>
                      <Select value={outputFormat} onValueChange={(value: OutputFormat) => setOutputFormat(value)}>
                        <SelectTrigger className="w-24">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="pdf">
                            <div className="flex items-center gap-2">
                              <FileText className="h-4 w-4" />
                              PDF
                            </div>
                          </SelectItem>
                          <SelectItem value="docx">
                            <div className="flex items-center gap-2">
                              <FileType className="h-4 w-4" />
                              Word
                            </div>
                          </SelectItem>
                          <SelectItem value="txt">
                            <div className="flex items-center gap-2">
                              <FileDown className="h-4 w-4" />
                              Text
                            </div>
                          </SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  
                  <div className="flex gap-2 justify-center">
                    <Button onClick={() => mockProcessPDF()} disabled={isProcessing}>
                      {isProcessing ? (
                        <>
                          <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                          Processing...
                        </>
                      ) : (
                        <>
                          <FileText className="h-4 w-4 mr-2" />
                          Translate to {outputFormat.toUpperCase()}
                        </>
                      )}
                    </Button>
                    <Button variant="outline" onClick={resetProcess}>
                      <RefreshCw className="h-4 w-4 mr-2" />
                      Reset
                    </Button>
                  </div>
                </div>
              ) : (
                <div className="space-y-3">
                  <Upload className="h-12 w-12 text-muted-foreground mx-auto" />
                  <div>
                    <p className="font-medium">Upload PDF Document</p>
                    <p className="text-sm text-muted-foreground">
                      Supports text-based PDFs • Max size: 50MB
                    </p>
                  </div>
                  <Button onClick={handleUploadClick}>
                    <Upload className="h-4 w-4 mr-2" />
                    Select PDF File
                  </Button>
                </div>
              )}
            </div>
            
            <input
              ref={fileInputRef}
              type="file"
              accept=".pdf,application/pdf"
              onChange={handleFileSelect}
              className="hidden"
            />
          </div>

          {/* Processing Steps */}
          {file && (
            <div className="space-y-4">
              <h4 className="font-medium">Processing Pipeline</h4>
              <div className="space-y-3">
                {steps.map((step, index) => (
                  <div key={step.id} className="space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        {getStepIcon(step)}
                        <span className={`text-sm ${step.status === 'completed' ? 'text-green-600' : ''}`}>
                          {step.name}
                        </span>
                      </div>
                      <Badge variant={
                        step.status === 'completed' ? 'default' : 
                        step.status === 'processing' ? 'secondary' : 
                        step.status === 'error' ? 'destructive' : 'outline'
                      }>
                        {step.status === 'completed' ? 'Done' :
                         step.status === 'processing' ? 'Processing...' :
                         step.status === 'error' ? 'Error' : 'Pending'}
                      </Badge>
                    </div>
                    {step.status === 'processing' && (
                      <Progress value={step.progress} className="h-2" />
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Results */}
          {(extractedText || translatedText) && (
            <div className="grid md:grid-cols-2 gap-4">
              {extractedText && (
                <Card>
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <h4 className="font-medium">Extracted Text ({sourceLang.toUpperCase()})</h4>
                      <Badge variant="outline">
                        <Eye className="h-3 w-3 mr-1" />
                        Preview
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="max-h-60 overflow-y-auto p-3 bg-muted/50 rounded text-sm">
                      {extractedText}
                    </div>
                  </CardContent>
                </Card>
              )}

              {translatedText && (
                <Card>
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <h4 className="font-medium">Translated Text ({targetLang.toUpperCase()})</h4>
                      <Button size="sm" onClick={downloadTranslatedDocument}>
                        <Download className="h-3 w-3 mr-1" />
                        Download {outputFormat.toUpperCase()}
                      </Button>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="max-h-60 overflow-y-auto p-3 bg-blue-50 dark:bg-blue-950/20 rounded text-sm">
                      {translatedText}
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>
          )}

          {/* Output Format Info */}
          <Card className="bg-muted/30">
            <CardContent className="pt-4">
              <h4 className="font-medium mb-2">Supported Output Formats</h4>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                <div className="flex items-center gap-2">
                  <FileText className="h-4 w-4 text-red-500" />
                  <div>
                    <span className="font-medium">PDF</span>
                    <p className="text-xs text-muted-foreground">Preserves original layout</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <FileType className="h-4 w-4 text-blue-500" />
                  <div>
                    <span className="font-medium">Word (DOCX)</span>
                    <p className="text-xs text-muted-foreground">Editable document</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <FileDown className="h-4 w-4 text-green-500" />
                  <div>
                    <span className="font-medium">Plain Text</span>
                    <p className="text-xs text-muted-foreground">Simple text format</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </CardContent>
      </Card>
    </div>
  );
}