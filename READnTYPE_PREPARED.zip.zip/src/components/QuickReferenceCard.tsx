import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { Keyboard, Mic, Image, FileText, Monitor, Zap } from "lucide-react";

interface QuickReferenceCardProps {
  isVisible: boolean;
}

export function QuickReferenceCard({ isVisible }: QuickReferenceCardProps) {
  if (!isVisible) return null;

  const features = [
    {
      icon: Mic,
      title: "Voice Translate",
      shortcut: "V",
      description: "Speak and get instant translation",
      color: "bg-blue-50 text-blue-700 dark:bg-blue-950 dark:text-blue-300"
    },
    {
      icon: Image,
      title: "Image Translate",
      shortcut: "I",
      description: "Upload or capture image to translate text",
      color: "bg-green-50 text-green-700 dark:bg-green-950 dark:text-green-300"
    },
    {
      icon: FileText,
      title: "Transcribe",
      shortcut: "T",
      description: "Convert speech to text",
      color: "bg-purple-50 text-purple-700 dark:bg-purple-950 dark:text-purple-300"
    },
    {
      icon: Keyboard,
      title: "Virtual Keyboard",
      shortcut: "K",
      description: "Type with multilingual virtual keyboard",
      color: "bg-orange-50 text-orange-700 dark:bg-orange-950 dark:text-orange-300"
    },
    {
      icon: Monitor,
      title: "Screen Translate",
      shortcut: "S",
      description: "Live floating screen translation",
      color: "bg-red-50 text-red-700 dark:bg-red-950 dark:text-red-300"
    }
  ];

  const tips = [
    "Use Ctrl+1-5 to quickly switch between translation modes",
    "Use Ctrl+0 to return to the main menu",
    "Screen translate runs in background as floating bubble",
    "Virtual keyboard supports 7+ language layouts with live translation",
    "All translations are automatically saved to history",
    "Sign in to sync translations across devices",
    "Drag the screen translate bubble to reposition it"
  ];

  return (
    <Card className="mt-6">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Zap className="h-5 w-5 text-yellow-500" />
          Quick Reference
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Translation Modes */}
        <div>
          <h4 className="font-medium mb-3">Translation Modes</h4>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {features.map((feature) => {
              const Icon = feature.icon;
              return (
                <div key={feature.title} className="flex items-center gap-3 p-2 rounded-lg border">
                  <div className={`p-2 rounded ${feature.color}`}>
                    <Icon className="h-4 w-4" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="font-medium text-sm">{feature.title}</span>
                      <Badge variant="secondary" className="text-xs">
                        {feature.shortcut}
                      </Badge>
                    </div>
                    <p className="text-xs text-muted-foreground mt-1">
                      {feature.description}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Tips */}
        <div>
          <h4 className="font-medium mb-3">Pro Tips</h4>
          <div className="space-y-2">
            {tips.map((tip, index) => (
              <div key={index} className="flex items-start gap-2">
                <div className="w-1.5 h-1.5 rounded-full bg-primary mt-2 flex-shrink-0"></div>
                <p className="text-sm text-muted-foreground">{tip}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Language Support */}
        <div>
          <h4 className="font-medium mb-3">Language Support</h4>
          <div className="flex flex-wrap gap-2">
            <Badge variant="outline">85+ Languages</Badge>
            <Badge variant="outline">Major International</Badge>
            <Badge variant="outline">Regional Dialects</Badge>
            <Badge variant="outline">Indian Languages</Badge>
            <Badge variant="outline">African Languages</Badge>
            <Badge variant="outline">Pacific Languages</Badge>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}