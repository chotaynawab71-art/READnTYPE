import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";

interface Language {
  code: string;
  name: string;
  flag: string;
  region?: string;
}

const languages: Language[] = [
  // Major International Languages
  { code: 'en', name: 'English', flag: '🇺🇸' },
  { code: 'es', name: 'Spanish', flag: '🇪🇸' },
  { code: 'fr', name: 'French', flag: '🇫🇷' },
  { code: 'de', name: 'German', flag: '🇩🇪' },
  { code: 'it', name: 'Italian', flag: '🇮🇹' },
  { code: 'pt', name: 'Portuguese', flag: '🇵🇹' },
  { code: 'ru', name: 'Russian', flag: '🇷🇺' },
  { code: 'ja', name: 'Japanese', flag: '🇯🇵' },
  { code: 'ko', name: 'Korean', flag: '🇰🇷' },
  { code: 'zh', name: 'Chinese (Simplified)', flag: '🇨🇳' },
  { code: 'zh-tw', name: 'Chinese (Traditional)', flag: '🇹🇼' },
  { code: 'ar', name: 'Arabic', flag: '🇸🇦' },
  { code: 'hi', name: 'Hindi', flag: '🇮🇳' },

  // European Languages
  { code: 'nl', name: 'Dutch', flag: '🇳🇱' },
  { code: 'pl', name: 'Polish', flag: '🇵🇱' },
  { code: 'sv', name: 'Swedish', flag: '🇸🇪' },
  { code: 'no', name: 'Norwegian', flag: '🇳🇴' },
  { code: 'da', name: 'Danish', flag: '🇩🇰' },
  { code: 'fi', name: 'Finnish', flag: '🇫🇮' },
  { code: 'el', name: 'Greek', flag: '🇬🇷' },
  { code: 'cs', name: 'Czech', flag: '🇨🇿' },
  { code: 'sk', name: 'Slovak', flag: '🇸🇰' },
  { code: 'hu', name: 'Hungarian', flag: '🇭🇺' },
  { code: 'ro', name: 'Romanian', flag: '🇷🇴' },
  { code: 'bg', name: 'Bulgarian', flag: '🇧🇬' },
  { code: 'hr', name: 'Croatian', flag: '🇭🇷' },
  { code: 'sr', name: 'Serbian', flag: '🇷🇸' },
  { code: 'sl', name: 'Slovenian', flag: '🇸🇮' },
  { code: 'lv', name: 'Latvian', flag: '🇱🇻' },
  { code: 'lt', name: 'Lithuanian', flag: '🇱🇹' },
  { code: 'et', name: 'Estonian', flag: '🇪🇪' },
  { code: 'is', name: 'Icelandic', flag: '🇮🇸' },
  { code: 'ga', name: 'Irish', flag: '🇮🇪' },
  { code: 'cy', name: 'Welsh', flag: '🏴󠁧󠁢󠁷󠁬󠁳󠁿' },
  { code: 'mt', name: 'Maltese', flag: '🇲🇹' },

  // Asian Languages
  { code: 'th', name: 'Thai', flag: '🇹🇭' },
  { code: 'vi', name: 'Vietnamese', flag: '🇻🇳' },
  { code: 'id', name: 'Indonesian', flag: '🇮🇩' },
  { code: 'ms', name: 'Malay', flag: '🇲🇾' },
  { code: 'tl', name: 'Filipino', flag: '🇵🇭' },
  { code: 'my', name: 'Myanmar (Burmese)', flag: '🇲🇲' },
  { code: 'km', name: 'Khmer', flag: '🇰🇭' },
  { code: 'lo', name: 'Lao', flag: '🇱🇦' },
  { code: 'ka', name: 'Georgian', flag: '🇬🇪' },
  { code: 'hy', name: 'Armenian', flag: '🇦🇲' },
  { code: 'az', name: 'Azerbaijani', flag: '🇦🇿' },
  { code: 'kk', name: 'Kazakh', flag: '🇰🇿' },
  { code: 'ky', name: 'Kyrgyz', flag: '🇰🇬' },
  { code: 'uz', name: 'Uzbek', flag: '🇺🇿' },
  { code: 'tk', name: 'Turkmen', flag: '🇹🇲' },
  { code: 'tj', name: 'Tajik', flag: '🇹🇯' },
  { code: 'mn', name: 'Mongolian', flag: '🇲🇳' },

  // Indian Subcontinent Languages
  { code: 'bn', name: 'Bengali', flag: '🇧🇩' },
  { code: 'ur', name: 'Urdu', flag: '🇵🇰' },
  { code: 'ta', name: 'Tamil', flag: '🇮🇳', region: 'Tamil Nadu' },
  { code: 'te', name: 'Telugu', flag: '🇮🇳', region: 'Andhra Pradesh' },
  { code: 'ml', name: 'Malayalam', flag: '🇮🇳', region: 'Kerala' },
  { code: 'kn', name: 'Kannada', flag: '🇮🇳', region: 'Karnataka' },
  { code: 'gu', name: 'Gujarati', flag: '🇮🇳', region: 'Gujarat' },
  { code: 'mr', name: 'Marathi', flag: '🇮🇳', region: 'Maharashtra' },
  { code: 'pa', name: 'Punjabi', flag: '🇮🇳', region: 'Punjab' },
  { code: 'or', name: 'Odia', flag: '🇮🇳', region: 'Odisha' },
  { code: 'as', name: 'Assamese', flag: '🇮🇳', region: 'Assam' },
  { code: 'ne', name: 'Nepali', flag: '🇳🇵' },
  { code: 'si', name: 'Sinhala', flag: '🇱🇰' },

  // Middle Eastern Languages
  { code: 'fa', name: 'Persian (Farsi)', flag: '🇮🇷' },
  { code: 'he', name: 'Hebrew', flag: '🇮🇱' },
  { code: 'tr', name: 'Turkish', flag: '🇹🇷' },
  { code: 'ku', name: 'Kurdish', flag: '🏴' },

  // African Languages
  { code: 'sw', name: 'Swahili', flag: '🇰🇪' },
  { code: 'am', name: 'Amharic', flag: '🇪🇹' },
  { code: 'ha', name: 'Hausa', flag: '🇳🇬' },
  { code: 'yo', name: 'Yoruba', flag: '🇳🇬' },
  { code: 'ig', name: 'Igbo', flag: '🇳🇬' },
  { code: 'zu', name: 'Zulu', flag: '🇿🇦' },
  { code: 'af', name: 'Afrikaans', flag: '🇿🇦' },
  { code: 'xh', name: 'Xhosa', flag: '🇿🇦' },
  { code: 'so', name: 'Somali', flag: '🇸🇴' },
  { code: 'mg', name: 'Malagasy', flag: '🇲🇬' },

  // Latin American Languages
  { code: 'qu', name: 'Quechua', flag: '🇵🇪' },
  { code: 'gn', name: 'Guarani', flag: '🇵🇾' },
  { code: 'ay', name: 'Aymara', flag: '🇧🇴' },

  // Pacific Languages
  { code: 'mi', name: 'Māori', flag: '🇳🇿' },
  { code: 'haw', name: 'Hawaiian', flag: '🇺🇸', region: 'Hawaii' },
  { code: 'sm', name: 'Samoan', flag: '🇼🇸' },
  { code: 'to', name: 'Tongan', flag: '🇹🇴' },
  { code: 'fj', name: 'Fijian', flag: '🇫🇯' },

  // Other Regional Languages
  { code: 'eu', name: 'Basque', flag: '🏴' },
  { code: 'ca', name: 'Catalan', flag: '🏴' },
  { code: 'gl', name: 'Galician', flag: '🏴󠁥󠁳󠁧󠁡󠁿' },
  { code: 'br', name: 'Breton', flag: '🏴' },
  { code: 'co', name: 'Corsican', flag: '🇫🇷', region: 'Corsica' },
  { code: 'sc', name: 'Sardinian', flag: '🇮🇹', region: 'Sardinia' },
  { code: 'lb', name: 'Luxembourgish', flag: '🇱🇺' },
  { code: 'fo', name: 'Faroese', flag: '🇫🇴' },
  { code: 'fy', name: 'Frisian', flag: '🇳🇱', region: 'Friesland' },
];

interface LanguageSelectorProps {
  value: string;
  onValueChange: (value: string) => void;
  placeholder: string;
  disabled?: boolean;
}

export function LanguageSelector({ value, onValueChange, placeholder, disabled = false }: LanguageSelectorProps) {
  // Group languages by region for better organization
  const groupedLanguages = {
    'Major Languages': languages.slice(0, 13),
    'European Languages': languages.slice(13, 36),
    'Asian Languages': languages.slice(36, 50),
    'Indian Subcontinent': languages.slice(50, 63),
    'Middle Eastern': languages.slice(63, 67),
    'African Languages': languages.slice(67, 77),
    'Latin American': languages.slice(77, 80),
    'Pacific Languages': languages.slice(80, 85),
    'Regional Languages': languages.slice(85),
  };

  const getLanguageDisplay = (language: Language) => (
    <span className="flex items-center gap-2">
      <span>{language.flag}</span>
      <span>{language.name}</span>
      {language.region && (
        <span className="text-xs text-muted-foreground">({language.region})</span>
      )}
    </span>
  );

  const selectedLanguage = languages.find(lang => lang.code === value);

  return (
    <Select value={value} onValueChange={onValueChange} disabled={disabled}>
      <SelectTrigger className="w-full">
        <SelectValue placeholder={placeholder}>
          {selectedLanguage && getLanguageDisplay(selectedLanguage)}
        </SelectValue>
      </SelectTrigger>
      <SelectContent className="max-h-80">
        {Object.entries(groupedLanguages).map(([groupName, groupLanguages]) => (
          <div key={groupName}>
            <div className="px-2 py-1.5 text-sm font-semibold text-muted-foreground">
              {groupName}
            </div>
            {groupLanguages.map((language) => (
              <SelectItem key={language.code} value={language.code}>
                {getLanguageDisplay(language)}
              </SelectItem>
            ))}
          </div>
        ))}
      </SelectContent>
    </Select>
  );
}