import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Copy, Trash2, User, Clock, Type, Mic, Image, FileText, Keyboard, Monitor } from "lucide-react";
import { toast } from "sonner@2.0.3";

export interface Translation {
  id: string;
  userId: string;
  sourceText: string;
  translatedText: string;
  sourceLang: string;
  targetLang: string;
  timestamp: string;
  type?: 'text' | 'voice' | 'image' | 'transcribe' | 'keyboard' | 'screen';
}

interface TranslationHistoryProps {
  translations: Translation[];
  onClear: () => void;
  onUseTranslation: (translation: Translation) => void;
  onDeleteTranslation?: (translationId: string) => void;
  isLoading?: boolean;
  isAuthenticated?: boolean;
}

export function TranslationHistory({ 
  translations, 
  onClear, 
  onUseTranslation,
  onDeleteTranslation,
  isLoading = false,
  isAuthenticated = false
}: TranslationHistoryProps) {
  const copyToClipboard = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      toast.success("Copied to clipboard");
    } catch {
      toast.error("Failed to copy");
    }
  };

  const getLanguageName = (code: string) => {
    const languages = {
      'en': 'English',
      'es': 'Spanish',
      'fr': 'French',
      'de': 'German',
      'it': 'Italian',
      'pt': 'Portuguese',
      'ru': 'Russian',
      'ja': 'Japanese',
      'ko': 'Korean',
      'zh': 'Chinese',
      'ar': 'Arabic',
      'hi': 'Hindi',
    };
    return languages[code as keyof typeof languages] || code;
  };

  const getTypeIcon = (type?: string) => {
    switch (type) {
      case 'voice':
        return <Mic className="h-3 w-3" />;
      case 'image':
        return <Image className="h-3 w-3" />;
      case 'transcribe':
        return <FileText className="h-3 w-3" />;
      case 'keyboard':
        return <Keyboard className="h-3 w-3" />;
      case 'screen':
        return <Monitor className="h-3 w-3" />;
      default:
        return <Type className="h-3 w-3" />;
    }
  };

  const getTypeColor = (type?: string) => {
    switch (type) {
      case 'voice':
        return 'bg-blue-100 text-blue-800';
      case 'image':
        return 'bg-green-100 text-green-800';
      case 'transcribe':
        return 'bg-purple-100 text-purple-800';
      case 'keyboard':
        return 'bg-yellow-100 text-yellow-800';
      case 'screen':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const formatTimestamp = (timestamp: string) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diffTime = Math.abs(now.getTime() - date.getTime());
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays === 1) {
      return `Today at ${date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;
    } else if (diffDays === 2) {
      return `Yesterday at ${date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;
    } else if (diffDays <= 7) {
      return `${diffDays - 1} days ago`;
    } else {
      return date.toLocaleDateString();
    }
  };

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            Translation History
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-center py-8">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (translations.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            Translation History
            {!isAuthenticated && (
              <div className="flex items-center gap-1 text-xs text-muted-foreground">
                <User className="h-3 w-3" />
                Local only
              </div>
            )}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8 space-y-3">
            <Clock className="h-12 w-12 text-muted-foreground mx-auto" />
            <div>
              <p className="text-muted-foreground">
                No translations yet. Start translating to see your history here.
              </p>
              {!isAuthenticated && (
                <p className="text-xs text-muted-foreground mt-2">
                  Sign in to save your history permanently and sync across devices.
                </p>
              )}
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <span>Translation History</span>
          <div className="flex items-center gap-2">
            {!isAuthenticated && (
              <div className="flex items-center gap-1 text-xs text-muted-foreground">
                <User className="h-3 w-3" />
                Local
              </div>
            )}
            <Button
              variant="outline"
              size="sm"
              onClick={onClear}
              className="h-8"
            >
              <Trash2 className="h-4 w-4 mr-1" />
              Clear All
            </Button>
          </div>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4 max-h-96 overflow-y-auto">
        {translations.map((translation) => (
          <div
            key={translation.id}
            className="border rounded-lg p-4 space-y-2 hover:bg-muted/50 cursor-pointer transition-colors group"
            onClick={() => onUseTranslation(translation)}
          >
            <div className="flex items-center justify-between text-sm text-muted-foreground">
              <div className="flex items-center gap-2">
                <Badge variant="secondary" className={`text-xs ${getTypeColor(translation.type)}`}>
                  {getTypeIcon(translation.type)}
                  <span className="ml-1 capitalize">{translation.type || 'text'}</span>
                </Badge>
                <span>
                  {getLanguageName(translation.sourceLang)} → {getLanguageName(translation.targetLang)}
                </span>
              </div>
              <div className="flex items-center gap-2">
                <span>{formatTimestamp(translation.timestamp)}</span>
                {onDeleteTranslation && (
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-6 w-6 p-0 opacity-0 group-hover:opacity-100 transition-opacity"
                    onClick={(e) => {
                      e.stopPropagation();
                      onDeleteTranslation(translation.id);
                    }}
                  >
                    <Trash2 className="h-3 w-3 text-destructive" />
                  </Button>
                )}
              </div>
            </div>
            <div className="space-y-1">
              <div className="flex items-start justify-between gap-2">
                <p className="text-sm line-clamp-2">{translation.sourceText}</p>
                <Button
                  variant="ghost"
                  size="sm"
                  className="h-6 w-6 p-0 flex-shrink-0 opacity-0 group-hover:opacity-100 transition-opacity"
                  onClick={(e) => {
                    e.stopPropagation();
                    copyToClipboard(translation.sourceText);
                  }}
                >
                  <Copy className="h-3 w-3" />
                </Button>
              </div>
              <div className="flex items-start justify-between gap-2">
                <p className="text-sm font-medium line-clamp-2">{translation.translatedText}</p>
                <Button
                  variant="ghost"
                  size="sm"
                  className="h-6 w-6 p-0 flex-shrink-0 opacity-0 group-hover:opacity-100 transition-opacity"
                  onClick={(e) => {
                    e.stopPropagation();
                    copyToClipboard(translation.translatedText);
                  }}
                >
                  <Copy className="h-3 w-3" />
                </Button>
              </div>
            </div>
          </div>
        ))}
        
        {!isAuthenticated && translations.length > 0 && (
          <div className="text-center pt-4 border-t">
            <p className="text-xs text-muted-foreground">
              Sign in to save more translations and sync across devices
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}