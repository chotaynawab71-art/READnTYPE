import { useState, useRef } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { Upload, Camera, FileImage, X, Copy } from "lucide-react";
import { toast } from "sonner@2.0.3";

interface ImageTranslateProps {
  sourceLang: string;
  targetLang: string;
  onTranslation: (sourceText: string, translatedText: string) => void;
}

export function ImageTranslate({ sourceLang, targetLang, onTranslation }: ImageTranslateProps) {
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [extractedText, setExtractedText] = useState("");
  const [translatedText, setTranslatedText] = useState("");
  const [isProcessing, setIsProcessing] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);

  // Mock OCR function
  const mockOCR = async (imageUrl: string): Promise<string> => {
    await new Promise(resolve => setTimeout(resolve, 2000));
    return "This is mock text extracted from the image. In a real implementation, this would use OCR technology to extract actual text from the uploaded image.";
  };

  // Mock translation function
  const mockTranslate = async (text: string): Promise<string> => {
    await new Promise(resolve => setTimeout(resolve, 1000));
    return `[Image Translation ${sourceLang} → ${targetLang}]: ${text}`;
  };

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    // Validate file type
    if (!file.type.startsWith('image/')) {
      toast.error('Please select an image file');
      return;
    }

    // Validate file size (max 10MB)
    if (file.size > 10 * 1024 * 1024) {
      toast.error('Image size must be less than 10MB');
      return;
    }

    const reader = new FileReader();
    reader.onload = (e) => {
      const imageUrl = e.target?.result as string;
      setSelectedImage(imageUrl);
      processImage(imageUrl);
    };
    reader.readAsDataURL(file);
  };

  const processImage = async (imageUrl: string) => {
    setIsProcessing(true);
    setExtractedText("");
    setTranslatedText("");

    try {
      // Extract text from image
      const extractedText = await mockOCR(imageUrl);
      setExtractedText(extractedText);

      // Translate extracted text
      if (extractedText.trim()) {
        const translated = await mockTranslate(extractedText);
        setTranslatedText(translated);
        onTranslation(extractedText, translated);
        toast.success('Image processed and translated successfully!');
      } else {
        toast.warning('No text found in the image');
      }
    } catch (error) {
      console.error('Image processing error:', error);
      toast.error('Failed to process image');
    } finally {
      setIsProcessing(false);
    }
  };

  const clearImage = () => {
    setSelectedImage(null);
    setExtractedText("");
    setTranslatedText("");
    if (fileInputRef.current) fileInputRef.current.value = '';
    if (cameraInputRef.current) cameraInputRef.current.value = '';
  };

  const copyToClipboard = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      toast.success("Copied to clipboard");
    } catch {
      toast.error("Failed to copy");
    }
  };

  return (
    <div className="space-y-6">
      {/* Image Upload */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            Upload Image
            {selectedImage && (
              <Button onClick={clearImage} variant="outline" size="sm">
                <X className="h-4 w-4 mr-2" />
                Clear
              </Button>
            )}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {!selectedImage ? (
            <div className="border-2 border-dashed border-muted-foreground/25 rounded-lg p-8">
              <div className="text-center space-y-4">
                <FileImage className="h-12 w-12 text-muted-foreground mx-auto" />
                <div>
                  <p className="text-lg font-medium">Upload an image to translate</p>
                  <p className="text-sm text-muted-foreground">
                    Support JPG, PNG, GIF up to 10MB
                  </p>
                </div>
                <div className="flex gap-4 justify-center">
                  <Button onClick={() => fileInputRef.current?.click()} variant="outline">
                    <Upload className="h-4 w-4 mr-2" />
                    Choose File
                  </Button>
                  <Button onClick={() => cameraInputRef.current?.click()} variant="outline">
                    <Camera className="h-4 w-4 mr-2" />
                    Take Photo
                  </Button>
                </div>
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="relative max-w-md mx-auto">
                <ImageWithFallback
                  src={selectedImage}
                  alt="Selected image"
                  className="w-full h-auto rounded-lg border"
                />
                {isProcessing && (
                  <div className="absolute inset-0 bg-black/50 rounded-lg flex items-center justify-center">
                    <div className="text-center text-white">
                      <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-white mx-auto mb-2"></div>
                      <p className="text-sm">Processing image...</p>
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}

          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            onChange={handleFileSelect}
            className="hidden"
          />
          <input
            ref={cameraInputRef}
            type="file"
            accept="image/*"
            capture="environment"
            onChange={handleFileSelect}
            className="hidden"
          />
        </CardContent>
      </Card>

      {/* Extracted Text */}
      {extractedText && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              Extracted Text
              <Button
                onClick={() => copyToClipboard(extractedText)}
                variant="outline"
                size="sm"
              >
                <Copy className="h-4 w-4 mr-2" />
                Copy
              </Button>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="p-4 border rounded-lg bg-muted/30">
              <p className="whitespace-pre-wrap">{extractedText}</p>
            </div>
            <div className="mt-2 text-sm text-muted-foreground">
              {extractedText.length} characters extracted
            </div>
          </CardContent>
        </Card>
      )}

      {/* Translated Text */}
      {translatedText && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              Translation
              <Button
                onClick={() => copyToClipboard(translatedText)}
                variant="outline"
                size="sm"
              >
                <Copy className="h-4 w-4 mr-2" />
                Copy
              </Button>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="p-4 border rounded-lg bg-muted/30">
              <p className="whitespace-pre-wrap">{translatedText}</p>
            </div>
            <div className="mt-2 text-sm text-muted-foreground">
              {translatedText.length} characters
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}