import { useState, useRef, useCallback } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Progress } from "./ui/progress";
import { Badge } from "./ui/badge";
import { Slider } from "./ui/slider";
import { 
  Camera, 
  Scan, 
  Download, 
  RotateCcw, 
  Crop,
  Contrast,
  Sun,
  Loader2, 
  CheckCircle,
  FileImage,
  RefreshCw,
  Eye
} from "lucide-react";
import { toast } from "sonner@2.0.3";

interface CamScannerProps {
  sourceLang: string;
  targetLang: string;
  onTranslation: (sourceText: string, translatedText: string) => void;
}

interface FilterSettings {
  brightness: number;
  contrast: number;
  rotation: number;
}

export function CamScanner({ sourceLang, targetLang, onTranslation }: CamScannerProps) {
  const [capturedImage, setCapturedImage] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [currentStep, setCurrentStep] = useState<'capture' | 'filter' | 'ocr' | 'translate' | 'complete'>('capture');
  const [extractedText, setExtractedText] = useState("");
  const [translatedText, setTranslatedText] = useState("");
  const [filterSettings, setFilterSettings] = useState<FilterSettings>({
    brightness: 100,
    contrast: 100,
    rotation: 0
  });
  const [ocrProgress, setOcrProgress] = useState(0);
  
  const fileInputRef = useRef<HTMLInputElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const mockOCRProcess = async () => {
    setIsProcessing(true);
    setCurrentStep('ocr');
    setOcrProgress(0);

    // Simulate OCR progress
    for (let i = 0; i <= 100; i += 10) {
      setOcrProgress(i);
      await new Promise(resolve => setTimeout(resolve, 200));
    }

    const mockText = `Welcome to Digital Solutions
    
We provide cutting-edge technology solutions for modern businesses. Our services include:

• Cloud Computing Solutions
• Artificial Intelligence Integration  
• Data Analytics and Insights
• Mobile Application Development
• Cybersecurity Solutions

Contact us today to transform your business with technology.

Phone: +1 (555) 123-4567
Email: info@digitalsolutions.com
Website: www.digitalsolutions.com`;

    setExtractedText(mockText);
    setCurrentStep('translate');
    
    // Simulate translation
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    const mockTranslation = `Bienvenido a Soluciones Digitales
    
Proporcionamos soluciones tecnológicas de vanguardia para empresas modernas. Nuestros servicios incluyen:

• Soluciones de Computación en la Nube
• Integración de Inteligencia Artificial
• Análisis de Datos e Insights
• Desarrollo de Aplicaciones Móviles
• Soluciones de Ciberseguridad

Contáctanos hoy para transformar tu negocio con tecnología.

Teléfono: +1 (555) 123-4567
Correo: info@solucionesdigitales.com
Sitio web: www.solucionesdigitales.com`;

    setTranslatedText(mockTranslation);
    setCurrentStep('complete');
    setIsProcessing(false);
    
    onTranslation(mockText, mockTranslation);
    toast.success("Document scanned and translated successfully!");
  };

  const handleImageCapture = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      if (file.type.startsWith('image/')) {
        const reader = new FileReader();
        reader.onload = (e) => {
          setCapturedImage(e.target?.result as string);
          setCurrentStep('filter');
          setExtractedText("");
          setTranslatedText("");
        };
        reader.readAsDataURL(file);
        toast.success("Image captured successfully");
      } else {
        toast.error("Please select a valid image file");
      }
    }
  };

  const handleCameraClick = () => {
    fileInputRef.current?.click();
  };

  const applyFilters = useCallback(() => {
    if (!capturedImage || !canvasRef.current) return;

    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const img = new Image();
    img.onload = () => {
      canvas.width = img.width;
      canvas.height = img.height;

      // Clear canvas
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      // Apply rotation
      ctx.save();
      ctx.translate(canvas.width / 2, canvas.height / 2);
      ctx.rotate((filterSettings.rotation * Math.PI) / 180);
      ctx.translate(-canvas.width / 2, -canvas.height / 2);

      // Apply brightness and contrast
      ctx.filter = `brightness(${filterSettings.brightness}%) contrast(${filterSettings.contrast}%)`;
      ctx.drawImage(img, 0, 0);
      ctx.restore();
    };
    img.src = capturedImage;
  }, [capturedImage, filterSettings]);

  const resetProcess = () => {
    setCapturedImage(null);
    setCurrentStep('capture');
    setExtractedText("");
    setTranslatedText("");
    setFilterSettings({
      brightness: 100,
      contrast: 100,
      rotation: 0
    });
    setOcrProgress(0);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const downloadResults = () => {
    const content = `Original Text (${sourceLang.toUpperCase()}):\n${extractedText}\n\n---\n\nTranslated Text (${targetLang.toUpperCase()}):\n${translatedText}`;
    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'scanned_translation.txt';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    toast.success("Results downloaded successfully");
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Camera className="h-5 w-5" />
            CamScanner & Translate
            <Badge variant="secondary">Smart OCR</Badge>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Step Indicator */}
          <div className="flex items-center justify-between">
            {[
              { key: 'capture', label: 'Capture', icon: Camera },
              { key: 'filter', label: 'Enhance', icon: Contrast },
              { key: 'ocr', label: 'Scan Text', icon: Scan },
              { key: 'translate', label: 'Translate', icon: CheckCircle },
            ].map(({ key, label, icon: Icon }, index) => (
              <div key={key} className="flex items-center">
                <div className={`flex items-center justify-center w-8 h-8 rounded-full border-2 ${
                  currentStep === key ? 'border-blue-500 bg-blue-500 text-white' :
                  ['filter', 'ocr', 'translate', 'complete'].indexOf(currentStep) > ['capture', 'filter', 'ocr', 'translate'].indexOf(key) ? 
                  'border-green-500 bg-green-500 text-white' : 'border-muted-foreground'
                }`}>
                  <Icon className="h-4 w-4" />
                </div>
                <span className="ml-2 text-sm font-medium">{label}</span>
                {index < 3 && <div className="flex-1 h-px bg-muted-foreground/25 mx-4" />}
              </div>
            ))}
          </div>

          {/* Capture Stage */}
          {currentStep === 'capture' && (
            <div className="space-y-4">
              <div className="border-2 border-dashed border-muted-foreground/25 rounded-lg p-8 text-center">
                <Camera className="h-12 w-12 text-blue-500 mx-auto mb-3" />
                <h3 className="font-medium mb-2">Capture Document</h3>
                <p className="text-sm text-muted-foreground mb-4">
                  Take a photo or upload an image of the document you want to translate
                </p>
                <Button onClick={handleCameraClick}>
                  <Camera className="h-4 w-4 mr-2" />
                  Capture Image
                </Button>
              </div>
              
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                capture="environment"
                onChange={handleImageCapture}
                className="hidden"
              />
            </div>
          )}

          {/* Filter/Enhancement Stage */}
          {currentStep === 'filter' && capturedImage && (
            <div className="space-y-4">
              <div className="grid md:grid-cols-2 gap-4">
                <div className="space-y-4">
                  <h4 className="font-medium flex items-center gap-2">
                    <Contrast className="h-4 w-4" />
                    Image Enhancement
                  </h4>
                  
                  <div className="space-y-3">
                    <div className="space-y-2">
                      <label className="text-sm font-medium flex items-center gap-2">
                        <Sun className="h-3 w-3" />
                        Brightness: {filterSettings.brightness}%
                      </label>
                      <Slider
                        value={[filterSettings.brightness]}
                        onValueChange={([value]) => setFilterSettings(prev => ({ ...prev, brightness: value }))}
                        min={50}
                        max={150}
                        step={5}
                        className="w-full"
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <label className="text-sm font-medium flex items-center gap-2">
                        <Contrast className="h-3 w-3" />
                        Contrast: {filterSettings.contrast}%
                      </label>
                      <Slider
                        value={[filterSettings.contrast]}
                        onValueChange={([value]) => setFilterSettings(prev => ({ ...prev, contrast: value }))}
                        min={50}
                        max={200}
                        step={5}
                        className="w-full"
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <label className="text-sm font-medium flex items-center gap-2">
                        <RotateCcw className="h-3 w-3" />
                        Rotation: {filterSettings.rotation}°
                      </label>
                      <Slider
                        value={[filterSettings.rotation]}
                        onValueChange={([value]) => setFilterSettings(prev => ({ ...prev, rotation: value }))}
                        min={-45}
                        max={45}
                        step={1}
                        className="w-full"
                      />
                    </div>
                  </div>
                  
                  <div className="flex gap-2">
                    <Button onClick={mockOCRProcess} disabled={isProcessing}>
                      {isProcessing ? (
                        <>
                          <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                          Processing...
                        </>
                      ) : (
                        <>
                          <Scan className="h-4 w-4 mr-2" />
                          Scan & Translate
                        </>
                      )}
                    </Button>
                    <Button variant="outline" onClick={resetProcess}>
                      <RefreshCw className="h-4 w-4 mr-2" />
                      Reset
                    </Button>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <h4 className="font-medium flex items-center gap-2">
                    <Eye className="h-4 w-4" />
                    Preview
                  </h4>
                  <div className="relative border rounded-lg overflow-hidden bg-muted/50">
                    <img
                      src={capturedImage}
                      alt="Captured document"
                      className="w-full h-64 object-contain"
                      style={{
                        filter: `brightness(${filterSettings.brightness}%) contrast(${filterSettings.contrast}%)`,
                        transform: `rotate(${filterSettings.rotation}deg)`
                      }}
                    />
                    <canvas ref={canvasRef} className="hidden" />
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* OCR Processing */}
          {currentStep === 'ocr' && (
            <div className="space-y-4 text-center">
              <Scan className="h-12 w-12 text-blue-500 mx-auto" />
              <h3 className="font-medium">Scanning Text...</h3>
              <Progress value={ocrProgress} className="w-full max-w-md mx-auto" />
              <p className="text-sm text-muted-foreground">
                Extracting text from image using OCR technology
              </p>
            </div>
          )}

          {/* Translation Processing */}
          {currentStep === 'translate' && (
            <div className="space-y-4 text-center">
              <Loader2 className="h-12 w-12 text-blue-500 mx-auto animate-spin" />
              <h3 className="font-medium">Translating Text...</h3>
              <p className="text-sm text-muted-foreground">
                Converting from {sourceLang.toUpperCase()} to {targetLang.toUpperCase()}
              </p>
            </div>
          )}

          {/* Results */}
          {currentStep === 'complete' && (extractedText || translatedText) && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h4 className="font-medium flex items-center gap-2">
                  <CheckCircle className="h-4 w-4 text-green-500" />
                  Results
                </h4>
                <div className="flex gap-2">
                  <Button size="sm" onClick={downloadResults}>
                    <Download className="h-3 w-3 mr-1" />
                    Download
                  </Button>
                  <Button size="sm" variant="outline" onClick={resetProcess}>
                    <Camera className="h-3 w-3 mr-1" />
                    New Scan
                  </Button>
                </div>
              </div>
              
              <div className="grid md:grid-cols-2 gap-4">
                <Card>
                  <CardHeader className="pb-3">
                    <h4 className="font-medium">Extracted Text ({sourceLang.toUpperCase()})</h4>
                  </CardHeader>
                  <CardContent>
                    <div className="max-h-60 overflow-y-auto p-3 bg-muted/50 rounded text-sm whitespace-pre-wrap">
                      {extractedText}
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-3">
                    <h4 className="font-medium">Translated Text ({targetLang.toUpperCase()})</h4>
                  </CardHeader>
                  <CardContent>
                    <div className="max-h-60 overflow-y-auto p-3 bg-blue-50 dark:bg-blue-950/20 rounded text-sm whitespace-pre-wrap">
                      {translatedText}
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}