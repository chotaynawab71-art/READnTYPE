import { projectId, publicAnonKey } from '../utils/supabase/info'
import { supabase } from '../utils/supabase/client'

const API_BASE = `https://${projectId}.supabase.co/functions/v1/make-server-8e6575ed`

async function getAuthHeaders() {
  const { data: { session } } = await supabase.auth.getSession()
  return {
    'Content-Type': 'application/json',
    'Authorization': `Bearer ${session?.access_token || publicAnonKey}`
  }
}

export interface Translation {
  id: string
  userId: string
  sourceText: string
  translatedText: string
  sourceLang: string
  targetLang: string
  timestamp: string
  type?: 'text' | 'voice' | 'image' | 'transcribe' | 'keyboard' | 'screen'
}

export interface UserPreferences {
  defaultSourceLang: string
  defaultTargetLang: string
  maxHistoryItems: number
}

export const translationService = {
  async getUserProfile() {
    const headers = await getAuthHeaders()
    const response = await fetch(`${API_BASE}/profile`, { headers })
    
    if (!response.ok) {
      const error = await response.json()
      throw new Error(error.error || 'Failed to get user profile')
    }
    
    return response.json()
  },

  async updatePreferences(preferences: UserPreferences) {
    const headers = await getAuthHeaders()
    const response = await fetch(`${API_BASE}/preferences`, {
      method: 'PUT',
      headers,
      body: JSON.stringify(preferences)
    })
    
    if (!response.ok) {
      const error = await response.json()
      throw new Error(error.error || 'Failed to update preferences')
    }
    
    return response.json()
  },

  async saveTranslation(translation: Omit<Translation, 'id' | 'userId' | 'timestamp'>) {
    const headers = await getAuthHeaders()
    const response = await fetch(`${API_BASE}/translations`, {
      method: 'POST',
      headers,
      body: JSON.stringify(translation)
    })
    
    if (!response.ok) {
      const error = await response.json()
      throw new Error(error.error || 'Failed to save translation')
    }
    
    return response.json()
  },

  async getTranslationHistory(): Promise<{ translations: Translation[] }> {
    const headers = await getAuthHeaders()
    const response = await fetch(`${API_BASE}/translations`, { headers })
    
    if (!response.ok) {
      const error = await response.json()
      throw new Error(error.error || 'Failed to get translation history')
    }
    
    return response.json()
  },

  async deleteTranslation(translationId: string) {
    const headers = await getAuthHeaders()
    // Extract the timestamp part from the full ID (userId:timestamp)
    const timestampId = translationId.split(':').pop()
    const response = await fetch(`${API_BASE}/translations/${timestampId}`, {
      method: 'DELETE',
      headers
    })
    
    if (!response.ok) {
      const error = await response.json()
      throw new Error(error.error || 'Failed to delete translation')
    }
    
    return response.json()
  },

  async clearTranslationHistory() {
    const headers = await getAuthHeaders()
    const response = await fetch(`${API_BASE}/translations`, {
      method: 'DELETE',
      headers
    })
    
    if (!response.ok) {
      const error = await response.json()
      throw new Error(error.error || 'Failed to clear translation history')
    }
    
    return response.json()
  }
}