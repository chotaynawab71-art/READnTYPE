import { Hono } from 'npm:hono'
import { cors } from 'npm:hono/cors'
import { logger } from 'npm:hono/logger'
import { createClient } from 'npm:@supabase/supabase-js@2'
import * as kv from './kv_store.tsx'

const app = new Hono()

app.use('*', cors({
  origin: '*',
  allowHeaders: ['*'],
  allowMethods: ['*'],
}))
app.use('*', logger(console.log))

const supabase = createClient(
  Deno.env.get('SUPABASE_URL')!,
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!,
)

// Helper function to get user ID from access token
async function getUserId(request: Request): Promise<string | null> {
  const accessToken = request.headers.get('Authorization')?.split(' ')[1];
  if (!accessToken) return null;
  
  const { data: { user }, error } = await supabase.auth.getUser(accessToken);
  if (error || !user) return null;
  
  return user.id;
}

// Sign up route
app.post('/make-server-8e6575ed/signup', async (c) => {
  try {
    const { email, password, name } = await c.req.json()
    
    if (!email || !password || !name) {
      return c.json({ error: 'Email, password, and name are required' }, 400)
    }

    const { data, error } = await supabase.auth.admin.createUser({
      email,
      password,
      user_metadata: { name },
      // Automatically confirm the user's email since an email server hasn't been configured.
      email_confirm: true
    })

    if (error) {
      console.log(`Sign up error: ${error.message}`)
      return c.json({ error: error.message }, 400)
    }

    // Initialize user preferences
    await kv.set(`user_preferences:${data.user.id}`, {
      defaultSourceLang: 'en',
      defaultTargetLang: 'es',
      maxHistoryItems: 50,
      createdAt: new Date().toISOString()
    })

    return c.json({ 
      user: data.user,
      message: 'User created successfully' 
    })
  } catch (error) {
    console.log(`Sign up error: ${error}`)
    return c.json({ error: 'Internal server error during sign up' }, 500)
  }
})

// Get user profile
app.get('/make-server-8e6575ed/profile', async (c) => {
  try {
    const userId = await getUserId(c.req.raw);
    if (!userId) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const { data: { user }, error } = await supabase.auth.admin.getUserById(userId);
    if (error || !user) {
      return c.json({ error: 'User not found' }, 404);
    }

    const preferences = await kv.get(`user_preferences:${userId}`) || {
      defaultSourceLang: 'en',
      defaultTargetLang: 'es',
      maxHistoryItems: 50
    };

    return c.json({
      user: {
        id: user.id,
        email: user.email,
        name: user.user_metadata?.name,
        created_at: user.created_at
      },
      preferences
    });
  } catch (error) {
    console.log(`Get profile error: ${error}`)
    return c.json({ error: 'Internal server error while getting profile' }, 500)
  }
})

// Update user preferences
app.put('/make-server-8e6575ed/preferences', async (c) => {
  try {
    const userId = await getUserId(c.req.raw);
    if (!userId) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const preferences = await c.req.json();
    await kv.set(`user_preferences:${userId}`, {
      ...preferences,
      updatedAt: new Date().toISOString()
    });

    return c.json({ message: 'Preferences updated successfully' });
  } catch (error) {
    console.log(`Update preferences error: ${error}`)
    return c.json({ error: 'Internal server error while updating preferences' }, 500)
  }
})

// Save translation to history
app.post('/make-server-8e6575ed/translations', async (c) => {
  try {
    const userId = await getUserId(c.req.raw);
    if (!userId) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const { sourceText, translatedText, sourceLang, targetLang, type } = await c.req.json();
    
    if (!sourceText || !translatedText || !sourceLang || !targetLang) {
      return c.json({ error: 'Missing required translation data' }, 400);
    }

    const translationId = `${userId}:${Date.now()}`;
    const translation = {
      id: translationId,
      userId,
      sourceText,
      translatedText,
      sourceLang,
      targetLang,
      type: type || 'text', // Default to 'text' if not specified
      timestamp: new Date().toISOString()
    };

    await kv.set(`translation:${translationId}`, translation);

    // Update user's translation list
    const userTranslationsKey = `user_translations:${userId}`;
    const existingTranslations = await kv.get(userTranslationsKey) || [];
    const updatedTranslations = [translationId, ...existingTranslations.slice(0, 49)]; // Keep last 50
    await kv.set(userTranslationsKey, updatedTranslations);

    return c.json({ translation, message: 'Translation saved successfully' });
  } catch (error) {
    console.log(`Save translation error: ${error}`)
    return c.json({ error: 'Internal server error while saving translation' }, 500)
  }
})

// Get user's translation history
app.get('/make-server-8e6575ed/translations', async (c) => {
  try {
    const userId = await getUserId(c.req.raw);
    if (!userId) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const userTranslationsKey = `user_translations:${userId}`;
    const translationIds = await kv.get(userTranslationsKey) || [];
    
    const translations = [];
    for (const id of translationIds) {
      const translation = await kv.get(`translation:${id}`);
      if (translation) {
        translations.push(translation);
      }
    }

    return c.json({ translations });
  } catch (error) {
    console.log(`Get translations error: ${error}`)
    return c.json({ error: 'Internal server error while getting translations' }, 500)
  }
})

// Delete translation from history
app.delete('/make-server-8e6575ed/translations/:id', async (c) => {
  try {
    const userId = await getUserId(c.req.raw);
    if (!userId) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const translationId = c.req.param('id');
    const fullTranslationId = `${userId}:${translationId}`;
    
    // Remove from storage
    await kv.del(`translation:${fullTranslationId}`);
    
    // Update user's translation list
    const userTranslationsKey = `user_translations:${userId}`;
    const existingTranslations = await kv.get(userTranslationsKey) || [];
    const updatedTranslations = existingTranslations.filter((id: string) => id !== fullTranslationId);
    await kv.set(userTranslationsKey, updatedTranslations);

    return c.json({ message: 'Translation deleted successfully' });
  } catch (error) {
    console.log(`Delete translation error: ${error}`)
    return c.json({ error: 'Internal server error while deleting translation' }, 500)
  }
})

// Clear all translation history
app.delete('/make-server-8e6575ed/translations', async (c) => {
  try {
    const userId = await getUserId(c.req.raw);
    if (!userId) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const userTranslationsKey = `user_translations:${userId}`;
    const translationIds = await kv.get(userTranslationsKey) || [];
    
    // Delete all translation records
    for (const id of translationIds) {
      await kv.del(`translation:${id}`);
    }
    
    // Clear the user's translation list
    await kv.set(userTranslationsKey, []);

    return c.json({ message: 'Translation history cleared successfully' });
  } catch (error) {
    console.log(`Clear translations error: ${error}`)
    return c.json({ error: 'Internal server error while clearing translations' }, 500)
  }
})

// Health check
app.get('/make-server-8e6575ed/health', (c) => {
  return c.json({ status: 'healthy', timestamp: new Date().toISOString() })
})

Deno.serve(app.fetch)