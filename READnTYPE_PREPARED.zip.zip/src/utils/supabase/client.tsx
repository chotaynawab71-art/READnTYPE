import { createClient } from '@supabase/supabase-js'

const supabaseUrl = 'https://ktduqwkrjlkvfkcdsqgn.supabase.co'
const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imt0ZHVxd2tyamxrdmZrY2RzcWduIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MzMzNDg3NzAsImV4cCI6MjA0ODkyNDc3MH0.KMIlQwaNWyP8fCGPNhUg3bgRQxDHNp7w_ZmWsI5w3Ec'

export const supabase = createClient(supabaseUrl, supabaseAnonKey)