import React from 'react';

export default function Privacy() {
  return (
    <div style={{ padding: 16 }}>
      <h1 style={{ fontSize: 20, fontWeight: 700 }}>Privacy Policy</h1>
      <p style={{ marginTop: 8 }}>
        READnTYPE processes data on-device. We do not collect, store, or share
        personal information. Camera, microphone, or storage permissions are
        used only when you enable related features.
      </p>
      <p style={{ marginTop: 8 }}>
        Contact: you@example.com
      </p>
    </div>
  );
}
